Public synthetic facts for D-F-cli-synthetic. No observed outcomes or normative approval.
