"""Own delivery tests; expectations are not execution records.
Run: /opt/specorganon/venv/bin/python -E -s -B /input/delivery/test_fractionmix.py
External executor supplies readonly delivery, network isolation and resource limits.
"""

import json
import random
import subprocess
import sys
from fractions import Fraction
from math import gcd

PYTHON = '/opt/specorganon/venv/bin/python'
COMMAND = [PYTHON, '-E', '-s', '-B', '/input/delivery/fractionmix.py']
ERROR = b'{"error":"invalid_input"}\n'
STREAM_LIMIT = 2 * 1024 * 1024


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def invoke(raw, label, args=()):
    process = subprocess.run(COMMAND + list(args), input=raw,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             timeout=3, check=False)
    require(len(process.stdout) <= STREAM_LIMIT, label + ': stdout limit')
    require(len(process.stderr) <= STREAM_LIMIT, label + ': stderr limit')
    return process


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate output key')
        result[key] = value
    return result


def non_json_constant(value):
    raise AssertionError('non-JSON output constant: ' + value)


def expect_success(raw, expected, label):
    process = invoke(raw, label)
    require(process.returncode == 0, label + ': exit')
    require(process.stderr == b'', label + ': stderr')
    output = process.stdout
    require(output.startswith(b'{') and output.endswith(b'}\n'),
            label + ': outer format')
    actual = json.loads(output.decode('utf-8', errors='strict'),
                        object_pairs_hook=unique_object,
                        parse_constant=non_json_constant)
    require(type(actual) is dict and set(actual) == set(expected),
            label + ': output keys')
    require(all(type(value) is int for value in actual.values()),
            label + ': exact integer types')
    require(actual == expected, label + ': result')
    require(actual['denominator'] > 0, label + ': denominator sign')
    require(gcd(actual['numerator'], actual['denominator']) == 1,
            label + ': reduction')


def encode(terms):
    return json.dumps({'terms': terms}, separators=(',', ':')).encode('ascii')


def term(numerator, denominator):
    return {'numerator': numerator, 'denominator': denominator}


def expected_sum(terms):
    value = sum((Fraction(t['numerator'], t['denominator']) for t in terms),
                Fraction(0, 1))
    return {'numerator': value.numerator, 'denominator': value.denominator,
            'term_count': len(terms)}


def valid(terms, label):
    expect_success(encode(terms), expected_sum(terms), label)


def invalid(raw, label, args=()):
    process = invoke(raw, label, args)
    require(process.returncode == 2, label + ': error exit')
    require(process.stdout == b'', label + ': error stdout')
    require(process.stderr == ERROR, label + ': exact error stderr')


def prime(number):
    # Deterministic Miller-Rabin bases sufficient for numbers below 10**9.
    if number < 2:
        return False
    for divisor in (2, 3, 5, 7, 11):
        if number % divisor == 0:
            return number == divisor
    odd = number - 1
    power = 0
    while odd % 2 == 0:
        odd //= 2
        power += 1
    for base in (2, 3, 5, 7, 11):
        value = pow(base, odd, number)
        if value in (1, number - 1):
            continue
        for _ in range(power - 1):
            value = value * value % number
            if value == number - 1:
                break
        else:
            return False
    return True


def main():
    sys.set_int_max_str_digits(0)
    expect_success(b'{"terms":[{"numerator":1,"denominator":2},'
                   b'{"numerator":1,"denominator":3}]}',
                   {'numerator': 5, 'denominator': 6, 'term_count': 2},
                   'public example 1')
    expect_success(b'{"terms":[{"numerator":2,"denominator":4},'
                   b'{"numerator":-1,"denominator":2}]}',
                   {'numerator': 0, 'denominator': 1, 'term_count': 2},
                   'public example 2')
    valid([], 'empty list')
    valid([term(-6, 8)], 'negative reduction')
    valid([term(0, 1000000000)] * 1000, '1000 zero terms')
    valid([term(1000000000, 1)] * 1000, '1000 upper numerators')
    valid([term(-1000000000, 1)] * 1000, '1000 lower numerators')
    valid([term(1, 1000000000)], 'upper denominator')
    valid([term(1, 6)] * 6, 'duplicates counted')
    mixed = [term(0, 17), term(7, 12), term(-7, 12), term(2, 3)]
    valid(mixed, 'zeros and cancellation')
    valid(list(reversed(mixed)), 'reversed order')
    expect_success(b' \t\r\n{"terms":[{"denominator":2,"numerator":1}]}\n ',
                   {'numerator': 1, 'denominator': 2, 'term_count': 1},
                   'key order and outer whitespace')
    expect_success(b'{"ter\\u006ds":[{"num\\u0065rator":1,"denominator":2}]}',
                   {'numerator': 1, 'denominator': 2, 'term_count': 1},
                   'decoded valid keys')
    base = encode([])
    expect_success(base + b' ' * (65536 - len(base)), expected_sum([]),
                   '65536 bytes inclusive')
    invalid(base + b' ' * (65537 - len(base)), '65537 bytes')
    invalid(encode([term(0, 1)] * 1001), '1001 terms')

    invalid_documents = [
        b'', b' \t\r\n', b'null', b'[]', b'1', b'true', b'"text"',
        b'{}', b'{"terms":null}', b'{"terms":{}}',
        b'{"terms":true}', b'{"terms":"[]"}',
        b'{"terms":[],"extra":0}', b'{"terms":[]}{}',
        b'{"terms":[]} null', b'{"terms":[],}',
        b'{"terms":[1]}', b'{"terms":[null]}', b'{"terms":[[]]}',
        b'{"terms":[{}]}', b'{"terms":[{"numerator":0}]}',
        b'{"terms":[{"denominator":1}]}',
        b'{"terms":[{"numerator":0,"denominator":1,"extra":2}]}',
        b'{"terms":[],"terms":[]}',
        b'{"terms":[],"ter\\u006ds":[]}',
        b'{"terms":[{"numerator":0,"numerator":1,"denominator":2}]}',
        b'{"terms":[{"numerator":0,"num\\u0065rator":1,"denominator":2}]}',
        b'{"terms":[{"numerator":0,"denominator":1,"denominator":2}]}',
        b'{"terms":[{"numerator":NaN,"denominator":1}]}',
        b'{"terms":[{"numerator":Infinity,"denominator":1}]}',
        b'{"terms":[{"numerator":-Infinity,"denominator":1}]}',
        b'{"terms":[{"numerator":01,"denominator":1}]}',
        b'{"terms":[{"numerator":+1,"denominator":1}]}',
        b'{"terms":[]}\v', b'\f{"terms":[]}',
        b'\xef\xbb\xbf{"terms":[]}', b'{"terms":[]}\x00',
        b'{"terms":[]}\xff', b'{"terms":[]}\xc0\xaf',
        b'{"terms":[]}\xc3',
        b'{"terms":[{"numerator":0,"denominator":1,"x":"\x00"}]}',
        b'{"terms":' + b'[' * 2000 + b'0' + b']' * 2000 + b'}',
        b'{"terms":[{"numerator":' + b'9' * 5000 + b',"denominator":1}]}',
    ]
    for index, raw in enumerate(invalid_documents):
        invalid(raw, 'invalid document ' + str(index))
    for value in (True, False, 1.0, 1.5, '1', None, [], {},
                  -1000000001, 1000000001):
        invalid(encode([term(value, 1)]), 'invalid numerator ' + repr(value))
    for value in (True, False, 1.0, 1.5, '1', None, [], {},
                  0, -1, -1000000000, 1000000001):
        invalid(encode([term(0, value)]), 'invalid denominator ' + repr(value))
    invalid(encode([term(1, 2), term(-1, 2), term(0, 0)]),
            'invalid term after cancellation')
    invalid(encode([term(0, 1), term(True, 1)]), 'invalid term after zero')
    for argument in ('--help', '--', 'extra'):
        invalid(base, 'argument ' + argument, (argument,))

    # Leave stdin open with no bytes: argument rejection must precede reading.
    process = subprocess.Popen(COMMAND + ['--help'], stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired as error:
            raise AssertionError('argument rejection waited for stdin') from error
        stdout, stderr = process.communicate(timeout=3)
        require(process.returncode == 2 and stdout == b'' and stderr == ERROR,
                'argument rejection before stdin')
    finally:
        if process.poll() is None:
            process.kill()
            process.communicate()

    rng = random.Random(1927)
    for index in range(12):
        terms = [term(rng.randint(-1000000000, 1000000000),
                      rng.randint(1, 1000000000)) for _ in range(25)]
        valid(terms, 'seeded rational case ' + str(index))
        rng.shuffle(terms)
        valid(terms, 'seeded permutation ' + str(index))

    # Distinct primes give a product denominator: modulo each prime,
    # exactly one summand of the common numerator is nonzero.
    denominators = []
    candidate = 999999999
    while len(denominators) < 500:
        if prime(candidate):
            denominators.append(candidate)
        candidate -= 2
    terms = [term(1, denominator) for denominator in denominators]
    expected = expected_sum(terms)
    product = 1
    for denominator in denominators:
        product *= denominator
    require(expected['denominator'] == product, 'large oracle denominator')
    require(len(str(expected['denominator'])) > 4300,
            'large denominator fixture')
    require(len(str(expected['numerator'])) > 4300,
            'large numerator fixture')
    require(len(encode(terms)) <= 65536, 'large fixture input limit')
    expect_success(encode(terms), expected, 'large decimal output')
    print('Own delivery test assertions completed.')


if __name__ == '__main__':
    main()
