import json
import sys
from fractions import Fraction


class InvalidInput(ValueError):
    pass


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidInput()
        result[key] = value
    return result


def reject_constant(value):
    raise InvalidInput()


def decode_terms(raw):
    if len(raw) > 65536 or raw.startswith(b'\xef\xbb\xbf') or b'\x00' in raw:
        raise InvalidInput()
    document = json.loads(
        raw.decode('utf-8', errors='strict'),
        object_pairs_hook=unique_object,
        parse_constant=reject_constant,
    )
    if type(document) is not dict or set(document) != {'terms'}:
        raise InvalidInput()
    terms = document['terms']
    if type(terms) is not list or len(terms) > 1000:
        raise InvalidInput()
    for term in terms:
        if type(term) is not dict or set(term) != {'numerator', 'denominator'}:
            raise InvalidInput()
        numerator = term['numerator']
        denominator = term['denominator']
        if type(numerator) is not int or not -1000000000 <= numerator <= 1000000000:
            raise InvalidInput()
        if type(denominator) is not int or not 1 <= denominator <= 1000000000:
            raise InvalidInput()
    return terms


def invalid_input():
    sys.stderr.buffer.write(b'{"error":"invalid_input"}\n')
    return 2


def main():
    if len(sys.argv) != 1:
        return invalid_input()
    sys.set_int_max_str_digits(0)
    raw = sys.stdin.buffer.read(65537)
    try:
        terms = decode_terms(raw)
    except (ValueError, UnicodeError, RecursionError):
        return invalid_input()
    total = Fraction(0, 1)
    for term in terms:
        total += Fraction(term['numerator'], term['denominator'])
    result = {
        'numerator': total.numerator,
        'denominator': total.denominator,
        'term_count': len(terms),
    }
    output = json.dumps(result, separators=(',', ':')) + '\n'
    sys.stdout.buffer.write(output.encode('utf-8'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
