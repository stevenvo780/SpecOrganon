import sys
sys.stderr.write('{"error":"invalid_input"}\n')
raise SystemExit(2)
