# FractionMix

Utilidad local para sumar racionales exactamente y devolver una fracción canónica. Requiere Python 3.12 y sólo biblioteca estándar; no requiere paquetes adicionales. Colocar fractionmix.py en /input/delivery. Los datos se leen exclusivamente de stdin, sin archivos auxiliares, red ni consulta del entorno por el programa.

## Invocación

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Suministrar un único objeto JSON por stdin. Cualquier argumento, incluido --help, produce el error contractual antes de leer stdin.

## Ejemplos públicos

Comandos reproducibles y resultados esperados por el contrato; no son resultados observados.

```sh
printf '%s\n' '{"terms":[{"numerator":1,"denominator":2},{"numerator":1,"denominator":3}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Stdout esperado, con LF terminal:

```json
{"numerator":5,"denominator":6,"term_count":2}
```

```sh
printf '%s\n' '{"terms":[{"numerator":2,"denominator":4},{"numerator":-1,"denominator":2}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Stdout esperado, con LF terminal:

```json
{"numerator":0,"denominator":1,"term_count":2}
```

En ambos ejemplos el contrato exige exit 0 y stderr vacío.

## Validación y errores

La entrada tiene como máximo 65536 bytes, incluyendo whitespace final. Se exige UTF-8 estricto sin BOM inicial ni byte NUL. Se permite whitespace JSON exterior, pero no entrada vacía, segundo valor, claves duplicadas a cualquier profundidad ni NaN/Infinity/-Infinity. Las claves se comparan después de decodificar escapes.

El objeto superior contiene exactamente terms, una lista de 0 a 1000 objetos. Cada término contiene exactamente numerator y denominator. Ambos son enteros JSON exactos: no bool, float, string ni coerción. Numerator está entre -1000000000 y 1000000000 inclusive; denominator entre 1 y 1000000000 inclusive. Un término inválido invalida toda la entrada, aunque sea cero o se cancele.

Para cualquier error contractual: exit 2, stdout vacío y stderr exactamente los bytes ASCII de {"error":"invalid_input"} seguidos de un LF. Timeout, OOM y crash son fallos de ejecución y no se convierten en errores contractuales.

## Aritmética y salida

La validación de todos los términos precede al cálculo. La suma usa enteros exactos y reducción por máximo común divisor, sin redondeo. El denominador es positivo; cero se representa como 0/1. La lista vacía devuelve numerator=0, denominator=1 y term_count=0. Duplicados, ceros y cancelaciones cuentan individualmente; no se deduplican términos. El orden no cambia el valor de la suma.

La salida contiene exactamente numerator, denominator y term_count como enteros JSON, empieza con { y termina con } seguido de LF. No hay whitespace exterior. Se habilita explícitamente la conversión decimal de enteros de más de 4300 dígitos; los rangos por término no limitan los enteros del resultado.

## Recursos y verificación

El entorno de ejecución debe aplicar por invocación 3 segundos, 2 CPU, 1 GiB, 128 procesos y streams de hasta 2 MiB, con entrega readonly y sin red ni credenciales. El programa limita la lectura a 65537 bytes para detectar exceso y no modifica la entrega. No configura ni amplía los límites del ejecutor. Su viabilidad bajo esos recursos no ha sido medida aquí.

Esta entrega corresponde a la etapa program y contiene únicamente programa y documentación. Las pruebas propias se incorporarán en la etapa tests mediante test_fractionmix.py; ese archivo todavía no se entrega. El comando previsto para esa etapa es:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/test_fractionmix.py
```

La suite pendiente debe invocar el programa con el intérprete absoluto, comprobar ambos ejemplos, éxito, errores y bordes: lista vacía, cancelaciones y duplicados, límites de bytes/términos/enteros, UTF-8, BOM, NUL, duplicados escapados, números y tipos prohibidos, argumentos y serialización de enteros grandes. Debe comprobar exit, stdout y stderr contra expectativas y un oráculo exacto. Este comando no acredita ejecución ni resultados.

Las pruebas propias se mantienen separadas de las 84 recetas candidatas de evaluación reservada, cuyo contenido completo no se suministra. No se utiliza feedback reservado para reparar. El alcance es conformidad técnica en entradas sintéticas; no se afirma cobertura universal, superioridad general ni beneficio en personas.
