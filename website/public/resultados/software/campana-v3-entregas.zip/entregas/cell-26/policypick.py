import sys
import json


def fail():
    sys.stderr.write('{"error":"invalid_input"}\n')
    sys.exit(2)


def dict_no_dup(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise ValueError("duplicate key")
        d[k] = v
    return d


def no_constant(c):
    raise ValueError("constant not allowed")


def validate_string(s):
    if type(s) is not str:
        return False
    if len(s) == 0:
        return False
    if '\x00' in s or '\r' in s or '\n' in s:
        return False
    try:
        b = s.encode('utf-8')
    except UnicodeEncodeError:
        return False
    if len(b) > 64:
        return False
    return True


def main():
    if len(sys.argv) > 1:
        fail()

    try:
        raw = sys.stdin.buffer.read(65537)
    except Exception:
        fail()

    if len(raw) == 0 or len(raw) > 65536:
        fail()

    if b'\x00' in raw or b'\xef\xbb\xbf' in raw:
        fail()

    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError:
        fail()

    try:
        data = json.loads(
            text,
            object_pairs_hook=dict_no_dup,
            parse_constant=no_constant,
        )
    except Exception:
        fail()

    if type(data) is not dict:
        fail()

    if set(data.keys()) != {"rules", "queries"}:
        fail()

    raw_rules = data["rules"]
    raw_queries = data["queries"]

    if type(raw_rules) is not list or type(raw_queries) is not list:
        fail()

    if len(raw_rules) > 1000 or len(raw_queries) > 1000:
        fail()

    seen_rule_names = set()
    parsed_rules = []

    for r in raw_rules:
        if type(r) is not dict:
            fail()
        if set(r.keys()) != {"name", "priority", "requires"}:
            fail()

        name = r["name"]
        if not validate_string(name):
            fail()
        if name in seen_rule_names:
            fail()
        seen_rule_names.add(name)

        priority = r["priority"]
        if type(priority) is not int:
            fail()
        if not (-1000000000 <= priority <= 1000000000):
            fail()

        requires = r["requires"]
        if type(requires) is not list:
            fail()
        if len(requires) > 1000:
            fail()
        for req in requires:
            if not validate_string(req):
                fail()

        parsed_rules.append({
            "name": name,
            "priority": priority,
            "requires_set": set(requires),
        })

    seen_query_ids = set()
    parsed_queries = []

    for q in raw_queries:
        if type(q) is not dict:
            fail()
        if set(q.keys()) != {"id", "tags"}:
            fail()

        qid = q["id"]
        if not validate_string(qid):
            fail()
        if qid in seen_query_ids:
            fail()
        seen_query_ids.add(qid)

        tags = q["tags"]
        if type(tags) is not list:
            fail()
        if len(tags) > 1000:
            fail()
        for tag in tags:
            if not validate_string(tag):
                fail()

        parsed_queries.append({
            "id": qid,
            "tags_set": set(tags),
        })

    decisions = []
    for q in parsed_queries:
        q_tags = q["tags_set"]
        matching = [
            r for r in parsed_rules
            if r["requires_set"].issubset(q_tags)
        ]
        if not matching:
            decisions.append({"id": q["id"], "rule": None})
        else:
            best = min(matching, key=lambda r: (-r["priority"], r["name"]))
            decisions.append({"id": q["id"], "rule": best["name"]})

    output = {"decisions": decisions}
    sys.stdout.write(json.dumps(output, separators=(',', ':')) + '\n')
    sys.exit(0)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        fail()
