Public synthetic facts for D-F-synthetic. No observed outcomes or normative approval.
