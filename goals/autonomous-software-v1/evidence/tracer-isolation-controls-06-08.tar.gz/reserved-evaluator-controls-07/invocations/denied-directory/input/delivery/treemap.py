import os
try: os.listdir('/fixture/root/denied')
except PermissionError:
    import sys
    sys.stderr.write('{"error":"invalid_input"}\n')
    raise SystemExit(2)
else: raise AssertionError('expected denied directory')
