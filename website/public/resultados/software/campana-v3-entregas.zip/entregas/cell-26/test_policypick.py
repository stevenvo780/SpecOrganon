import json
import os
import subprocess
import sys
import unittest

POLICYPICK_PATH = os.environ.get(
    "POLICYPICK_PATH",
    "/input/delivery/policypick.py"
    if os.path.exists("/input/delivery/policypick.py")
    else os.path.join(os.path.dirname(__file__), "policypick.py"),
)


class TestPolicyPick(unittest.TestCase):
    def run_proc(self, stdin_bytes, args=None):
        cmd = [sys.executable, "-E", "-s", "-B", POLICYPICK_PATH]
        if args:
            cmd.extend(args)
        p = subprocess.run(
            cmd,
            input=stdin_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return p.returncode, p.stdout, p.stderr

    def test_example_1(self):
        payload = {
            "rules": [
                {"name": "default", "priority": 0, "requires": []},
                {"name": "staff", "priority": 2, "requires": ["internal"]},
            ],
            "queries": [
                {"id": "q1", "tags": ["internal", "internal"]},
                {"id": "q2", "tags": []},
            ],
        }
        rc, out, err = self.run_proc(json.dumps(payload).encode("utf-8"))
        self.assertEqual(rc, 0)
        self.assertEqual(err, b"")
        self.assertEqual(
            out,
            b'{"decisions":[{"id":"q1","rule":"staff"},{"id":"q2","rule":"default"}]}\n',
        )

    def test_example_2_tiebreaker(self):
        payload = {
            "rules": [
                {"name": "z", "priority": 3, "requires": ["x"]},
                {"name": "A", "priority": 3, "requires": ["x"]},
            ],
            "queries": [
                {"id": "yes", "tags": ["x"]},
                {"id": "no", "tags": []},
            ],
        }
        rc, out, err = self.run_proc(json.dumps(payload).encode("utf-8"))
        self.assertEqual(rc, 0)
        self.assertEqual(err, b"")
        self.assertEqual(
            out,
            b'{"decisions":[{"id":"yes","rule":"A"},{"id":"no","rule":null}]}\n',
        )

    def test_empty_queries(self):
        payload = {"rules": [{"name": "r1", "priority": 1, "requires": []}], "queries": []}
        rc, out, err = self.run_proc(json.dumps(payload).encode("utf-8"))
        self.assertEqual(rc, 0)
        self.assertEqual(err, b"")
        self.assertEqual(out, b'{"decisions":[]}\n')

    def test_empty_rules(self):
        payload = {"rules": [], "queries": [{"id": "q1", "tags": ["x"]}]}
        rc, out, err = self.run_proc(json.dumps(payload).encode("utf-8"))
        self.assertEqual(rc, 0)
        self.assertEqual(err, b"")
        self.assertEqual(out, b'{"decisions":[{"id":"q1","rule":null}]}\n')

    def test_cli_arguments_rejected(self):
        rc, out, err = self.run_proc(b"", args=["--help"])
        self.assertEqual(rc, 2)
        self.assertEqual(out, b"")
        self.assertEqual(err, b'{"error":"invalid_input"}\n')

    def test_empty_stdin_rejected(self):
        rc, out, err = self.run_proc(b"")
        self.assertEqual(rc, 2)
        self.assertEqual(out, b"")
        self.assertEqual(err, b'{"error":"invalid_input"}\n')

    def test_stdin_over_65536_bytes(self):
        payload = json.dumps({"rules": [], "queries": []}).encode("utf-8")
        oversized = payload + b" " * (65537 - len(payload))
        rc, out, err = self.run_proc(oversized)
        self.assertEqual(rc, 2)
        self.assertEqual(out, b"")
        self.assertEqual(err, b'{"error":"invalid_input"}\n')

    def test_bom_and_null_bytes_rejected(self):
        valid = json.dumps({"rules": [], "queries": []}).encode("utf-8")
        rc, out, err = self.run_proc(b"\xef\xbb\xbf" + valid)
        self.assertEqual(rc, 2)
        rc, out, err = self.run_proc(b"\x00" + valid)
        self.assertEqual(rc, 2)

    def test_duplicate_json_keys(self):
        raw = b'{"rules":[],"rules":[],"queries":[]}'
        rc, out, err = self.run_proc(raw)
        self.assertEqual(rc, 2)

    def test_priority_validation(self):
        for bad_p in [True, False, 1.5, "10", 1000000001, -1000000001]:
            val_str = json.dumps(bad_p)
            raw = f'{{"rules":[{{"name":"r","priority":{val_str},"requires":[]}}],"queries":[]}}'.encode("utf-8")
            rc, out, err = self.run_proc(raw)
            self.assertEqual(rc, 2, f"Failed for priority {bad_p}")

    def test_string_length_and_controls(self):
        long_name = "a" * 65
        payload = {"rules": [{"name": long_name, "priority": 0, "requires": []}], "queries": []}
        rc, out, err = self.run_proc(json.dumps(payload).encode("utf-8"))
        self.assertEqual(rc, 2)

        payload_empty = {"rules": [{"name": "", "priority": 0, "requires": []}], "queries": []}
        rc, out, err = self.run_proc(json.dumps(payload_empty).encode("utf-8"))
        self.assertEqual(rc, 2)

        raw_cr = b'{"rules":[{"name":"a\\r","priority":0,"requires":[]}],"queries":[]}'
        rc, out, err = self.run_proc(raw_cr)
        self.assertEqual(rc, 2)

    def test_duplicate_identifiers(self):
        payload_dup_rules = {
            "rules": [
                {"name": "r1", "priority": 1, "requires": []},
                {"name": "r1", "priority": 2, "requires": []},
            ],
            "queries": [],
        }
        rc, out, err = self.run_proc(json.dumps(payload_dup_rules).encode("utf-8"))
        self.assertEqual(rc, 2)

        payload_dup_queries = {
            "rules": [],
            "queries": [{"id": "q1", "tags": []}, {"id": "q1", "tags": []}],
        }
        rc, out, err = self.run_proc(json.dumps(payload_dup_queries).encode("utf-8"))
        self.assertEqual(rc, 2)

    def test_duplicate_tags_and_requires_valid(self):
        payload = {
            "rules": [{"name": "r1", "priority": 1, "requires": ["a", "a", "b"]}],
            "queries": [{"id": "q1", "tags": ["b", "a", "b", "c"]}],
        }
        rc, out, err = self.run_proc(json.dumps(payload).encode("utf-8"))
        self.assertEqual(rc, 0)
        self.assertEqual(out, b'{"decisions":[{"id":"q1","rule":"r1"}]}\n')

    def test_extra_and_missing_keys(self):
        rc, _, _ = self.run_proc(b'{"rules":[]}')
        self.assertEqual(rc, 2)
        rc, _, _ = self.run_proc(b'{"rules":[],"queries":[],"extra":1}')
        self.assertEqual(rc, 2)
        rc, _, _ = self.run_proc(b'{"rules":[{"name":"r","priority":1,"requires":[],"extra":2}],"queries":[]}')
        self.assertEqual(rc, 2)


if __name__ == "__main__":
    unittest.main()
