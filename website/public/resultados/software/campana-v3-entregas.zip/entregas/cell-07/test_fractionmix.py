import json
import random
import subprocess
import sys
import unittest
from fractions import Fraction

sys.set_int_max_str_digits(0)
COMMAND = ['/opt/specorganon/venv/bin/python', '-E', '-s', '-B', '/input/delivery/fractionmix.py']
ERROR = b'{"error":"invalid_input"}\n'


class FractionMixTests(unittest.TestCase):
    def invoke(self, raw):
        return subprocess.run(COMMAND, input=raw, capture_output=True, timeout=3)

    def success(self, raw, expected):
        result = self.invoke(raw)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, b'')
        self.assertTrue(result.stdout.startswith(b'{'))
        self.assertTrue(result.stdout.endswith(b'}\n'))
        self.assertLessEqual(len(result.stdout), 2 * 1024 * 1024)
        def unique(pairs):
            obj = {}
            for key, value in pairs:
                self.assertNotIn(key, obj)
                obj[key] = value
            return obj
        def constant(value):
            self.fail('Non-JSON output constant: ' + value)
        obj = json.loads(result.stdout.decode('utf-8'), object_pairs_hook=unique, parse_constant=constant)
        self.assertIs(type(obj), dict)
        self.assertEqual(set(obj), {'numerator', 'denominator', 'term_count'})
        for value in obj.values():
            self.assertIs(type(value), int)
        self.assertEqual(obj, expected)

    def terms(self, pairs):
        total = sum((Fraction(n, d) for n, d in pairs), Fraction())
        raw = json.dumps({'terms': [{'numerator': n, 'denominator': d} for n, d in pairs]}).encode()
        self.success(raw, dict(numerator=total.numerator, denominator=total.denominator, term_count=len(pairs)))

    def test_examples_and_arithmetic(self):
        for pairs in [[], [(1, 2), (1, 3)], [(2, 4), (-1, 2)], [(0, 7), (1, 3), (1, 3)], [(-7, 6), (1, 4)], [(1000000000, 1)] * 3, [(-1000000000, 1000000000)], [(1000000000, 999999999), (-999999999, 1000000000)]]:
            with self.subTest(pairs=pairs):
                self.terms(pairs)
        self.success(b' \t\r\n{"te\\u0072ms":[{"denominator":2,"numer\\u0061tor":-0}]}\n', dict(numerator=0, denominator=1, term_count=1))

    def test_order_and_exactness(self):
        rng = random.Random(917)
        pairs = [(rng.randint(-1000000000, 1000000000), rng.randint(1, 1000000000)) for _ in range(60)]
        self.terms(pairs)
        self.terms(list(reversed(pairs)))
        self.terms([(0, 1000000000)] * 1000)

    def test_byte_boundary(self):
        raw = b'{"terms":[]}'
        self.success(raw + b' ' * (65536 - len(raw)), dict(numerator=0, denominator=1, term_count=0))
        self.invalid(raw + b' ' * (65537 - len(raw)))

    def invalid(self, raw):
        result = self.invoke(raw)
        self.assertEqual((result.returncode, result.stdout, result.stderr), (2, b'', ERROR))

    def test_invalid_documents(self):
        cases = [b'', b' \t\r\n', b'null', b'[]', b'1', b'{}', b'{"terms":null}', b'{"terms":{}}', b'{"terms":[],"extra":0}', b'{"terms":[]} {}', b'{"terms":[],}', b'{"terms":[]}\xff', b'\xef\xbb\xbf{"terms":[]}', b'{"terms":[]}\x00', b'{"terms":[]}\xc0\af', b'{"terms":[]}\xc2\xa0', b'{"terms":[],"terms":[]}', b'{"terms":[],"te\\u0072ms":[]}', b'{"terms":[{"numerator":1,"numer\\u0061tor":2,"denominator":3}]}', b'{"terms":[],"extra":{"x":1,"x":2}}']
        for raw in cases:
            with self.subTest(raw=raw):
                self.invalid(raw)
        self.invalid(json.dumps({'terms': [{'numerator': 0, 'denominator': 1}] * 1001}).encode())

    def test_invalid_terms(self):
        for term in ['null', '[]', '1', '{}', '{"numerator":1}', '{"denominator":1}', '{"numerator":0,"denominator":1,"x":0}']:
            self.invalid(('{"terms":[' + term + ']}').encode())
        for key, values in [('numerator', ['true', 'false', 'null', '"1"', '1.0', '1e0', 'NaN', 'Infinity', '-Infinity', '1000000001', '-1000000001']), ('denominator', ['true', 'false', 'null', '"1"', '1.0', '1e0', '0', '-1', '1000000001'])]:
            for value in values:
                with self.subTest(key=key, value=value):
                    term = '{"numerator":' + (value if key == 'numerator' else '0') + ',"denominator":' + (value if key == 'denominator' else '1') + '}'
                    self.invalid(('{"terms":[{"numerator":1,"denominator":2},{"numerator":-1,"denominator":2},' + term + ']}').encode())

    def test_arguments_before_stdin(self):
        for arg in ['--help', 'extra', '']:
            with self.subTest(arg=arg):
                with subprocess.Popen(COMMAND + [arg], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as proc:
                    try:
                        proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.communicate()
                        self.fail('Argument rejection waited for stdin EOF')
                    out, err = proc.communicate()
                    self.assertEqual((proc.returncode, out, err), (2, b'', ERROR))

    def test_more_than_4300_digits(self):
        def prime(n):
            d, s = n - 1, 0
            while d % 2 == 0:
                d //= 2
                s += 1
            for a in (2, 7, 61):
                x = pow(a, d, n)
                if x in (1, n - 1):
                    continue
                for _ in range(s - 1):
                    x = x * x % n
                    if x == n - 1:
                        break
                else:
                    return False
            return True
        denominators = []
        candidate = 999999999
        while len(denominators) < 490:
            if prime(candidate):
                denominators.append(candidate)
            candidate -= 2
        total = sum((Fraction(1, d) for d in denominators), Fraction())
        self.assertGreater(len(str(total.denominator)), 4300)
        self.terms([(1, d) for d in denominators])


if __name__ == '__main__':
    unittest.main()
