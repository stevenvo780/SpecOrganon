#!/usr/bin/env python3
import sys
import json


def fail():
    sys.stderr.write('{"error":"invalid_input"}\n')
    sys.stderr.flush()
    sys.exit(2)


def main():
    if len(sys.argv) > 1:
        fail()

    raw = sys.stdin.buffer.read(65537)
    if len(raw) > 65536:
        fail()

    if b'\x00' in raw or raw.startswith(b'\xef\xbb\xbf'):
        fail()

    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError:
        fail()

    def pairs_hook(pairs):
        keys = set()
        d = {}
        for k, v in pairs:
            if k in keys:
                raise ValueError("duplicate key")
            keys.add(k)
            d[k] = v
        return d

    def no_constants(c):
        raise ValueError("constants not allowed")

    def no_floats(f):
        raise ValueError("floats not allowed")

    try:
        doc = json.loads(
            text,
            object_pairs_hook=pairs_hook,
            parse_constant=no_constants,
            parse_float=no_floats,
        )
    except Exception:
        fail()

    if type(doc) is not dict:
        fail()

    if set(doc.keys()) != {"items", "operations"}:
        fail()

    items = doc["items"]
    operations = doc["operations"]

    if type(items) is not list or len(items) > 1000:
        fail()

    for x in items:
        if type(x) is not int or x < -1000000000 or x > 1000000000:
            fail()

    if type(operations) is not list or len(operations) > 1000:
        fail()

    for op in operations:
        if type(op) is not dict:
            fail()
        if "op" not in op or type(op["op"]) is not str:
            fail()
        name = op["op"]
        if name == "insert":
            if set(op.keys()) != {"op", "index", "value"}:
                fail()
            idx = op["index"]
            val = op["value"]
            if type(idx) is not int or idx < 0 or idx > 1000:
                fail()
            if type(val) is not int or val < -1000000000 or val > 1000000000:
                fail()
        elif name == "replace":
            if set(op.keys()) != {"op", "index", "value"}:
                fail()
            idx = op["index"]
            val = op["value"]
            if type(idx) is not int or idx < 0 or idx > 1000:
                fail()
            if type(val) is not int or val < -1000000000 or val > 1000000000:
                fail()
        elif name == "delete":
            if set(op.keys()) != {"op", "index"}:
                fail()
            idx = op["index"]
            if type(idx) is not int or idx < 0 or idx > 1000:
                fail()
        else:
            fail()

    curr = list(items)
    for op in operations:
        name = op["op"]
        idx = op["index"]
        if name == "insert":
            if idx > len(curr) or len(curr) >= 1000:
                fail()
            curr.insert(idx, op["value"])
        elif name == "replace":
            if idx >= len(curr):
                fail()
            curr[idx] = op["value"]
        elif name == "delete":
            if idx >= len(curr):
                fail()
            del curr[idx]

    out_obj = {
        "items": curr,
        "applied": len(operations)
    }
    sys.stdout.write(json.dumps(out_obj, separators=(',', ':')) + "\n")
    sys.stdout.flush()
    sys.exit(0)


if __name__ == '__main__':
    main()
