# PolicyPick

PolicyPick resolves query tags against prioritized rules using strict subset matching and deterministic Unicode tie-breaking.

## Installation & Requirements
- Requires Python 3.12 (standard library only, no external dependencies).
- Expected execution path:
  `/opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py`

## Interface & Execution
- Invocation must have no command-line arguments. Supplying any argument (even `--help`) immediately exits with status 2 and invalid input error.
- Input is read entirely from standard input (maximum 65536 bytes).
- Input must be a single strict UTF-8 JSON object without BOM, raw NUL bytes, duplicate keys, or NaN/Infinity.
- Output on success: exit 0, empty stderr, stdout contains exact JSON object followed by a single LF with no external whitespace:
  `{"decisions":[{"id":id,"rule":name_or_null},...]}`
- Output on error: exit 2, empty stdout, stderr contains exact JSON object followed by LF:
  `{"error":"invalid_input"}\n`

## Limits & Schema Formats
- Top-level object exact keys: `{"rules":[...],"queries":[...]}`.
- Maximum 1000 rules and maximum 1000 queries.
- Rule object exact keys: `{"name":string,"priority":int,"requires":[strings]}`.
- Query object exact keys: `{"id":string,"tags":[strings]}`.
- `priority` must be an integer between -1000000000 and 1000000000 (no floats, booleans, or strings).
- `requires` and `tags` lists may have at most 1000 elements each.
- Strings (names, IDs, requirements, tags) must be non-empty, at most 64 UTF-8 encoded bytes, with no NUL, CR, or LF characters, and no unencodable surrogates.
- Rule names must be unique within rules. Query IDs must be unique within queries.
- Whitespace, capitalization, and Unicode are literal with no trimming or normalization.
- Duplicate entries in `requires` and `tags` are permitted and treated as sets.

## Semantics & Tie-Breaking
- A rule matches a query if all items in its `requires` list are present in the query's `tags` set.
- An empty `requires` list matches any query.
- Unknown or unused tags in a query are ignored.
- The matched rule with the highest `priority` is selected.
- Ties in priority are broken by choosing the rule whose `name` is smallest in Unicode code point order.
- If no rule matches, `rule` is `null`.
- Queries are evaluated and returned in their original input order.

## Public Examples

### Example 1
Command:
```bash
printf '{"rules":[{"name":"default","priority":0,"requires":[]},{"name":"staff","priority":2,"requires":["internal"]}],"queries":[{"id":"q1","tags":["internal","internal"]},{"id":"q2","tags":[]}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py
```
Stdout:
```json
{"decisions":[{"id":"q1","rule":"staff"},{"id":"q2","rule":"default"}]}
```

### Example 2
Command:
```bash
printf '{"rules":[{"name":"z","priority":3,"requires":["x"]},{"name":"A","priority":3,"requires":["x"]}],"queries":[{"id":"yes","tags":["x"]},{"id":"no","tags":[]}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py
```
Stdout:
```json
{"decisions":[{"id":"yes","rule":"A"},{"id":"no","rule":null}]}
```

## Executable Test Command
Run the following bash pipeline to verify both valid public examples and invalid argument rejection:
```bash
python3 policypick.py --help 2>&1 | grep -q '{"error":"invalid_input"}' && \
printf '{"rules":[],"queries":[]}' | python3 policypick.py | grep -q '{"decisions":[]}' && \
echo "All smoke tests passed"
```
