# Evidencia de la campaña v3 original

42 celdas originales, tres tareas, dos familias, dos repeticiones, N/S/T/A.
El informe conserva 3500 resultados contractuales; los programas ausentes
fallan sin ejecutar sujetos. Las invocaciones físicas tienen recibos separados.
No son 3500 replicaciones de autor ni una prueba de superioridad causal general.

El informador primario terminó exit1 y report.json sigue ausente.
closure/report-posthoc-v1.json aplica la regla registrada evidencia ausente=0
a dos puntos G/g4 pass con stdout vacío. Conserva aserción y verificación
por separado y examina todos los pass. No repite sujetos ni revisores.
Los registros, entregas y fuentes congeladas se copian con sus bytes originales.
Los archivos bajo original conservan sus nombres y sus referencias históricas.
Los recibos y observadores son un extracto público; los perfiles, credenciales,
cuotas privadas y journals nativos completos permanecen fuera de este paquete.
La custodia depende del operador y del sistema de archivos. Los hashes no
prueban por sí solos la verdad de un juicio semántico ni una identidad externa.

El ZIP del toolkit rc2 separado incluye construcción Docker e instrucciones
CLI/MCP verificadas. Estas fuentes congeladas corresponden a la campaña anterior
al empaquetado de versión; SOURCE-MANIFEST identifica ambos alcances por separado.
El registro original incluye rutas e imágenes originales y no se puede trasladar
para continuar o reemplazar la campaña desde una máquina nueva. Una generación
independiente necesita otro registro previo y sus propias cuentas y presupuestos.

Para reproducir el análisis descriptivo sin modelos ni nuevos sujetos:
python analyze_recorded.py
El script verifica todos los archivos del manifest y recalcula diferencias y
estratos desde las 42 filas originales. No repite programas, no repara entregas
ni cambia puntuaciones. Los programas sellados están en original/deliveries.

Las aprobaciones locales conservan un mandato declarado. Las pruebas del toolkit
con fixtures y perturbaciones sintéticas se identifican en sus recibos separados;
no cuentan como casos nativos adicionales. Tokens normalizados y coste monetario
son desconocidos. El hito de software no demuestra eficacia alimentaria de campo
ni la tesis general.
