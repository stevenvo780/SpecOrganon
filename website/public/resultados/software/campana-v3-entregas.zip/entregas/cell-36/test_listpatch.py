import json
import os
import subprocess
import sys
import unittest

TARGET = os.environ.get("LISTPATCH_PATH", "/input/delivery/listpatch.py")
PYTHON = sys.executable


def run_listpatch(payload_bytes=b"", args=None):
    cmd = [PYTHON, "-E", "-s", "-B", TARGET]
    if args:
        cmd.extend(args)
    proc = subprocess.run(
        cmd,
        input=payload_bytes,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return proc.returncode, proc.stdout, proc.stderr


def run_json(obj, args=None, raw_text=None):
    if raw_text is not None:
        payload = raw_text.encode("utf-8")
    else:
        payload = json.dumps(obj).encode("utf-8")
    return run_listpatch(payload, args=args)


class TestListPatch(unittest.TestCase):
    def assert_invalid(self, code, out, err):
        self.assertEqual(code, 2)
        self.assertEqual(out, b"")
        self.assertEqual(err, b'{"error":"invalid_input"}\n')

    def assert_success(self, code, out, err, expected_items, expected_applied):
        self.assertEqual(code, 0)
        self.assertEqual(err, b"")
        expected_payload = json.dumps(
            {"items": expected_items, "applied": expected_applied},
            separators=(",", ":"),
        ).encode("utf-8") + b"\n"
        self.assertEqual(out, expected_payload)

    def test_example1(self):
        doc = {
            "items": [10, 20],
            "operations": [
                {"op": "insert", "index": 1, "value": 15},
                {"op": "replace", "index": 0, "value": 9},
                {"op": "delete", "index": 2},
            ],
        }
        code, out, err = run_json(doc)
        self.assert_success(code, out, err, [9, 15], 3)

    def test_example2(self):
        doc = {
            "items": [],
            "operations": [
                {"op": "insert", "index": 0, "value": -2},
                {"op": "delete", "index": 0},
            ],
        }
        code, out, err = run_json(doc)
        self.assert_success(code, out, err, [], 2)

    def test_argv_disallowed(self):
        for arg in [["--help"], ["-v"], ["foo"]]:
            code, out, err = run_listpatch(b'{"items":[],"operations":[]}', args=arg)
            self.assert_invalid(code, out, err)

    def test_stdin_size_limit(self):
        big_spaces = b" " * 65537
        code, out, err = run_listpatch(big_spaces)
        self.assert_invalid(code, out, err)

    def test_bom_and_null_bytes(self):
        code, out, err = run_listpatch(b"\xef\xbb\xbf{" + b'"items":[],"operations":[]}')
        self.assert_invalid(code, out, err)
        code, out, err = run_listpatch(b'{"items":[0],\x00"operations":[]}')
        self.assert_invalid(code, out, err)

    def test_invalid_utf8(self):
        code, out, err = run_listpatch(b"\xff\xfe\xfd")
        self.assert_invalid(code, out, err)

    def test_duplicate_keys(self):
        raw = '{"items":[1],"items":[1],"operations":[]}'
        code, out, err = run_listpatch(raw.encode("utf-8"))
        self.assert_invalid(code, out, err)

        raw_op = '{"items":[],"operations":[{"op":"delete","index":0,"op":"delete"}]}'
        code, out, err = run_listpatch(raw_op.encode("utf-8"))
        self.assert_invalid(code, out, err)

    def test_constants_and_floats(self):
        raw_nan = '{"items":[NaN],"operations":[]}'
        code, out, err = run_listpatch(raw_nan.encode("utf-8"))
        self.assert_invalid(code, out, err)

        raw_float = '{"items":[1.5],"operations":[]}'
        code, out, err = run_listpatch(raw_float.encode("utf-8"))
        self.assert_invalid(code, out, err)

        raw_op_float = '{"items":[],"operations":[{"op":"insert","index":0,"value":1.0}]}'
        code, out, err = run_listpatch(raw_op_float.encode("utf-8"))
        self.assert_invalid(code, out, err)

    def test_boolean_types_rejected(self):
        raw_bool_item = '{"items":[true],"operations":[]}'
        code, out, err = run_listpatch(raw_bool_item.encode("utf-8"))
        self.assert_invalid(code, out, err)

        raw_bool_idx = '{"items":[1],"operations":[{"op":"delete","index":false}]}'
        code, out, err = run_listpatch(raw_bool_idx.encode("utf-8"))
        self.assert_invalid(code, out, err)

        raw_bool_val = '{"items":[],"operations":[{"op":"insert","index":0,"value":true}]}'
        code, out, err = run_listpatch(raw_bool_val.encode("utf-8"))
        self.assert_invalid(code, out, err)

    def test_concatenated_json_rejected(self):
        raw = '{"items":[],"operations":[]}{"items":[],"operations":[]}'
        code, out, err = run_listpatch(raw.encode("utf-8"))
        self.assert_invalid(code, out, err)

    def test_root_structure_and_keys(self):
        code, out, err = run_json([])
        self.assert_invalid(code, out, err)
        code, out, err = run_json({"items": []})
        self.assert_invalid(code, out, err)
        code, out, err = run_json({"items": [], "operations": [], "extra": 1})
        self.assert_invalid(code, out, err)

    def test_integer_bounds(self):
        code, out, err = run_json({"items": [-1000000000, 1000000000], "operations": []})
        self.assert_success(code, out, err, [-1000000000, 1000000000], 0)

        code, out, err = run_json({"items": [-1000000001], "operations": []})
        self.assert_invalid(code, out, err)
        code, out, err = run_json({"items": [1000000001], "operations": []})
        self.assert_invalid(code, out, err)

    def test_list_length_limit(self):
        code, out, err = run_json({"items": [0] * 1001, "operations": []})
        self.assert_invalid(code, out, err)
        code, out, err = run_json({"items": [], "operations": [{"op": "delete", "index": 0}] * 1001})
        self.assert_invalid(code, out, err)

    def test_insert_capacity_limit(self):
        items = [1] * 1000
        doc = {"items": items, "operations": [{"op": "insert", "index": 0, "value": 2}]}
        code, out, err = run_json(doc)
        self.assert_invalid(code, out, err)

    def test_operations_semantics(self):
        doc_remove = {"items": [1], "operations": [{"op": "remove", "index": 0}]}
        code, out, err = run_json(doc_remove)
        self.assert_invalid(code, out, err)

        doc_delete_extra = {"items": [1], "operations": [{"op": "delete", "index": 0, "value": 1}]}
        code, out, err = run_json(doc_delete_extra)
        self.assert_invalid(code, out, err)

        doc_idx_oob = {"items": [1], "operations": [{"op": "replace", "index": 1, "value": 2}]}
        code, out, err = run_json(doc_idx_oob)
        self.assert_invalid(code, out, err)

        doc_insert_oob = {"items": [1], "operations": [{"op": "insert", "index": 2, "value": 2}]}
        code, out, err = run_json(doc_insert_oob)
        self.assert_invalid(code, out, err)

        doc_atomic = {
            "items": [10],
            "operations": [
                {"op": "insert", "index": 1, "value": 20},
                {"op": "delete", "index": 5},
            ],
        }
        code, out, err = run_json(doc_atomic)
        self.assert_invalid(code, out, err)

    def test_whitespace_tolerance(self):
        raw = " \n\t {\"items\": [ 1 ], \"operations\": [ ] } \n "
        code, out, err = run_listpatch(raw.encode("utf-8"))
        self.assert_success(code, out, err, [1], 0)


if __name__ == "__main__":
    unittest.main()
