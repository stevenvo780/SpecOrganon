# Auditoría de aceptación actual

## Hito del MVP local

El [dossier](../experiments/development/mvp_local_2026-10-01/results.md)
registra dos proyectos expuestos con nueve fases aceptadas, revisión nativa
real, reproducción escolar exacta, replay sin duplicados e invalidación de
dependencias al cambiar una hipótesis. El nuevo modo `local` y `report`
pasaron interfaces CLI/MCP reales y controles de regresión. La confianza se
declara local; no se autentican personas ni campo.

**El MVP está disponible para uso técnico local.** Esto no cierra C2–C5, ni
convierte los proyectos en casos reservados. D107 mantiene su veredicto
histórico C1; el wheel del MVP descubrió 24 herramientas y comprobó report y
replay de los nuevos proyectos fuera del árbol. Los apartados siguientes
conservan la evidencia y condiciones de sus cortes anteriores.

## D-124 · Ingreso de declaraciones de evaluación DEV

[Dossier](../experiments/development/external_rating_ingress_2026-10-01/README.md):
API pura y CLI real de lectura privada; forma cerrada, SHA de originales y
referencias públicas fijas, sin escribir notas normalizadas. Cinco componentes
enteros0..20; suma e incidentes separados. Declaraciones bool/null no autentican
humanos ni custodia. Q/calidad/aceptación/celda formal false, sin imponer reglas
nuevas del panel confirmatorio a DEV.

Plan776710a/freeze4459ae2,87pruebas por Python3.11/3.12 y estáticos0.
Catorce lecturas definitivas: seis aceptadas/ocho rechazadas; todos controles
sintéticos. Suma100 conserva incidente visible; bytes distintos de valores
iguales ligan SHA distintos; unknown y cuatro errores CLI tratados. Fuentes,
HEAD y snapshots before/after iguales; archivos21miembros por intérprete
cotejados contra originales.19archivos draft/22miembros preservados.
Revisión detectó P2 de destinos `..`; fix temprano y siete variantes sin efectos
verificados por worker/revisor, fuente/probe/freeze/capturas anteriores intactos.
D123725 registros live+4docs históricos Git7d5a, recibo y herencia preservados.

**C1 técnico D107; C2–C5 No demostrado; 0/24 formales.** No nuevas notas humanas,
API experimental ni credenciales. Lectura cooperativa mismoUID no aporta
custodia autenticada o snapshot global atómico. Siguen personas, elección/
autorización/acceso, modelos/uso/H/costos reales; después confirmación/campo/
transferencia. Los cortes siguientes conservan su alcance histórico.
El dueño indica un revisor y custodio disponibles; la separación de personas
y sus condiciones no están verificadas. El panel confirmatorio sigue pendiente.

## D-123 · Entrada controlada y desenlaces indeterminados

[Dossier](../experiments/development/authorized_route_entry_2026-10-01/README.md):
controlador separado sin modificar guards/ledger/claim/observación sellados.
Step real exige flag/declaración privada exacta y origen oficial fijo; clave
tras gates. Check dentro del hilo antes de I/O cierra carrera reproducida.
Espera local≤90/deadline nativo, sin cancelación remota garantizada.
Lector conserva reservas; uso/precio declarado no es factura ni costo completo.
Guard indeterminate no se declara replay completo ni autoriza reejecución.

Plan080acba/freeze7246936,74pruebas por Python3.11/3.12 y estáticos0.
Seis controles completos A/B/C,146CLI/110sends completos de fixture;
dos incomplete adicionales retienen133tokens/133µUSD cada uno y reportan
7µUSD de uso declarado, sin sumar esas columnas. Ruta OpenAI sin permiso
rechazada sin cambios. Fuentes before/after y archivos bytes/modos intactos;
D1215875/D122121 pins+recibos preservados, cuatro docs históricos Git antes
de avanzar este corte. Lifecycle inicial y dos timeouts600s se conservan;
ninguno cuenta como PASS. Capturas03 completas pasan.

**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.**
Sin proveedor real/claves/Q/autoridad/campo. Acceso/elección/gasto/snapshot/
effort efectivo/telemetría/H y costos completos pendientes. Ingreso de
evaluaciones externas puede prepararse localmente, sin inventar puntuaciones.
Los cortes siguientes conservan su alcance histórico.

## D-122 · Propuesta de ruta real, sin R1

[Dossier](../experiments/development/real_route_proposal_2026-10-01/README.md):
cuatro build/verify originales —Astra/Luna `high` × Python 3.11/3.12—,
configuración nativa validada para doce celdas en cada uno; no runtimes,
claims, conteos/envíos remotos ni nuevas celdas formales. Precios actuales
separados de cotas condicionales del modelo; costes completos y calidad
desconocidos. No se suman ambas opciones, no hay selección ni gasto autorizado.

Los 5.879 pins+receipt D121 pasan antes/después del build; cuatro docs
activos históricos en `9f90b79` antes de este corte. Las rutas `step` siguen
fixture; acceso real, snapshot, esfuerzo efectivo, conteo/uso/incomplete,
capacidad `high`/8192 y evaluación independiente deben cerrarse antes de R1.
Documentación/API pública no acredita acceso de cuenta ni factura.
**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.**

## D-121 · Observación prospectiva local

[Dossier](../experiments/development/coordinated_observation_2026-10-01/README.md).
Journal/clocks/boot y callbacks observados sin modificar fuentes D119/D120.
Release sólo preparado/cursor0 sin requests/tools, protegido por lock original;
el precheck valida delegación/merge/delivery y métricas antes de efectos.
Deadline previo a I/O, proxy de protocolo y broker real por instancia. Fallo
activo no se reanuda; callback tardía no escribe. D120 y guard/replay/publicación
nativos cotejan cobertura exacta y containment de send. API pura no autentica guard.

Freeze `892d6a8`, 104 registros + extractor; **88 pruebas por Python 3.11/3.12**,
Ruff/sintaxis/diff 0, freeze/HEAD before/after iguales. Seis runtimes nuevos
A/B/C × D-E: 118 CLI/110 count/110 send/66 tools originales, 770 tokens
sintéticos; dos releases retrospectivos rechazados sin crear observador.
Baseline D119/D120 2283/2439 pins incluyendo versiones Git de docs y doce
inventarios originales intactos. Dos archives ×1369 entradas cotejadas por
bytes/modos/membresía/raíces. Historial de fallos y fuentes preservado.

W es elapsed local identificado de liberación a marca de entrega verificada,
con guard/I/O/pausas; no recepción externa ni CPU/remoto. Sumas/uniones
separadas por kind/rol; tool host/sandbox son subconjuntos, no adiciones.
**C1 técnico preservado; C2–C5 No demostrado; 0/24 formales.** Sin Q, factura/
effort/proveedor autenticados, autoridad, campo o reserva. H/remoto/costes
completos/ruta y autorización real siguen pendientes. No ventaja comparativa
inferida. Los cortes siguientes mantienen sus límites históricos.

## D-120 · Conciliación de mediciones locales

[Dossier](../experiments/development/coordinated_measurement_2026-10-01/README.md).
Lector independiente: una captura bajo lock original, guard/replay/publicación
D119, uso y liquidación concordantes, coste declarado redondeado por request,
herramientas ligadas y tiempos locales separados. Salida por allowlist, sin
prompts/RAW textual/argumentos. Caché y razonamiento son subconjuntos;
ausencia desconocida, no cero. La API pura no prueba ejecución del guard.

Freeze `8576cc6`: 92 registros y 93 con el propio freeze; **51 pruebas por Python 3.11/3.12**,
Ruff/sintaxis/diff exit 0 y fuentes/HEAD estables. Doce lecturas CLI reales de los
runtimes sintéticos D119: 113 requests, 69 tools y 791 tokens declarados por entorno,
calendarios distintos. Inventarios before/after iguales; 2283 pins D119
preservados durante capturas. Cuatro docs activos avanzan después, con bytes
históricos conservados enGit `c64169c`. Tres huecos PURE cerrados; no bypass
CLI afirmado. El primer intento conserva hashes pero no fuentes originales;
los siguientes sí. Revisión y receipt en el dossier.

**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.**
Sin nuevos sends/tools ni modelo experimental. W/H, conteo/actividad remota,
costes de herramientas/revisión/puntuación/estudio, proveedor/effort/tarifa/
factura verificables y Q permanecen pendientes. No ventaja comparativa,
autoridad humana, campo o reserva demostrados. Los cortes siguientes son
históricos.

## D-119 · Runtime persistente de desarrollo coordinado

[Dossier](../experiments/development/coordinated_runtime_2026-10-01/README.md).
El runtime implementa A/B/C desde init original del líder hasta varias
delegaciones, merge, análisis final vigente y reviewer público, con el mismo
ledger/contexto/claim y contadores globales. El host impone ownership y CAS;
el análisis readonly usa herramientas originales y las métricas se retiran
cuando cambia work. La entrega requiere estructura D118 y finish exitoso.
El cierre del runtime conserva normas pendientes y no acepta automáticamente
las cuatro fases del prototipo.

Freeze corregido `7de98c9`: 82 fuentes y extractor, 125 rutas históricas
verificadas por root/revisor. Se conserva el primer freeze y sus resultados
negativos. La revisión reprodujo y cerró la diferencia entre tool_policy y
ejecutables al mezclar intérpretes: rechazo antes de IO y cotejo en reapertura.
Pasaron317pruebas por Python3.11/3.12, Ruff/sintaxis/diff0 y83fuentes
before/after idénticas. La revisión reabrió los doce runs CLI/HTTP finales:
112CLI/113sends/69tools de fixture por intérprete, claim/saldo único,
análisis final vigente e inventario original completo, reviewer sin RAW
ajeno. A3epochs serial; B/C2epochs con solapamiento HTTP local.
Archivo37raíces/53.857regulares/12.643blobs/47.929.387B SHA f7c7c884…,
18.735entradas de metadata; root cotejó bytes/modos/targets y membresía Tar
contra todos los originales, sin seguir symlinks ni abrir FIFO.

**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.**
No modelo/effort, usage, actividad remota o factura autenticados; estructura,
inventario de fuentes y HTTP local no demuestran Q ni interpretación científica,
campo, reserva o transferencia. El wheel y el producto permanecen intactos.
Los cortes siguientes son históricos.

## D-118 · Preparación coordinada común, sin nuevas celdas evaluadas

[Dossier](../experiments/development/coordinated_contract_2026-10-01/README.md).
Freeze `6a36197` conserva 62 fuentes y extractor externo; 103 rutas D117
verificadas por root y revisor. Pasaron **265 pruebas por Python 3.11/3.12**
con Ruff/compile/diff0 y fuentes estables. Se preparan 12 IDs nuevos R1 de
cuatro roles; CLI reales build/verify/validate/check cotejan 106 archivos y
seis fixtures estructurales por intérprete, sin requests de modelo.

Contrato/rúbrica e información común están implementados y ligados al
calendario. Los métodos originales y su coordinación aún necesitan runtimes
A/B y continuidad/binding C. El checker no ejecuta `analysis.py`, no autentica
metrics.json ni verifica pasajes/calidad; los valores nulos motivados no son
resultados. El freeze/prompt declarado no autoriza admisión pagada ni prueba
identidad/efectivo esfuerzo, uso o actividad. R2 permanece bloqueada.

**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.** No se
repitió instalación/global2674/wheel ni se modificó el producto. Siguen
ejecuciones comparables R1/R2, selección, reserva/custodia/jueces/autoridades,
campo y transferencia. Los cortes siguientes conservan su alcance histórico.

## D-108 · Derivación alimentaria y conservación

[Dossier](../experiments/development/bread_energy_derivation_2026-09-30/README.md):
freeze64aa0a8/89pines presentes en Git, dos intentos instalados exit0/no timeout
ni error. Mismo wheel D107/24módulos y1555archivos por venv intactos;
discovery23, cuatro positivos68eventos/prefijo64 y4puts, replay0/4.
58pares CLI/MCP por entorno (nueve gates, cuatro trazas, status/next/controles);
243registros incluyen63CLI,61MCP,1builder,60tiempos y58comparaciones.
Tres fuentes revisadas por copia invalidan los cuatro nuevos descendientes;
archivo de derivación cambiado/ausente invalida evidencia/indicador sin
eventos de consulta; restauración exacta recupera estado. Siete negativos
puros, no verificación semántica del CLI. Cuatro tests de contrato por Python,
Ruff/compile pasan; suite global2674 conserva alcance D107.

Revisión independiente recalcula432miembros de tar,58pares/128streams por
Python, cuatro cadenas positivas y seis controles69eventos,89inputs, diez
copias publicadas y racional103/184/error de representación11/(23×10^24).
Fecha de derivación UTC real distinta de publicación2018; dato empresarial
de fecha desconocida. No P1/P2 abierto en alcance revisado, cero aprobación
normativa/fase aceptada y cuatro umbrales de intervención todavía nulos.
**Aceptación1/5; C2–C5 No demostrados.** Sin Q/campo/reserva24 ni comparación
experimental nueva. La suma documental de portadores no es energía útil,
efecto causal, baseline actual o resolución de la cadena alimentaria.

Reparación Git D1076b5ccb4 conserva los dos archivos ignorados del build;
sus470pines finales coinciden con ese commit. El freeze474ed13 sólo contenía
430/432inputs: el dossier declara checkout combinado y nuevo registro para
reproducir, sin modificar resultados/freeze. Evidencias siguientes son históricas.

## D-107 · Núcleo, paquete e historia de retiro

[Evidencia](../experiments/development/indicator_retirement_2026-09-30/README.md).
Wheel137581B SHA63c58a91…:24módulos src/site y1555archivos por Python3.11.15/3.12.3
cotejados. Suite actual2674passed, Ruff/compile. 23operaciones positivas CLI/MCP
por entorno, cuatro workflows firmados con9fases sintéticas/50–51eventos, controles
y repetición real LandlockABI9. Su evaluación field sigue no_demostrado.

Retiro: dos positivos por Python,62eventos/prefijo52,9puts+retiro,
182capturas/52pares, seis controles y guards rechazados sin escritura. Origen,
tipo/rechazo conservados; reemplazos tipados y enlace D106→inferencia→síntesis;
cero fases aceptadas en Citi. Cuatro tar/596regulares y seis symlinks sólo metadata.
Revisor independiente confirma efectos/origins/cadenas/archivos/publicación;
sin P1/P2 abierto en el alcance revisado.

C1 mantiene PASS sólo en el alcance técnico inventariado del wheel actual.
C2–C5 No demostrados: tests no autentican humanidad/custodia, campo, Q o reserva24.
Restauración exacta sin evento puede recuperar snapshot/avance previo: el motor
no recuerda corrupción transitoria. Los resultados siguientes conservan sus
alcances históricos y wheels específicos.

**Fracciones y filas D-105/D-106:**
[controles instalados](../experiments/development/citibike_fraction_lineage_2026-09-30/)
y [reproducción desde raw](../experiments/development/citibike_raw_count_audit_2026-09-30/).
Mismo wheel D-102,24módulos site/src iguales, Python3.11.15/3.12.3.
Cada entorno aplica9puts CLI, replay MCP0/9,22tools y25pares CLI/MCP
byte cotejados: cinco trazas/nueve gates/estado, controles de denominador y
archive. Evidencias e indicadores tienen métrica/unidad literal común,
valor decimal24 redondeado y racional separado; error≤5e-25 sólo de
representación. Denominador con contenido idéntico revisado hace stale9
descendientes; dos siblings vigentes. Archive alterado/eliminado invalida
ramas y bloquea sin escrituras; exacta restitución recupera estado. Cuatro
negativos por Python rechazados, incluido cambio de contrato con pin viejo,
que verifica binding y no verdad semántica. Prefix42/chain52/publicación8files
verificados independientemente; cuatro tar/240archivos y176capturas.
Los dos iniciales failed quedan intactos: supuesto incorrecto42puts frente
a40puts+dos eventos históricos; reparación prospectiva en nuevo destino.
Study/explain siguen bloqueados por i_rows rechazado/síntesis sin enlace,
además de fases previas; normas/decisión sin aprobar y cero fases aceptadas.

D-106 usa el analizador histórico exacto sobre bytes Parquet de10.853.196B
sellados con15 y doble hash. Una ejecución3.11 exit0 reproduce stdout/report
histórico1599B SHA352ef988… sin cambios:1.812.548filas,1.809.036elegibles,
1.725.248/1.682.386numeradores. Entorno offline nuevo y1382dep-files actuales
verificados;30pines congelados intactos. Dos P2 de referencias/recibo cerrados
antes de ejecutar y fuente inicial conservada, no ejecutada. Revisor distinto
recalcula input/outputs/dependencias, sin reejecutar análisis. La pertenencia
verificada es del archivo y regla descriptiva, no de la realidad física;
no segunda implementación independiente, custodia externa, prerregistro del
estudio, causalidad o campo. Evidencia raw sigue separada del ledger D-105.
Ruff/compile pasan en ambos Python; sin nuevo global ni modelo experimental.
**C1 técnico conservado; C2–C5 No demostrados, aceptación actual1/5.**
La transferencia de mecanismos aquí observada es desarrollo expuesto, sin
adjudicar generalización completa. GOAL/matriz/umbrales y24módulos intactos.

**Integridad D-104:** [resultados y límites](../experiments/development/method_integrity_audit_2026-09-30/).
Regresión de desarrollo 21/21 en cada Python 3.11/3.12 sobre wheel D-102,
42 ledgers conservados/cadenas verificadas, grupos 6/6/6/3 sin skips.
E06 conserva el bloqueo tardío en specify. No es el banco sellado final C2.
Auditor de 15 objetivos separa rutas, coincidencias tipadas y metadata
provisional: cuatro indicadores nuevos del pan e i_rows Citi carecen de
evidencia con la misma métrica/unidad; masa documental tiene una. Autoridad,
derivación suficiente y umbrales siguen pendientes, sin aceptación de fase.
Tres programas conservados reciben copias con un SHA incorrecto: N/T
excepción previa a agregados, S flag falso con agregados y exit0. El contrato
permite salida diagnóstica; el comparador rechaza admisión de los tres, sin
atribuirles una decisión científica. Posthoc/expuesto, una condición por
programa, cero generaciones, sin Q/causalidad/modelo nuevo/corrida24.
Revisión independiente coteja 265 archivos en tres tar y 147 originales
D-099. Producción, GOAL y matriz intactos. **C1 técnico sigue cumplido;
C2–C5 No demostrados; aceptación actual 1/5.** Ruff/compile de instrumentos
en ambos Python, sin nueva suite global ni intervención de campo.

**Cierre D-103:** [dossier y revisión independiente](../experiments/development/installed_complete_interface_2026-09-30/).
C1 **Cumplido en alcance técnico** para el wheel D-102 en Linux con
Python 3.11.15/3.12.3: 22/22 CLI/MCP, 24 módulos actuales iguales al wheel,
workflow firmado de nueve fases/51 eventos con repetición real ABI 9 y dos
agentes nativos con cuatro escrituras guardadas por entorno. Todos los
controles críticos inventariados pasan: cliente stdio, SIGKILL, reanudación,
errores, persistencia, paridad y artefactos comprobados. Ocho tar/196 archivos
conservan evidencia y negativos originales. No se cambia GOAL ni matriz:
se corrige la atribución de pendientes humanos/confirmatorios a C1.
Firmas sintéticas, mismo UID y resumen smoke sin raw por llamada siguen
explícitos. No aprobación humana, Q, intervención o comparación final.
**Aceptación actual: 1/5; C2–C5 No demostrados.** Cortes y recibos 0/5
anteriores siguen históricos. Las 2560 pruebas globales pertenecen a D-102;
D-103 ejecutó controles integrados, Ruff y compile de sus scripts.

**Diario y borrador D-102:** [evidencia y límites](../experiments/development/lot_journal_prospectus_2026-09-30/).
La operación nativa nueva audita declaraciones incrementales con balance
húmedo/seco, identidad declarada de transferencias y evaporación terminal.
Missingness no se convierte en cero; hashes de fuente sólo son punteros.
No exige inventar brazos/períodos ni establece cobertura hasta consumo.
Un borrador de 64 puts enlaza tres opciones sin ranking, 54 consultas de
valores y cuatro obligaciones; normas, decisiones, criterios y prueba del
caso siguen pendientes. No hay baseline/result ni intervención seleccionada.
Dos instalaciones offline 3.11/3.12 pasan seis negativos por CLI/MCP,
nueve pares de gates y cuatro de trace; publican 64 y reintentan 0/64.
No hay aceptación de fase. Pasaron 2560 pruebas globales, Ruff,
compilación y smoke instalado 3.11 de 15 operaciones/22 tools. Focales
nuevas: 118 en 3.11; 116 y dos skips MCP en Python 3.12 global, con MCP real
en la sonda instalada. El primer global 2538 passed/21 failed se conserva:
D-099 rechaza el nuevo árbol por contrato congelado. Sólo su fixture de
tests usa módulos históricos verificados; no se reescriben ensayos ni pins.
270 protegidos idénticos, dos interfaces cambiadas de forma explícita;
artefactos y negativos previos conservados. El binding de preparación no
es un controlador estricto de 64 puts; fuentes/ledger no son atómicos.
Sin nueva comparación, Q, autoridad normativa o efecto de campo. Cinco
criterios **No demostrados; 0/5**. La suite acredita mecánica técnica.

**Receta D-101:** [evidencia instalada y límites](../experiments/development/audited_bread_recipe_2026-09-30/).
Repite el cotejo D-100 y construye 37 ítems pendientes; valida identidad,
prefijo exacto y efectos reales de transporte. Dos entornos con wheel D-100
instalado, Python 3.11/3.12, recuperan SIGKILL durable tras 16 puts por MCP
21/16 y reintento CLI 0/37; dirección inversa también sin duplicados.
Cada entorno verifica 18 controles de archivo y 39 pares CLI/MCP de
estado/compuerta/próxima tarea, invalidación transitiva y restitución exacta.
50 pruebas focales por Python, Ruff y compilación pasan. Las revisiones y
el avance del probe son sintéticos externos al workflow y el controlador
rechaza ese checkpoint divergente. Cierra tres falsos verdes de admisión,
conserva fallo inicial de ROOT y originales previos. Un cambio concurrente
puede dejar escrituras rechazadas; no hay transacción atómica ni cotejo
semántico universal de `put`. Sin Q, autoridad normativa, campo, nueva
comparación de modelos o corrida de las 24. Los cinco criterios finales
permanecen **No demostrados**, **0/5**.

**Cotejo D-100:** el [auditor de pasajes](../experiments/development/bread_source_audit_2026-09-30/)
verifica 17 afirmaciones y siete filas contra valores extraídos de PDF
fijados, y conserva dos contradicciones de prosa/tablas. Un contrato revisado
por Codex coteja unidad, base, procedencia y locadores; no infiere semántica
o aporta aprobación humana. Se cerró un falso verde reproducido con extractor
interpuesto por PATH mediante pin de binario y ejecución de sus bytes sellados.
82 pruebas focales pasaron en Python 3.11 y 3.12, Ruff y dos instalaciones
offline del wheel nuevo con módulo importado de site-packages y resultados
byte idénticos. Se conservaron el corte anterior al arreglo y los casos previos.
No hubo nueva evaluación global CLI/MCP, comparación metodológica, Q,
intervención o corrida de las 24. Bibliotecas y host siguen sin atestación
externa. Los cinco criterios finales permanecen **No demostrados**, **0/5**.

**Resultado D-099:** el [recibo de la terna expuesta](../experiments/development/subscription_method_trial_2026-09-30/receipt.json)
conserva seis invocaciones CLI con Luna medio solicitado, dos por brazo,
después de congelar plan y broker. Los tres únicos replays sellados
produjeron métricas y pasaron 18/18 cotejos numéricos y de formato; el
segundo turno recibió los streams reales y sólo produjo informe final.
No se reparó o reemplazó código. T añadió 11 comandos reales y siete
`item_put`: `frame.ready=true`, aceptación falsa, cuatro bloqueos de
`critique` y defectos conservados de procedencia y validez en `status`.
El [revisor posterior](../experiments/development/subscription_method_trial_2026-09-30/posttrial_review.json)
cotejó 147 archivos byte idénticos, 12 marcadores separados, 272 protegidos,
estados de proceso nuevo y cronología manual S/T/N; sin P1/P2 abierto.
Antes del lanzamiento pasaron 35 pruebas en Python 3.11 y 3.12 y Ruff,
con CLI falsas y sandbox/toolkit locales reales. El techo numérico no
mide Q, calidad equivalente, ventaja de método o efecto causal; T sólo
cubre traza y compuertas iniciales, sin normas o fases aprobadas. Coste,
RPC e identidad efectiva no autenticados; límites globales sin aplicar.
Sin intervención, comparación confirmatoria o corrida de las 24.
Veredicto global **0/5**. [Análisis de alcance](../experiments/development/subscription_method_trial_2026-09-30/RESULTS.md).

**Resultado D-097:** una sola generación con Luna medio solicitado creó
[código, fuentes e informe originales](../experiments/development/bread_continuation_2026-09-30/attempt/),
después de congelar plan y evaluador en `6a8018c`. La generación terminó
sin errores/herramientas observadas; **el análisis basal falló** en su único
replay sellado. Exigía espacios que no coinciden con la Tabla 1 extraída:
código 2, stderr previsto y stdout vacío, sin timeout. La revisión de
seguridad autorizó esa observación del negativo, sin aprobar su viabilidad.
Los 25 cotejos aritméticos y 23 contratos quedaron sin medir; las tres
variantes negativas quedaron sin ejecutar porque requieren baseline válido.
No hay puntuación Q, equivalencia entre modelos ni resultado de campo.
Otro proceso y un revisor verificaron los 27 archivos byte idénticos,
replay bloqueado y conservación de siete archivos protegidos y 113 previos.
Las 53 pruebas previas verifican el workflow/evaluador con CLI falsa y
sandbox real, no la calidad del candidato. Uso local 57.670/7.206 tokens,
coste e identidad efectiva sin autenticar. D-096 permanece inicial, con
normas pendientes. **0/5** criterios demostrados; ninguna corrida de las 24.

**Corrección D-098:** la [sonda real CLI/MCP](../experiments/development/bread_legacy_probe_2026-09-30.json)
ya interpreta la revisión antigua como `legacy_unverified`. Descubre 21
herramientas, compara siete operaciones y verifica las nueve cifras de los
PDF, sobre copia temporal. Ambos replays saltan 19 pasos y se detienen
por falta de revisión independiente verificada; el control inválido no
escribe. Los nueve archivos originales conservan sus hashes y 16 pruebas
pasaron también en revisión independiente. Esto corrige una expectativa
obsoleta del auditor; no aporta aceptación humana, investigación empírica,
impacto o comparación N/SDD/T. Veredicto global **0/5**.

**Avance D-096:** una sola llamada CLI con Luna medio solicitado, después de
congelar plan/código en `aa3e533`, produjo un [checkpoint inicial verificado](../experiments/development/prototype_checkpoint_compatibility_2026-09-30/outcome_inspection.json).
El host local quedó habilitado; la traza no contiene el error D-095 ni ítems
de herramienta. `init` y la lectura en proceso nuevo pasaron en 27,415 s de
supervisor, con 18 nodos pendientes, dos normas sin aprobación y cuatro
fases sin empezar. Se archivaron 23 archivos idénticos; no hubo reparación,
reemplazo ni fallback API. El parser de uso se corrigió tras reproducir otro
falso verde de error explícito; 281 pruebas del parser, 22 del supervisor y
79 focales independientes pasaron. Es operatividad de un estado inicial,
sin juicio de calidad, comparación N/SDD/T, coste autenticado, topes globales
o impacto de campo. D-095 queda intacto como fallo. **0/5** criterios
demostrados; esta ronda no cuenta entre las 24 corridas requeridas.

**Avance D-095:** el [control del plazo del calendario](../experiments/development/prototype_checkpoint_2026-09-30/managed_validation.json)
pasó 172 pruebas de presupuesto/sesión y revisión independiente. Cierra una
discordancia del puente managed antes de escrituras o envíos; no unifica el
presupuesto entre agentes o proveedores. El [ensayo de checkpoint CLI](../experiments/development/prototype_checkpoint_2026-09-30/outcome_inspection.json)
quedó **failed**: Luna medio solicitado produjo una propuesta pendiente válida,
pero un error de arranque de Code Mode hizo que la regla congelada rechazara
la traza. No hubo `init` ni checkpoint; un proceso nuevo verificó los archivos
y mantuvo el fallo sin posibilidad de relanzar. Las 17 pruebas del supervisor
usan modelo falso y prototipo real. Los contadores del helper no convierten
el error de la ejecución real en éxito, ni autentican coste, versión efectiva
o límites globales. No hay comparación de calidad ni corrida de la matriz24.
Los cinco criterios siguen **No demostrados**.

**Corte:** 2026-09-30 UTC. La [matriz prospectiva](protocolo_experimental.md#7-matriz-propuesta-antes-de-observar-resultados-confirmatorios) propone evidencias, procedimientos y umbrales antes de ensayos confirmatorios; sus decisiones normativas aún requieren aprobación humana y registro. Este archivo registra solo lo que se ejecutó; no modifica esos umbrales. `GOAL.md` permanece intacto.

El [corte D-086](../experiments/development/signed_observed_full_workflow_2026-09-28/) ejecuta desde wheels instalados en Python 3.11 y 3.12 un caso **nuevo** `signed_observed` de nueve fases por CLI y cliente MCP stdio. `t1` usa un archivo de entrada y ejecutable fijados; el auditor lo repite bajo Landlock/seccomp y un actor sintético distinto registra por MCP el recibo firmado. Los 51 eventos incluyen reporte y observación; replay no escribe y alterar entrada o artefacto, o retirar la clave del observador, reabre `build` y `validate`. El test instalado cubre también el modo legado; una revisión read-only no halló P1/P2 confirmado. Los recibos son resúmenes reproducibles de bundles temporales y claves bajo un mismo UID: **no** acreditan custodia independiente, ejecución histórica, decisión humana ni caso alimentario real. Criterio 1 **No demostrado**; veredicto global **0/5**.

El [corte D-087](../experiments/development/citibike_march_crash_recovery_2026-09-28/) verifica reanudación del caso público y expuesto de Citi Bike marzo: CLI instalada termina por `SIGKILL` tras el evento duradero 16, un lector nuevo valida el prefijo, MCP aplica los seis ítems pendientes y la CLI reintenta sin escritura. La revisión firmada es sintética; `critique` permanece bloqueada por la norma sin aprobación `n_scope`. La sonda se ejecutó en Python 3.11 y 3.12 y dejó 24 eventos finales sin tocar los ledgers versionados. No reabrió el Parquet, no simuló pérdida de energía y no evalúa revisión humana, intervención ni caso reservado. Criterio 5 **No demostrado**; veredicto global **0/5**.

El [corte D-088](../experiments/development/model_scope_calibration_2026-09-28/receipt.json) fijó una tarea pública de lectura y cálculo antes de solicitar tres corridas nativas con modelos y esfuerzos declarados como Luna bajo/alto y Sol medio. Cada respuesta acertó diez clasificaciones, dos fracciones reducidas, la unidad de observación declarada y el estado de criterio 5 (14/14); el puntuador rechazó dos errores inyectados. El enunciado no distingue explícitamente esa unidad de la dimensión adimensional de las fracciones. La tarea produjo un techo y no mide ventaja relativa, método N/SDD/T, familias independientes, réplicas, tokens, tiempo, coste o evaluación humana ciega. El modelo y esfuerzo efectivos tampoco tienen recibo de proveedor en esta sonda. Criterio 4 **No demostrado**; veredicto global **0/5**.

La [ruta local D-091](presupuesto_solicitudes_modelo.md) reserva antes del envío tokens y coste calculado con tarifas aportadas para solicitudes de texto OpenAI que comparten ledger; la CLI exige ese perfil y techo. La revisión independiente cerró un falso verde de integridad del recibo. También demostró con proveedor falso que un conteo previo menor que el uso informado puede dejar el cargo por encima de la reserva después del envío. No hubo proveedor ni factura reales, control externo del gasto, herramientas compartidas o comparación N/S/T. Criterio 4 **No demostrado**; veredicto global **0/5**.

La [ruta local D-092](presupuesto_solicitudes_modelo.md#conversación-de-desarrollo-con-una-herramienta-sellada) une dos turnos de un modelo con una función declarada y una herramienta de stage sellada. Su [recibo offline](../experiments/development/managed_tool_conversation_2026-09-28.json) registra **167 pruebas focales combinadas y 2095 globales**; cotejan esquema en el conteo, argumentos y `call_id`, digest de la reserva, terminal, replay, cupos y estados tras fallos. La revisión adversarial cerró falsos verdes de decimales, estado e historial y una discrepancia entre el esfuerzo programado y el solicitado. No hubo proveedor real, coste facturado, custodia independiente, herramientas compartidas entre agentes, panel congelado ni matriz N/S/T. La salida conserva `global_run_limits_enforced:false`, criterio 4 **No demostrado** y veredicto global **0/5**.

El [control D-093](decisiones.md#d-093--comprobar-los-bytes-de-evidencia-local-en-las-compuertas) verifica en el motor los archivos declarados por evidencias `signed` con `archive`/`source_sha256`. Su ausencia, alteración o enlace inseguro invalida las dependencias y la revisión de fase; dos digests incompatibles para la misma ruta se rechazan antes de leer. La [sonda instalada](../scripts/probe_local_evidence_gate.py), sobre copias temporales de los dos PDF del pan, pasó en Python 3.11.15 y 3.12.3 con CLI y MCP stdio reales: ocho evidencias y diez dependientes quedaron bloqueados al alterar, borrar o enlazar uno de los PDF; `advance` y `run` no escribieron, y restaurar los bytes recuperó la aceptación. Pasaron **17 pruebas focales, 2 instaladas y 2114 globales**, Ruff y compilación. Los [recibos](../experiments/development/local_evidence_gate_2026-09-30/receipt.json) conservan hashes, controles y límites. Las claves son sintéticas y el cotejo no evalúa el contenido de los documentos ni su custodia; criterios 1 y 2 **No demostrados**, veredicto global **0/5**.

El [ensayo D-094](../experiments/development/bread_prototype_feasibility_2026-09-30/) congeló un paquete alimentario público antes de tres intentos nativos A/B/C con configuración heredada común. Los tres fueron interrumpidos sin entrega terminal tras superar el plazo solicitado según el operador; se conservan once archivos originales. B dejó siete entregables y seis comandos reales; A/C, solo script y métricas. Los tres cálculos se repitieron con `pdftotext` en entorno limpio y concuerdan en 25/25 cotejos por intento; el sandbox rechazó los tres por impedir subprocesos. En B, filosofía se bloqueó por `N-consent` y la norma sigue vinculada al requisito; ingeniería se rechazó por fases previas, sin aislar la causa normativa. La revisión independiente corrigió esa sobreafirmación del inspector. No hay Q, ganador, tokens/coste medidos ni límite global aplicado; no cuentan entre las 24 corridas. Criterio 4 **No demostrado**; veredicto global **0/5**.

El [control D-085](../experiments/development/signed_observed_test_gate_2026-09-27.json) activa solo en casos nuevos una compuerta de test con pines previos, repetición local y recibo de observador firmado. El motor compara el recibo con el reporte vigente y con los bytes actuales del bundle; un reporte con hashes inventados, un recibo negativo posterior, la pérdida del bundle, la revisión del test y la revocación de clave bloquean el avance. CLI/MCP comparten las dos operaciones nuevas y el runner solicita `observe_test`. Una prueba integró sandbox real, firma y replay; pasaron **1963 pruebas globales, Ruff, wheel offline en Python 3.11/3.12, smoke de nueve fases y descubrimiento de 21 herramientas**. Tres bypasses detectados por revisión adversarial se corrigieron y probaron. El observador puede fabricar un bundle y firmarlo bajo el mismo UID; sin custodia externa no se acredita la ejecución histórica ni la independencia. Criterio 1 **No demostrado**; los cinco criterios siguen **No demostrados**.

El [control D-084](../experiments/development/citibike_march_challenge_2026-09-27.json) ensaya por la CLI instalada, en una copia temporal del caso histórico de Citi Bike marzo, el ciclo `challenge → síntesis revisada → resolución → reapertura` ante un denominador bruto adversarial. Coteja por separado los conteos publicados fijados y conserva la impugnación manual, la invalidación de descendientes y tres rechazos sin escritura. La revisión por actor distinto es solo una etiqueta del script, no una persona independiente; el motor no entiende el error semántico sin la impugnación. No se reprocesa aquí el Parquet, no se aprueba la norma ni se evalúa una intervención nueva. Criterio 5 **No demostrado** y veredicto global **0/5**.

El [control D-082](../experiments/development/local_signed_test_repeat_2026-09-27.json) repite de forma optativa un test firmado vigente bajo sandbox local con ejecutable sellado y cotejo de bytes declarados. Rechaza en esa repetición un reporte firmado con hashes ficticios, aunque el motor todavía lo marca `signed_passed`; firma válida y observación local se informan por separado. Las pruebas cubren salida/artefacto distinto, enlace simbólico, ejecutable cambiado, timeout y fallo. No prueba que ocurrió la corrida histórica, independencia del firmante ni revisión humana; criterio 1 **No demostrado**.

El [control D-083](../experiments/development/development_six_cell_local_audit_2026-09-27.json) reúne las seis carpetas exploratorias mediante el observador D-E y detecta celdas faltantes, duplicadas o incompatibles sin descartar truncamientos. El positivo con seis CLI falsas se reprodujo con observación real y conserva `controlled_comparison_eligible:false`. El ledger T sintético solo declara política `signed`, sin firma Ed25519 verificada; el informe lo expresa como `signed_toolkit_workflow_verified:false`. Falta plan bajo custodia previa, proveedores reales, telemetría autenticada, herramientas y jueces comparables; criterio 4 **No demostrado**.

El [control D-081](../experiments/development/pilot_triplet_budget_binding_2026-09-27.json) rechaza un piloto vivo cuyo plan local no sea de esquema 2, no declare `active_budget_seconds` entero entre 1 y 5400 o difiera del argumento de N/S/T. El observador coteja plan copiado, binding y `run_time_budget`, y rechaza un downgrade parcial a v1. Las corridas v1 históricas siguen observables y reproducibles sin atribución de presupuesto común; la revisión independiente detectó y ayudó a corregir una regresión inicial de ese replay. Pasaron **268 pruebas focales, 1901 globales y Ruff** con CLI falsas. El plan v2 permanece NO-GO, sin nombres de modelo ni presupuesto aprobado; no hubo llamadas nuevas a proveedores. Se verifica coherencia de configuración solicitada, no una comparación de recursos efectivamente iguales ni custodia previa; criterio 4 **No demostrado**.

El [control D-080](../experiments/development/local_active_run_budget_2026-09-27.json) cierra el exceso acumulado local del runner D-E: una sola invocación comparte hasta 5400 segundos entre preparación T, CLI y consulta posterior; al agotarse registra capturas parciales y no lanza la siguiente etapa. El observador rechaza un estado favorable contradicho por un timeout registrado o por una suma de duraciones mayor que el tiempo declarado. La revisión independiente reprodujo y cerró una falsificación de ese último tipo y un riesgo de señalización después de recolectar el proceso. También confirmó un límite que permanece: un escritor del mismo UID puede reescribir metadatos no custodiados para ocultar una demora posterior a la CLI, o presentar un registro como legado sin presupuesto; el observador no acredita la duración real. Pasaron **253 pruebas focales, 1886 globales y Ruff** con CLI falsas y sin llamadas a modelos nuevos. `cap_status:unknown`, `controlled_comparison_eligible:false`; criterio 4 **No demostrado**.

El [inventario D-079](../experiments/development/installed_public_interface_inventory_2026-09-27.json) cerró la brecha de transporte del wheel D-078: los 19 comandos públicos y las 19 herramientas MCP descubiertas se invocaron con el mismo paquete instalado en Python 3.11.15 y 3.12.3. El smoke cubrió 15 parejas; las pruebas instaladas de atestación de campo y ejecución firmada cubrieron las cuatro restantes, verificando eventos, estado, bloqueo de `validate`, salida y artefacto de un proceso sintético. Los dos tests adicionales pasaron en cada entorno; el gate global pasó **1873 pruebas** y Ruff. Es cobertura de interfaz y efectos del ensayo, no de un caso real o de custodia independiente. El criterio 1 sigue **No demostrado**.

El control actual [D-078](../experiments/development/signed_test_execution_2026-09-27.json) cierra el falso verde local del test declarado. Todos los tests de un caso `signed` requieren `argv` explícito y reporte Ed25519 vigente de un ejecutor registrado; `passed:true` no habilita `build` ni un éxito decisivo. La sonda instalada ejecutó `t1` sin shell, comprobó código, streams y artefacto, y recorrió las nueve fases por CLI y cliente MCP stdio en Python 3.11.15 y 3.12.3. En ambos entornos offline pasaron `uv pip check` y el smoke de fixture con 19 herramientas MCP descubiertas y 15 operaciones comparadas. La suite global pasó **1872 pruebas** y Ruff. La revisión adversarial no encontró bypass P1/P2 en las rutas públicas revisadas, pero mostró el límite esencial: el motor puede aceptar un reporte inventado si un actor con la clave registrada lo firma; no observa la ejecución ni verifica los bytes reportados. Las claves y el proceso de prueba son sintéticos. No hay revisión humana real, custodia independiente, resultado alimentario de campo, matriz comparativa ni caso reservado; criterios 1–5: **No demostrados**.

La [síntesis de activación](activacion_validacion.md) deja los cinco criterios en **no demostrado**. La [revisión firmada de fase D-072](decisiones.md#d-072--exigir-una-revisión-de-fase-firmada-en-casos-reales) cierra un falso verde de actor autodeclarado en casos `signed`: una revisión sin firma ya no acepta ni mantiene una fase. Los cinco ledgers reales versionados conservan sus eventos, pero `frame` pasa a `legacy_unverified` y `accepted=false` al releer. La revisión adversarial halló y cerró un segundo bypass por cambio de política `signed→fixture` con ledger rehasheado; la fecha del evento y el actor del avance siguen sin autenticación independiente. La [regresión y el recibo](../experiments/development/signed_phase_review_2026-09-27.json) acotan el resultado. El [control de celdas del diseño alimentario](../experiments/development/field_cell_preflight_2026-09-27.json) exige al menos dos grupos por celda brazo × estrato, porque el remuestreo de grupos completos del candidato ajustado rechaza celdas unitarias. Dos negativos de celda unitaria, un positivo de dos estratos, revisión independiente, **1727 pruebas globales en ese corte**, Ruff y el wheel instalado sin red en Python 3.11 y 3.12 verificaron la consistencia estructural. No se ha calculado potencia ni cobertura para un sitio, y el criterio 3 permanece **no demostrado**.

El gate final de D-072 pasó **1806 pruebas sin fallos** y Ruff. Un wheel nuevo se instaló sin red en entornos limpios Python 3.11.15 y 3.12.3; ambos pasaron `uv pip check`, el smoke de nueve fases con CLI y cliente MCP stdio reales, 17 herramientas descubiertas y el probe decisivo de fixture corregido. Las firmas y revisiones de estas pruebas son sintéticas. La sonda decisiva conserva `field_impact_tested:false` y `test_command_execution_authenticated:false`. El criterio 1 y los otros cuatro siguen **No demostrados**.

La [integración firmada completa D-073](../experiments/development/signed_full_workflow_2026-09-27.json) añade el recorrido que faltaba entre la revisión de fase aislada y el smoke completo con `fixture`. Un wheel nuevo pasó instalación offline y `uv pip check` en Python 3.11.15 y 3.12.3. La sonda en ambos usó CLI y MCP stdio reales, alternó doce invocaciones de `run` (una inicial y once reanudaciones), comprobó 29 artefactos, nueve revisiones firmadas y dos aprobaciones, y leyó 49 eventos vinculados a sus snapshots. Dos firmas ausentes no escribieron; el replay fue idéntico en bytes; retirar la clave del revisor reabrió las nueve fases y restaurarla recuperó el estado. El test focal pasó con contaminación exterior de fixture y `PYTHONPATH` porque los subprocesos reciben una lista permitida de variables. El gate global pasó **1807 pruebas** y Ruff. El recibo es un resumen reproducible, no una atestación separada del ledger temporal eliminado. Las claves, actores y datos son sintéticos: `t1.passed` procede del manifiesto, sin ejecutar ese comando, y `ass1` declara `field/no_demostrado`. No prueba revisión humana, competencia, independencia, impacto de campo ni aporte comparado; criterios 1–5: **No demostrados**.

El [control D-074](../experiments/development/pilot_triplet_binding_2026-09-27.json) exige en el modo piloto una tupla CLI/modelo/esfuerzo solicitados por familia y celdas N/S/T, con plan lateral y dossier fijados por SHA antes de preparar la corrida. Con CLI falsos se verificaron las seis celdas y negativos de desajuste. Una revisión independiente reprodujo una sustitución del wheel T después del cotejo inicial; el runner ahora comprueba el wheel **copiado** antes de instalarlo y de nuevo antes de lanzar proveedor. También reprodujo un vínculo piloto añadido después de una corrida genérica: el observador rechaza la inconsistencia simple y, si el mismo usuario reescribe toda la metadata, solo informa `recorded_materials_verified_prelaunch_unproven`, `prelaunch_binding_authenticated:false`. Las 240 pruebas focales y la repetición adversarial pasaron. No hubo llamadas de modelos, custodia previa externa ni verificación de configuración efectiva; `controlled_comparison_eligible:false`, criterio 4 **No demostrado**.

El [control D-075](../experiments/development/field_denominator_reconciliation_2026-09-27.json) añade `service.schema:3`: cada entrada externa declarada se cuenta una vez bajo una regla por material y el máximo de servicio y su incertidumbre deben coincidir con sumas exactas; el acta y extractos abiertos deben concordar antes de una atestación nueva. Las 229 pruebas focales rechazan inflación aislada 90→900 000, entradas omitidas o duplicadas y cambios contra bytes fijos. La revisión independiente confirmó que una fabricación coordinada de reglas, fuentes y extractos puede pasar como nuevo **techo declarado**, sin convertir `criterion_3.status:not_assessed` en aprobado. El gate global pasó **1847 pruebas** y Ruff; el wheel nuevo se instaló offline y pasó `uv pip check` en Python 3.11.15 y 3.12.3. Faltan autoridad y aprobación auténticas, cobertura física de entradas, potencia/custodia del sitio e impacto causal; criterio 3 **No demostrado**.

El [control D-076](../experiments/development/signed_review_dependency_2026-09-27.json) conserva historial de autores por ítem y la identidad del evento de aprobación verificado en el snapshot de cada revisión de fase `signed`. Reprodujo dos aceptaciones falsas del replay anterior: el autor que reaparece como revisor después de republicación idéntica y una revisión vieja que revive tras sustituir una aprobación normativa. El control actual exige revisión y avance nuevos. Una aprobación inválida posterior conserva la última válida y una aprobación ajena no reabre `frame`. Pasaron **32 pruebas focales**, incluida la sonda firmada de nueve fases; la revisión independiente no reprodujo otros bypasses en ese alcance. Son firmas sintéticas sin garantía de identidad o juicio personal; criterio 2 **No demostrado**.

El [auditor D-077](../experiments/development/citibike_march_ratio_audit_2026-09-27.json) coteja por bytes un contrato de fuente, cantidades, unidades, población, ventana y objetivo para las dos fracciones de la muestra pública de Citi Bike marzo. Rechaza reetiquetar la misma afirmación como estación-minutos o acceso de junio frente al pin anterior; calcula racionales exactos. La revisión independiente encontró que la CLI leía archivos grandes antes de aplicar límites; la lectura acotada `límite+1` ahora rechaza una fuente dispersa de 64 MiB con salida 2 incluso bajo memoria limitada, y el wheel aislado produce ambos resultados. Si se reemplazan juntos contrato y pin, el reetiquetado pasa: el contrato retrospectivo no tiene custodia externa, y el JSON no certifica la semántica de cada fila del Parquet. Ni generalización reservada ni impacto fueron evaluados; criterio 5 **No demostrado**.

El [gate integrado del corte D-077](../experiments/development/signed_ratio_integration_gate_2026-09-27.json) pasó **1867 pruebas sin fallos** y Ruff. Un wheel nuevo se instaló sin red en Python 3.11.15 y 3.12.3; `uv pip check` y la ruta `python -m specorganon.ratio_audit` desde `site-packages` pasaron en ambas versiones, y un pin contractual incorrecto salió 2. En aquel corte, la sonda de nueve fases firmadas usaba el `t1.passed:true` declarado en la fixture sin ejecutar su comando; D-078 reemplazó esa prueba local. Faltan además revisión humana real, intervención de campo, matriz controlada y caso reservado. Veredictos 1–5: **No demostrados**.

La [preparación offline D-E](../experiments/development/energy_pilot/offline_preparation_probe_2026-09-27.json) ejecutó `--prepare-only` en seis celdas N/S/T de dos familias documentales. Cotejó bytes contra el dossier por separado: mismo prompt efectivo por brazo entre familias, paquete público y wheel T con hashes esperados. El artefacto y el código conservaron `no_go_for_provider_calls`, cero solicitudes, `launch_ready:false`, sin instalación T ni `run.json`. La revisión independiente no encontró llamadas accidentales, pero demostró que el modo genérico acepta una instantánea local distinta del dossier; por ello ese cotejo externo y la revalidación futura son obligatorios. No se verificaron acceso, herramientas equivalentes, revisión humana, topes ni costes; el criterio 4 sigue **no demostrado**.

La [preparación estricta posterior](../experiments/development/energy_pilot/strict_dossier_preparation_2026-09-27.json) comprobó en las seis celdas el SHA aportado del dossier y los nueve hashes fijados antes de emitir `prepared.json`. Negativos de mutación, enlaces simbólicos y uso fuera de `--prepare-only` rechazaron; la revisión independiente no halló un falso verde dentro de ese contrato. El propio revisor demostró que un dossier alterado con un nuevo SHA aportado por el invocador también pasa: la concordancia local no equivale a custodia. Sigue `NO-GO`, sin límite de solicitudes, tokens o gasto aplicado ni identidad de proveedor verificada.

El [simulador prospectivo de sensibilidad](../experiments/development/field_power_sensitivity_synthetic_2026-09-27/receipt.json) comparte el estimador ajustado y bootstrap de grupos con el candidato de campo. En doce perfiles **inventados**, 40 extracciones dieron para `G` supuesto de `0,10` una detección frente a cero en 40/40 y un límite inferior de IC de al menos `0,10` en 1/40; el reporte anterior del estimador quedó byte idéntico. La revisión independiente verificó fallos por `V` imposible dentro del denominador y detectó un límite de cómputo que se corrigió y volvió a comprobar. Son resultados de fixture, no potencia ni cobertura de un sitio: faltan series auténticas, aprobación del evento de potencia y calibración del IC. `assignment_ready:false`; criterio 3 **no demostrado**.

El [gate global del corte anterior](../experiments/development/field_power_sensitivity_synthetic_2026-09-27/receipt.json) terminó con **1793 pruebas aprobadas, sin fallos esperados**, y Ruff pasó. Un wheel temporal de aquel código se instaló sin red en Python 3.11 y 3.12; `uv pip check` y la importación del simulador pasaron. El wheel [del corte previo](../experiments/development/field_cell_preflight_2026-09-27.json) pasó entonces el smoke de nueve fases, CLI y cliente MCP real en ambas versiones. El [registro Landlock](../experiments/development/mcp_landlock_root_write_2026-09-27.json) conserva el cierre del falso verde de escritura MCP tras trasladar un caso fijado fuera de `ORGANON_ROOT`; exige raíz explícita y Linux Landlock ABI 5 o superior. El [replay de Citi Bike](../experiments/development/citibike_march_workflow_replay_2026-09-27.json) prueba reanudación CLI→MCP→CLI sobre 22 ítems de otro dominio sin duplicar eventos en aquel corte. La revisión independiente pasó 15 pruebas focales y no halló regresión concreta en esas rutas. Estos controles técnicos de desarrollo no autentican aprobación, custodia, evaluación independiente sustantiva ni impacto.

El [cotejo anterior de volumen basal](../experiments/development/field_volume_source_binding_2026-09-27.json), la [compuerta local de liberación por bloques](../experiments/development/local_block_release_gate_2026-09-27.json) y el [registro anterior de rutas MCP](../experiments/development/mcp_case_path_hardening_2026-09-27.json) conservan sus pruebas y límites respectivos. La compuerta de bloques sigue sin autenticar proveedor ni consumo global entre hosts. Landlock cierra la escritura del caso trasladado que aquel registro de rutas conservaba como fallo esperado; mover la raíz, alterar enlaces físicos internos o usar descriptores ya abiertos permanecen fuera de la prueba. Los conteos menores de hitos anteriores describen cortes históricos. Ningún criterio cambia de veredicto por estos controles.

El [control D-068 de JSONL](../experiments/development/strict_cli_usage_jsonl_2026-09-27.json) rechaza en Codex/Agy una clave `input_tokens` duplicada que antes se informaba como 20 aunque la misma línea contuviera 90 000. También rechaza números no finitos y UTF-8 inválido; el observador relee la traza y no acepta un resumen verde falsificado. Pasaron 155 pruebas focales y una revisión independiente sin hallazgos en ese alcance. Es integridad de telemetría **local**, sin autenticación de proveedor, modelo, esfuerzo ni factura; criterio 4 **No demostrado**.

El [control D-069 de conversación Agy](../experiments/development/agy_conversation_identity_2026-09-27.json) detecta IDs explícitos contradictorios entre inicio, pasos y resultado, y falla cerrado ante eventos desconocidos; la revisión adversarial reprodujo y cerró un escape en un sobre desconocido. Las 180 pruebas focales pasaron. Una traza válida sin IDs sigue legible como identidad local no verificada. Ningún ID crudo aparece en el resumen; el control no autentica proveedor ni costes. Criterio 4: **No demostrado**.

El [control D-070 de indicadores decisivos](../experiments/development/decisive_indicator_measurement_2026-09-27.json) bloquea `cumplido/incumplido` cuando la evidencia ancestral no declara la misma métrica y unidad con valor y alcance, o cuando una evidencia `observed` tiene método inválido. La revisión independiente reprodujo primero los falsos verdes y después los rechazos; 154 pruebas focales pasaron y `no_demostrado` conservó su salida. Las pruebas son sintéticas y no autentican fuente ni efecto de campo. Criterios 2 y 3: **No demostrados**.

La [derivación D-071 de movilidad](../cases/citibike_march2024_lineage/README.md) corrige por eventos nuevos el indicador `i_rows` del caso histórico sin alterar sus 24 eventos previos. El mismo cambio de denominador que antes dejaba el indicador vigente ahora lo invalida junto con un requisito candidato; la reparación añade revisiones hasta 42 eventos. Cliente MCP real y CLI instalada ejecutaron la sonda; el [recibo](../experiments/development/citibike_march_indicator_lineage_2026-09-27.json) y 11 pruebas cotejan la fuente, el prefijo, los estados y artefactos versionados. La revisión independiente cerró dos fallos de la sonda. No hay aprobación humana ni intervención observada de movilidad; criterio 5 **No demostrado**.

Se integró en desarrollo un [candidato ajustado reproducible de `G`](preparacion_campo.md#aritmética-declarada-y-candidato-ajustado): el análisis de esquema 2 usa una especificación fechada antes de la ventana basal, manifiesto declarado de volumen por grupo, ajuste por estrato y log volumen, y remuestreo de grupos completos. En una atestación nueva de `analysis.schema:2`, cada fila de volumen requiere ahora un `source_record` abierto con registro `volume_row` cotejado exactamente por digest, locator, valor, unidad, ventana, fecha, método, estudio y definición. Esta exigencia opera tanto con `service` legado como con `service.schema:2`; este último liga por separado las cifras declaradas de servicio a extractos abiertos. Los análisis y reportes históricos de esquema 1 conservan su contrato; las firmas previas de esquema 2 no acreditan este cotejo y requieren nuevo desafío y firma. Los límites percentilares solo se emiten con al menos 200 extracciones válidas y siguen siendo nominales, sin calibración de cobertura ni potencia para este sitio. El [registro anterior](../experiments/development/field_adjusted_candidate_2026-09-27.json) conserva el candidato sintético, hashes de reportes legados y controles negativos; el [registro nuevo](../experiments/development/field_volume_source_binding_2026-09-27.json) documenta el cotejo de volumen. No hay volumen auténtico bajo custodia física, datos previos del sitio, aprobación, intervención ni resultados de campo atribuibles. Criterio 3: **No demostrado**.

El [control de claves JSON duplicadas](../experiments/development/duplicate_json_boundary_2026-09-27.json) rechaza en CLI, lectura del ledger y registro de aprobadores un objeto ambiguo que antes podía alterar un umbral o esconder un campo sin cambiar el hash calculado tras parsear. La revisión independiente reprodujo entonces que el parser previo del SDK MCP entregaba el último valor de una solicitud JSON-RPC cruda con duplicados. El [filtro D-059 de stdio](../experiments/development/mcp_strict_wire_2026-09-27.json) valida esos bytes antes del SDK y bloquea también conversiones de booleanos, cadenas JSON usadas como objetos, sobres de solicitud mezclados y UTF-8 inválido. Los negativos por wire no mutaron el ledger; un cliente MCP real y un wheel instalado en Python 3.11 y 3.12 siguieron operando. El control mejora la integridad de la entrada local, pero no autentica evidencia ni satisface los criterios 1 o 2.

El [control local de reintentos por caída externa](../experiments/development/local_external_failure_retry_2026-09-27.json) conserva cada intento y limita a diez los reclamos adicionales por calendario candidato. Un terminal `external_failure` publicado permite el siguiente intento del mismo brazo; el siguiente brazo espera el terminal utilizable o truncado del último intento. Un cierre explícito deja faltantes los brazos pendientes si el fallo no puede reintentarse. Release y stage de reintento usan manifiestos de esquema 2; la admisión y los ejecutores ligan el número. La revisión independiente detectó y motivó dos correcciones: un manifiesto de intento 1 antes podía publicarse como intento 2 y cuatro bloques con fallos no reintentables podían agotar permanentemente el cupo de abiertos. El [control D-056](../experiments/development/local_gate_receipt_boundary_2026-09-27.json) también publica procedencia de esquema 2 en un stage nuevo con gate del intento 1 y retiene el gate durante el inventario y hasta el recibo local durable en ambas modalidades de ejecución. Los stages históricos de esquema 1 no pueden retenerlo. Todas las pruebas usan incidentes, trazas y artefactos declarados o sintéticos, sin verificar caída real de proveedor, custodia ni límite global entre hosts. El criterio 4 continúa **No demostrado**.

El [cotejo D-057 de bytes de preparación](../experiments/development/preparation_byte_replay_2026-09-27.json) reabre actas ya validadas, hashea blobs locales de los cuatro objetos terminales y cegados y de fuentes/pruebas, y regenera ambos cegados con un perfil de spans fijo. Los positivos y negativos son sintéticos. Su digest de perfil no autentica el programa usado originalmente; la búsqueda de IDs literales omite los menores de ocho bytes y no prueba cegamiento semántico, y el orden real de preparación, cierre de notas y apertura del mapa sigue sin custodia. Por ello `criterion_4.status` continúa `not_assessed`.

El [cotejo D-058 de fuentes secundarias](../experiments/development/secondary_source_bytes_2026-09-27.json) abre bytes citados por cada fila medida y recalcula con tarifa e intentos declarados cada línea de factura de modelo. Una factura con hash correcto pero cargo falso falla; un reintento con llamada omitida también. El control no interpreta el contenido de auditorías, referencias ni eventos, no verifica gasto externo o cargos humanos/herramientas y no autentica tarifa, proveedor, factura ni custodia. `P` confirmatorio y el criterio 4 siguen **No demostrados**.

La [sonda del brazo T con wheel instalado](../experiments/development/installed_t_runner_probe_2026-09-27.json) ejecutó CLI y cliente MCP reales desde el entorno que prepara el runner: tres procesos CLI, uno MCP y tres publicaciones locales del ledger para dos eventos; observador y replay verificaron los artefactos. La sonda reprodujo primero un falso verde: un modelo ficticio sin llamadas a Organon copiaba un ledger firmado anterior y el runner/observador decían `artifacts_ready_for_inspection`. El control corregido exige una traza local del CLI/MCP instalado y de las publicaciones del caso; rechaza copia directa, `organon --help` seguida de copia, intercambio de directorio, sustitución mediante enlaces y `renameat` con directorios abiertos. Una revisión independiente repitió positivo y negativos con el wheel instalado. La traza depende de `strace` del host y de procesos del mismo UID; no autentica al modelo, proveedor ni procedencia criptográfica de los bytes finales. El piloto usó un ejecutable de modelo ficticio y no compara N/S/T ni familias. Criterio 4: **No demostrado**.

| Criterio | Veredicto actual | Evidencia obtenida y límite decisivo |
| --- | --- | --- |
| 1. Funcionamiento completo | **Cumplido en alcance técnico (D-103)** | Wheel D-102 e155d010…, Linux Python3.11.15/3.12.3: dos instalaciones limpias, 24 módulos iguales al wheel/árbol actual, 22/22 operaciones positivas CLI/MCP por entorno, cliente stdio real y efectos comprobados. Workflow signed_observed de nueve fases conserva 51 eventos, reporte, observación y repetición real ABI9. Dos agentes nativos actuales escriben cuatro ítems guardados por entorno: cadena válida, solapamiento inducido y cuatro pares de lectura sin mutar. Smokes actuales incluyen SIGKILL, recuperación, replay, errores/firmas inválidas y paridad; todos los controles críticos inventariados pasan. Ocho tar conservan 196 archivos regulares y fallos originales. Revisión independiente auditó C1 sin reducir GOAL o umbral. Claves sintéticas no acreditan autoridad humana; resúmenes smoke carecen de raw por llamada; no se infiere ventaja de modelos o campo. [Inventario, recibo y límites](../experiments/development/installed_complete_interface_2026-09-30/). |
| 2. Integridad metodológica | **No demostrado** | Pruebas adversariales detectaron y luego corrigieron rechazo tardío ignorado, resolución obsoleta, indicador sin evidencia, métrica de criterio divergente y autoevaluación final. Una corrección adicional permite cerrar una incompatibilidad cuantitativa solo mediante `challenge` del par exacto, síntesis posterior y revisión independiente vigente; conserva ambas mediciones y reabre el bloqueo si cambia su base. El runner ahora exige versiones para referencias externas del manifiesto e infiere las declaradas antes en el mismo plan; una prueba reprodujo y corrigió la atribución de un borrador preparado para `p1` v1 a `p1` v2. La revisión de seguridad de aprobaciones añadió registro externo por UUID, ruta y metadatos, firma sobre la cabeza previa del ledger y restricción de fixtures. El smoke sintético rechazó una firma ausente y otra inválida, verificó una firma válida y volvió a bloquear la compuerta al retirar el registro de confianza. El ancla externa opcional rechaza truncamiento, extensión y fork de cadena coherente; una ancla desactualizada bloquea CLI/MCP. El banco de desarrollo pasó 21/21 inyecciones, pero no es la reserva sellada. Una firma verificada acredita control de la clave configurada; persisten verificación externa de identidad, custodia, autoridad y autenticidad de fuentes y auditoría de requisitos/indicadores reservados. El ancla exige custodia independiente y revisión de cada transición; el rollback conjunto de ledger y ancla se acepta si ambos están bajo control del atacante. Un control nuevo rechaza evidencia generada sin ruta de protocolo, protocolos sin cadena hasta problema y indicadores, requisitos y criterios que unen problemas normativos y empíricos ajenos; la revisión adversarial cubrió también protocolos hermanos y fuentes publicadas ya protocolizadas. Las evidencias con métrica o unidad explícitas incompatibles no respaldan el indicador; campos ausentes aún requieren revisión semántica. Una regresión nueva bloquea el avance tras rechazar una revisión vigente de ítem y conserva los snapshots históricos de mango, Citi Bike y el caso sintético; nadie aprobó compromisos normativos de los casos reales. Un control adicional exige que cada veredicto decisivo enlace resultado, prueba vigente e implementación de todos los requisitos del criterio; la regresión y la compatibilidad de ledgers históricos constan en el [registro de linaje](../experiments/development/decisive_intervention_lineage_2026-09-27.json). El [control de precisión](../experiments/development/exact_decisive_threshold_2026-09-27.json) rechaza un `cumplido` inventado que antes pasaba al redondear enteros grandes; las cifras declaradas siguen sin autenticar. |
| 3. Resolución efectiva alimentaria | **No demostrado** | El expediente de mango conserva tres cargas publicadas distintas y un control aritmético negativo. El [análisis escolar](../cases/school_waste/README.md) reproduce 155 jornadas reales: PW+KSW pasó de 45,095972 a 29,068510 g/comensal entre períodos, con una jornada basal sin KSW y discordancias en columnas derivadas. Los 20 días finales recibieron cuatro conceptos semanales distintos; sin control contemporáneo, la diferencia no es un efecto causal. Un control placebo de línea base halló nueve caídas al menos tan grandes entre 78 cortes completos y muy solapados; es un recuento exploratorio, no una prueba de efecto. El preflight sintético verifica balances, tiempos, destinos y fuentes declaradas. Su esquema 2 exige un camino de operaciones por consumo humano; el esquema 3 opcional exige asignaciones nominales completas y una cota conservadora positiva de masa con las etapas requeridas para cada consumo. Ninguno autentica genealogía física, identidad de muestras ni cobertura real, y no calcula `V` o `G`. La [búsqueda pública acotada](caso_alimentos_fuentes_candidatas.md) no encontró en las fuentes examinadas una misma cadena con ingesta y diseño causal suficientes. No hay línea base de cadena completa hasta consumo, equivalencias aprobadas, asignación de este proyecto a grupos, medición de inocuidad/costes/daños ni resultados de una intervención propia de cadena completa. La fixture numérica del motor es inventada. Un [cotejo de diseño candidato](../experiments/development/field_trial_design_2026-09-27.json) rechaza la fixture de dos grupos como ensayo, coteja un plan separado con el grafo de esquema 3 y exige mínimos estructurales de grupos, estratos y ventanas; la revisión adversarial cerró una brecha de cronología declarada. No autentica prerregistro, aleatorización ni cobertura semanal y conserva `criterion_3: not_assessed`. |
| 4. Aporte frente a N y SDD | **No demostrado** | Tres prototipos y 33 escenarios sintéticos comparan mecánicas; el flujo secuencial conservó aceptaciones obsoletas y el grafo necesitó más reparaciones. El calendario, preparación de bytes, desafío de firma, auditoría y conciliación de recibos, estructura de juicios ciegos, ensamblaje declarado de `Q`, análisis pareado y cálculos secundarios con IC marginales forman una cadena **de desarrollo** probada con datos inventados. El analizador ahora rechaza actas de preparación duplicadas y parejas terminales ambiguas u omitidas de las advertencias. Un desglose nuevo de `Q` por caso, familia, modelo × esfuerzo y agentes expone deterioros ocultos por el agregado; el ejemplo R-F es enteramente sintético. Conserva faltantes y `criterion_4: not_assessed`; los digests de eventos, auditoría, inyección, facturas y tarifas no autentican sus fuentes. El piloto D-E ejecutó N, S y T con un solo modelo; T tuvo dos correcciones posteriores y una traza local CLI en T3. El runner concilia uso por pasos de Agy con el terminal, pero ese uso no es recibo autenticado ni permite demostrar un corte estricto antes de 80 000 tokens. No hubo registro externo, matriz por modelos, evaluadores ciegos, notas de casos reservados, ablaciones, telemetría comparable ni costes reales, ni análisis confirmatorio de métricas secundarias. Un cotejo local de actas preexistentes rechaza una permutación S/T si las actas quedan fijas, pero mapa y actas falsificados juntos aún pueden pasar. Las salidas exploratorias previas y D-E no forman un ensayo controlado. El parser local rechaza ahora caché mayor que entrada y razonamiento mayor que salida en Codex/Agy y pasos Agy completados; la [sonda](../experiments/development/local_usage_subset_2026-09-27.json) conserva que sigue sin haber recibos autenticados. |
| 5. Generalización | **No demostrado** | Citi Bike junio de 2026 aportó un segundo dominio real con 30 artefactos y una corrección de supuesto que dejó 12 descendientes obsoletos, incluidos decisión y requisito candidatos. Un sondeo puntual del feed actual unió 2.520 IDs, pero sus tres indicadores de estado no pasaron el tipo booleano GBFS 2.3; no se calculó disponibilidad de ese feed. Una [muestra histórica distinta, de marzo de 2024](../experiments/development/citibike_sample_status_2026-09-27.json), permitió calcular sobre bytes fijados 1.809.036 filas estación-instantánea que pasaron un control conservador, con 1.725.248 filas de alquiler habilitado y bicicleta y 1.682.386 de devolución habilitada y anclaje. Las 820 capturas tienen huecos y no sustentan minutos continuos, viajes frustrados ni un efecto de intervención; no se mezclan con junio de 2026. Una regresión sin red reprodujo el evento 31 por la CLI instalada, verificó la propagación hasta el requisito, la revisión de `frame` y el bloqueo de aprobación sin firma. Es aplicación parcial, sin aprobación normativa, intervención, ciclo completo ni evaluador de movilidad. Ese paquete está expuesto y no es reserva ciega para comparar métodos. |

El [control MCP con Landlock](../experiments/development/mcp_landlock_root_write_2026-09-27.json) convirtió el antiguo fallo esperado por traslado del caso en una regresión verde con cliente stdio real. Con raíz explícita, init, put, run y status funcionan dentro; el put posterior al traslado se rechaza y conserva el ledger externo. Sin raíz explícita no se instala esa regla; no cubre movimiento de la raíz, enlaces físicos internos ni descriptores de escritura preabiertos. D-103 cierra C1 en el alcance técnico de la matriz vigente, con pruebas actuales en ambos entornos. La atribución anterior de aprobación humana competente y coordinación confirmatoria como pendientes de C1 añadía obligaciones que GOAL y esa fila no exigen: se conservan como límites y tareas de integridad, campo y comparación en sus ámbitos. El umbral no cambia. **Aceptación actual: 1/5**; C2–C5 No demostrados. Los veredictos 0/5 de cortes previos y recibos originales son históricos y permanecen intactos.

El [replay Citi Bike de marzo](../experiments/development/citibike_march_workflow_replay_2026-09-27.json) genera determinísticamente un manifiesto de 23 pasos desde la semilla real: 22 `put` por CLI, pausa en cursor 22 para revisión de `frame`, un avance por MCP stdio y reintento CLI sin eventos nuevos. En ambos intérpretes instalados el ledger temporal terminó con 22 cargas, una revisión y un avance; la compuerta `critique` siguió bloqueada por la norma `n_scope` sin firma. La revisión fue emitida por el mismo script con otra etiqueta de actor, no por un evaluador sustantivo independiente. Se cotejaron hashes y locators del JSON derivado, pero no se reabrió ni recalculó el Parquet. Es transferencia de mecanismos en un caso retrospectivo de desarrollo, sin ciclo completo ni intervención; criterio 5: **No demostrado**.

En una prueba posterior y separada, el [recálculo de la fuente de marzo](../experiments/development/citibike_march_source_recalculation_2026-09-27.json) descargó del commit público el Parquet de 10.853.196 bytes, verificó su SHA-256 y generó en Python 3.11.15 con dependencias fijadas un JSON idéntico byte a byte al archivado. Una entrada de hash distinto se rechazó antes de leer Parquet. Esto cierra la laguna de reproducibilidad de ese agregado que el replay por sí solo dejaba abierta; no acredita veracidad de cada observación ni intervención. El expediente sigue expuesto y el criterio 5 permanece **No demostrado**.

En un corte histórico anterior, el wheel SHA-256 `83add783d93618180199ddc42925a1ea318853414e2e79b8305b191b10561a49` se instaló sin red en Python 3.11.15 y 3.12.3. `uv pip check` y el smoke de nueve fases pasaron en ambos: descubrieron las 16 herramientas MCP e invocaron las 14 operaciones previas por CLI/MCP. Las 26 pruebas focales del análisis y la declaración firmada pasaron además desde `site-packages` en ambos entornos, incluyendo las dos operaciones nuevas por ambos transportes y el bloqueo de `validate` tras firma válida. Son pruebas con datos y claves sintéticos; la cobertura sigue sin ser validación de campo ni de las fuentes externas.

La [regresión de cantidades exactas y reintentos](../experiments/development/engine_exact_gate_retry_2026-09-27.json) añade evidencia técnica a los criterios 1 y 2: un entero sobre `2**53` ya no se redondea hasta coincidir con otro al buscar contradicciones ni al cotejar un producto; un reintento idéntico de `review_phase` o `advance` conserva el evento y la aceptación, incluso tras una colisión CAS. El rango publicado `3-6` del ledger mango permanece válido y se compara como intervalo cerrado con un escalar porcentual de la misma unidad. La revisión independiente cerró sus contraejemplos y pasaron 110 pruebas focales; el wheel instalado offline pasó el smoke CLI/MCP en Python 3.11 y 3.12. No se autentican mediciones, fuente, actores, revisión humana ni el efecto del caso real; ambos criterios siguen **No demostrado**.

La [sesión local de herramientas consecutivas](../experiments/development/staged_tool_session_2026-09-27.json) conserva `work/` y un journal de reservas entre dos ejecutables sellados de una instancia de stage. Bloquea la continuación ante una reserva o recibo inciertos, rechazo de inventario y fallo de `fsync`; un ancla evita reiniciar el cupo con otra sesión de esa misma ruta. Las regresiones reprodujeron dos herramientas reales sobre datos sintéticos, interrupciones, un recibo contradictorio, plazos y concurrencia; pasaron 61 pruebas focales y 1148 globales en ese corte. El revisor mostró que entonces dos stages distintos del mismo release y `run_id` obtenían cupos independientes; `global_run_limits_enforced: false` lo declaraba. No hubo proveedor, token, costo, evaluador ciego ni comparación controlada de resultados. El criterio 4 sigue **No demostrado**.

El [registro local común del intento 1](../experiments/development/local_run_admission_2026-09-27.json) cierra ese bypass para procesos cooperantes del mismo UID, host y raíz: una copia ganadora reclama `(schedule_sha256, run_id)` antes de su primera reserva, y otra copia o modalidad no puede lanzar. `init` por sí solo no reclama; el reclamo y la identidad de la raíz quedan ligados al journal y a los recibos. Se reprodujeron carreras de hilos y procesos CLI, caídas y errores de sincronización; pasaron 57 pruebas focales y 1165 globales. La revisión independiente no encontró un bypass accionable en el alcance local. El registro no autentica una caída externa para otro intento ni limita modelos, tokens, coste o tiempo de proveedor. Tampoco aporta custodia, evaluación ciega, aislamiento de runtime ni resultados comparados: el criterio 4 sigue **No demostrado**.

La [muestra histórica de marzo de 2024](../cases/citibike_march2024/README.md) se incorporó además a un ledger hermano de 22 ítems y 24 eventos. La CLI verificó las trazas de cifras derivadas al protocolo retrospectivo y a la fuente, y aceptó solo `frame` tras revisión de un agente distinto. Pasaron 3 pruebas focales y **987 pruebas** en ese corte. `critique` está bloqueada por una norma sin aprobación humana; no hay estudio prerregistrado, intervención ni aceptación de fases posteriores. El ledger de junio conservó sus bytes y el criterio 5 sigue **no demostrado**.

El [manifiesto semanal de desarrollo](../experiments/development/field_weekly_presence_2026-09-27.json) hizo fallar el cotejo alimentario cuando faltó una semana de un grupo, aunque las ventanas del plan seguían cumpliendo cuatro y ocho semanas. Un control positivo sintético registró 168 eventos declarados para 12 grupos; pasaron 26 pruebas focales y **999 pruebas** en ese corte. La señal nueva es solo presencia declarada: no autentica fuente, continuidad, servicio semanal, potencia ni efecto. El criterio 3 sigue **no demostrado**.

La [ilustración de potencia](../experiments/development/field_power_mismatch_2026-09-27.json) verifica que el 80 % aproximado de detección de `G = 0,10` frente a cero no equivale a 80 % de probabilidad de que el límite inferior del IC 95 % llegue a `0,10`. Bajo el error estándar **supuesto** `0,0357` y un estimador normal fijo, los valores son `0,7998708194` y `0,025`; pasaron 16 pruebas focales, incluidas dos regresiones por pérdida de precisión, y **1015 pruebas** globales. Los casos escolar y mango no dan dispersión multigrupo previa de `V` del sitio. No se calculó potencia para la asignación estratificada, el estimador DiD y el intervalo por remuestreo del protocolo; el criterio 3 sigue **no demostrado**.

La [sonda del servidor MCP](../experiments/development/mcp_server_crash_2026-09-27.json) añadió dos interrupciones sobre `run` del wheel instalado: antes y después del segundo reemplazo del ledger. Un cliente stdio real observó cierre de conexión y, tras reconectar, completó el mismo manifiesto sin duplicados; CLI y MCP vieron el mismo estado. Un wrapper observó salida `-SIGKILL` del PID marcado por el hook. Los controles sin hook, con salida 17 y con excepción ajena al transporte impiden atribuir esos resultados a una terminación normal o a cualquier error. Es una ruta de recuperación sintética adicional; el criterio 1 sigue **no demostrado**.

El [control de recibos de matriz](../experiments/development/matrix_usage_presence_2026-09-27.json) rechaza ahora 324 intentos completos con todas las llamadas en cero y 162 tríos completos con solo el líder activo. Un tercer falso verde, 162 tríos que se decían `truncated` bajo todos los topes, produce ahora 162 infracciones y deja la cobertura declarada incompleta. Pasaron 67 pruebas focales y **1032 pruebas** globales. Un trío que **alcanza** un tope antes de que actúen los otros dos conserva el truncamiento, y una caída externa documentada puede registrar cero uso. La cobertura que calcula el auditor sigue siendo de **declaraciones locales**: no verifica contadores del proveedor, identidad o independencia de agentes, evaluaciones ni costes. El criterio 4 sigue **no demostrado**.

El [control del piloto Agy sin comandos](../experiments/development/agy_no_command_trace_gate_2026-09-27.json) cierra un falso verde de desarrollo: una traza con `RunCommand DONE` ya no puede dejar N/S listo para inspección o replay. El observador coteja tanto la traza como la política con los bytes del prompt; bloquea un `run.json` degradado a `default`, y conserva lectura de la telemetría anterior compatible. Se rechazaron también nombres de herramienta ausentes o inválidos, tipos de paso desconocidos y trazas sin escritura visible. Pasaron 79 pruebas focales y **1050** globales. Este filtro solo ve eventos JSONL locales; no impide físicamente comandos ni acredita llamadas no registradas. El criterio 4 permanece **no demostrado**.

El [replay local restringido](../experiments/development/local_replay_sandbox_2026-09-27.json) añadió una opción posterior a la generación D-E: ejecuta un `analysis.py` revisado con Landlock ABI 9, seccomp y límites locales, sin aperturas de escritura por ruta. En el host actual se denegaron lectura y escritura fuera del paquete, `chmod`, sockets, creación de procesos, `memfd` y cambio de prioridad de un hermano; un script de cálculo permitido produjo la misma salida y el observador verificó los streams sin ejecutar código. La revisión independiente halló y cerró los falsos alcances de prioridad y `memfd`; también mostró que `RLIMIT_FSIZE` es por archivo y `RLIMIT_AS` no es memoria total. Las etiquetas del registro expresan esas dos limitaciones y declaran ausentes las cuotas agregadas. Pasaron **92 pruebas focales, 1063 globales y Ruff**. El control solo restringe el replay local revisado: la CLI que generó el código, las llamadas a herramientas/modelos, el stage N/S/T, los tokens y la custodia siguen fuera de él. El criterio 4 continúa **no demostrado**.

El [control de enlaces decisivos](../experiments/development/decisive_direct_links_2026-09-27.json) exige que el resultado enlace su prueba, la prueba enlace el criterio y la implementación, y que la implementación llegue al requisito sin atravesar el propio criterio. Así se bloquean rutas falsas a través de criterio o línea base; una cadena de implementaciones explícitas sigue aceptada. El wheel actualizado pasó instalación offline, `uv pip check` y una sonda CLI en Python 3.11.15 y 3.12.3. Las regresiones usan veredictos y cifras sintéticas; las fuentes, identidad de revisor, ejecución de pruebas y causalidad de campo siguen sin autenticar. Los criterios 2 y 3 permanecen **no demostrados**.

En aquel corte, el wheel con SHA-256 `facbf02e0e0f3ac3157167d23124a4c9e8ca73bbb1c11151e63863addf9558bb` se construyó e instaló sin red en entornos temporales nuevos de Python 3.11.15 y 3.12.3 con dependencias de los bundles locales fijados. `uv pip check` y el smoke de nueve fases, 14 comandos CLI y 14 herramientas MCP pasaron en ambos; una importación desde cada `site-packages` conservó la desigualdad exacta entre los dos enteros de la regresión. La prueba pública del gate se ejecutó en la suite del repositorio. Los datos y la aprobación eran sintéticos y no prueban impacto de campo.

Una sonda del wheel anterior, cuyo script tenía entonces SHA-256 `dfec83864909b89c704f2e08cca39403a49db5384f5298aebf948f4cad860cd9`, ejecutó además el gate de linaje por CLI instalado: bloqueó `cumplido` cuando faltaba la prueba vinculada y aceptó la fixture al enlazar la prueba y renovar la revisión. El [script vigente](../scripts/probe_installed_decisive_gate.py) se actualizó después para declarar una medición sintética pertinente que exige el gate actual; su ejecución nueva figura en el recibo D-072. Ninguna versión autentica la ejecución real de pruebas.

El [piloto público D-E](../experiments/development/energy_pilot/README.md) añadió un caso factual de otro dominio y cinco salidas de un modelo: N, S y T1/T2/T3. La [auditoría](../experiments/development/energy_pilot/audit.md) conserva fallos de instrumentación, estimaciones de ahorro sin soporte y revisión autodeclarada. En T3 hay 47 llamadas locales al CLI y un ledger `signed` de 31 eventos; el informe histórico mostraba solo `frame` aceptada, pero esa revisión autodeclarada sin firma no satisface la compuerta vigente. `critique` además exige aprobación humana. La muestra y cinco scripts se pudieron reproducir; no se asignó `Q`, no hubo evaluadores independientes ni telemetría de tokens/coste. Por ello no cambia ningún veredicto de aceptación.

El [ejecutor local D-E y sus cuatro intentos adicionales](../experiments/development/local_cli_2026-09-26/README.md) conservaron dos fallos instrumentales: Agy informó éxito tras denegar `RunCommand` y Codex terminó con código 0 pese a fallos internos de aislamiento. Dos salidas N/S de un mismo Gemini, con instrucción extra de no usar comandos, produjeron scripts que se inspeccionaron y reprodujeron con SHA-256 fijado. La telemetría local informó 111 572 y 127 322 tokens totales respectivamente, por encima del tope de 80 000 del protocolo. El parser actual concilia el uso de `step_update` de Agy con el terminal y rechaza pasos sin `DONE`, índices inválidos, colisiones y totales inconsistentes; 26 pruebas focales pasaron y las cuatro trazas originales se cotejaron sin volver a ejecutar modelos. Un paso puede cruzar el límite antes de emitir su uso: no hay prueba de corte estricto a 80 000 tokens, recibos autenticados ni coste verificado. Un permiso temporal de comandos Agy permitió leer un archivo de prueba fuera de la carpeta del proyecto pese a `--sandbox`, por lo que no se usó en los brazos con entregables. No se ejecutó T con este ejecutor, no se puntuó `Q` y los informes N/S mantienen afirmaciones no sustentadas sobre cargas evitables y seguridad. Tampoco cambia el criterio 4: **no demostrado**.

La [ruta OpenCode D-061](decisiones.md#d-061--incorporar-opencode-al-runner-de-desarrollo-sin-atribuir-telemetría-de-proveedor) permite ensayar N/S/T locales con `minimax/<modelo>` y esfuerzo `uncontrolled`. El parser concilia pasos por `messageID`, exige al menos una herramienta completada cuando un paso termina en `tool-calls` y rechaza pasos abiertos, solapados, errores y valores obligatorios inválidos. El observador reabre el JSONL fijado por hash y rechaza un resumen que invente cierre o modelo observado. La ausencia permitida de `tokens.total` deja el cierre válido con uso incompleto, sin inferir su valor ni coste. Las pruebas usaron exclusivamente una CLI falsa y un wheel T simulado: no hubo llamada a MiniMax, no se autenticaron modelo, esfuerzo, tokens o factura, no se ejecutó una matriz comparable y el criterio 4 sigue **No demostrado**.

Una [regresión nueva del lector Codex](../tests/test_run_development_arm.py) cerró otro falso verde local: un `item.started` sin cierre podía preceder `turn.completed` y dejar `terminal_success=true`; el observador aceptaba entonces los materiales como listos. El lector concilia ahora ID y tipo de cada inicio con cierre o fallo y rechaza ítems abiertos, cierres contradictorios y códigos de salida presentes que no sean enteros JSON. Conserva completados históricos sin inicio para no reinterpretar trazas parciales. La [prueba del observador](../tests/test_observe_development_run.py) reproduce el antiguo resultado y comprueba el rechazo al reabrir los bytes. Son controles de consistencia de JSONL local, sin autenticar proveedor, modelo efectivo, coste ni uso de subagentes; el criterio 4 sigue **No demostrado**.

El wheel reconstruido tras corregir las revisiones de ítem pasó en Python 3.11.15 y 3.12.3: cada smoke invocó **14/14 comandos CLI y 14/14 herramientas MCP**, comparó 14 operaciones por ambos transportes, aceptó nueve fases, conservó 29 ítems y terminó en revisión 49. Antes descubría las 14 herramientas MCP, pero dejaba cinco sin invocar. La paridad cubre los escenarios sintéticos ensayados. El criterio 1 sigue `no demostrado` por sus requisitos externos pendientes.

La [regresión de rechazo de ítem](../experiments/development/item_review_rejection_2026-09-26.json) reprodujo nueve fases aceptadas que seguían aceptadas tras `review_item(req1, reject)`. El motor ahora propaga el rechazo vigente y exige nueva revisión/avance al reaceptar. La primera versión del arreglo alteró snapshots antiguos incluso sin revisión de ítem; se reparó y se cotejaron los ledgers de mango, Citi Bike y `synthetic_multiagent` sin reescribirlos. Es un control estructural sintético, no una revisión humana autenticada.

El [control de JSON estricto](../experiments/development/strict_json_transport_2026-09-26.json) reprodujo un éxito falso del wheel anterior: `put --data '{"value":NaN}'` salía con código 0, persistía `NaN` y MCP no devolvía un resultado estructurado válido. La revisión independiente detectó además que `1e-9999` se aceptaba como `0.0`; el wheel actual rechaza valores no finitos, exponentes que desbordan, subdesbordamiento a cero y literales cuya conversión cambiaría el valor decimal al volver a serializar. Una entrada rechazada conserva los bytes previos. Los smokes de Python 3.11.15 y 3.12.3 lo comprobaron con cliente MCP real. `float` aún representa decimales ordinarios de forma binaria aproximada en memoria; esto corrige rutas de transporte, sin probar el criterio 1 completo.

La [alineación requisito–indicador](../experiments/development/criterion_indicator_alignment_2026-09-26.json) reprodujo otra aceptación falsa: un criterio para un requisito de P1 tomaba un indicador de P2 con la misma métrica textual; el motor anterior permitía aceptar `specify`, `build` y `validate`. Ahora cada requisito antecesor debe compartir un problema normativo y de evidencia con un indicador de métrica compatible. Un control positivo mantiene válido que la evidencia del requisito mida otra propiedad cuando el indicador de éxito tiene su propio soporte. Es linaje declarado, no juicio semántico de fuentes.

La [corrección de unidades](decisiones.md#d-026--alinear-unidades-antes-de-aceptar-un-éxito-medido) cierra tres falsos verdes de `cumplido`: efecto distinto del indicador, línea base sin unidad y criterio/umbral con unidad explícita contradictoria. El gate conserva un positivo con unidades concordantes y permite registrar `no_demostrado` sin fingir una medición completa. El wheel actual volvió a pasar el smoke instalado en Python 3.11.15 y 3.12.3; eso no autentica las mediciones ni valida atribución causal. La evidencia sin métrica/unidad explícita todavía puede sostener provisionalmente un indicador y requiere auditoría semántica externa.

El [control de rechazo medido](../experiments/development/assessment_rejection_2026-09-27.json) cierra un falso verde de `incumplido` de campo con datos solo simulados y sin efecto estructurado. La revisión independiente encontró después dos fallos más: una regla textual aceptaba un intervalo que cruzaba el umbral, y un `reject_test` podía repetir la condición de éxito y aprobar ambos veredictos. La compuerta exige ahora un test previo y medido cuyo intervalo completo quede del lado adverso del mismo umbral; conserva `no_demostrado` para evidencia inconclusa. El motor genérico sigue aceptando éxito sobre una estimación puntual si el criterio previo lo declara: para R-F, el protocolo obliga a registrar `lower_ci >= 0,10`, y la regresión de ese criterio bloquea el IC cruzado. Son controles de coherencia sobre fixtures inventadas, no validación causal ni autenticación de campo.

El [contrato estructurado para éxito de campo](../experiments/development/field_success_structure_2026-09-27.json) cierra una aceptación falsa de `cumplido` cuando daños o costos se declaran «no medidos». La revisión adversarial mostró que buscar frases en texto libre dejaba pasar ausencias y también bloqueaba mediciones completas; esa heurística se descartó. Ahora ambos resultados exigen un objeto con estado `measured`, fuente, fecha y una lista no vacía de medidas numéricas finitas con unidad y tamaño de muestra positivo. Cero es válido. Un ledger antiguo con éxito de campo en prosa sigue legible, pero su aceptación puede reabrirse hasta registrar una nueva versión estructurada y revisarla; ningún caso versionado contiene ese éxito legado. Son comprobaciones sobre fixtures inventadas y metadatos declarados: no autentican la fuente, la cobertura de daños por actor ni que se respeten los márgenes humanos pendientes. El criterio 3 sigue **No demostrado**.

El [auditor prospectivo de perjuicios](../scripts/audit_field_guardrails.py) añade un preflight de cuatro JSON: plan, grafo de campo, registro de actor y etapa con seis clases de resultado, y mediciones por grupo y período. Compara hashes canónicos, fechas declaradas, mapa previsto de actores y etapas, métricas, márgenes o condiciones de parada y referencias de medida únicas. Las pruebas sintéticas incluyen pérdidas de cobertura y un registro fechado después del inicio basal. La salida declara `approval_authenticated:false`, `execution_ready:false` y `criterion_3:not_assessed`: ni el registro, las firmas, los participantes, las fuentes ni el daño real están autenticados. Este preflight sigue siendo un control declarativo: en expedientes `signed`, el [cierre D-060](decisiones.md#d-060--cerrar-los-veredictos-decisivos-de-campo-firmado-hasta-disponer-de-atestación-independiente) bloquea tanto `cumplido` como `incumplido` hasta disponer de análisis reproducible y custodia verificada, y conserva `no_demostrado`; en `fixture` solo se prueban mecánicas sintéticas. El wheel reconstruido se instaló offline en Python 3.11.15, pasó `uv pip check`, abrió la CLI y descubrió 14 herramientas con un cliente MCP real; su motor instalado devuelve el bloqueo para ambos veredictos. La ruta positiva de decisión sigue pendiente. La alternativa de liberar una línea basal bajo custodia ciega tampoco está implementada en este preflight.

El auditor de cuatro JSON ya está empaquetado en el wheel y el motor permite registrar una declaración Ed25519 de evaluador externo vinculada a caso, versiones, manifiesto, fuentes y reporte. El primer intento de usarla para desbloquear `validate` falló una revisión adversarial: un análisis `{}` y campos de reporte de una letra, con firma y hashes correctos, dejaban el gate listo y aceptado. El motor volvió a cerrar ambos veredictos decisivos firmados. Ahora el [auditor de análisis](../src/specorganon/field_effect_analysis.py) recalcula exactamente los `V` declarados, el `G` sin ajuste y comparaciones descriptivas de las celdas de perjuicio; exige esquema y cobertura completa; el esquema 1 comprueba la forma del IC declarado y el esquema 2 recalcula un candidato nominal, pero ambos devuelven `decision_ready:false`. Un análisis `{}` rehecho con hashes correctos ya se rechaza antes de firmar. La prueba integrada firma un reporte que reconoce falta de atribución y comprueba que API, CLI y cliente MCP conservan el bloqueo; el retiro de la clave externa marca la firma como no verificada. El estado `signature_verified` acredita únicamente la firma, no el contenido del informe. El [cotejo de hashes primarios](../experiments/development/field_primary_source_coverage_2026-09-27.json) exige que las referencias de asignación, equivalencia y mediciones tengan bytes locales con el rol esperado antes de desafiar una firma: en la fixture sintética 722 referencias se vinculan a dos archivos agregados. Una omisión rehecha con hashes correctos se rechazó. El [cotejo posterior de extractos](../experiments/development/field_source_content_match_2026-09-27.json) exige ahora que cada referencia corresponda a un registro JSON tipado con valores y localizador concordantes; rechazó un `{}` con hashes, plan, registro y manifiesto rehechos. La prueba con 720 archivos individuales también pasó. Ambos controles solo comparan declaraciones y bytes locales; no cotejan el extracto contra un original custodiado ni prueban origen, autoridad o verdad de la medida. El esquema 2 añade un candidato ajustado reproducible de `G` y límites percentilares nominales; su atestación exige ahora `volume_row` abierto para cada fila basal, incluso con `service` legado. `service.schema:2` coteja por separado las cifras de servicio contra extractos abiertos. Faltan validación de cobertura y potencia estadística para el sitio, originales bajo custodia, aprobación auténtica de equivalencias y márgenes y observación física. El criterio 3 sigue **No demostrado**.

El [cotejo local de actas](../experiments/development/preparation_records_2026-09-26.json) lee bytes de actas preexistentes y une ID opaco, corrida, intento terminal, cuatro digests y una receta declarada. Con actas fijas rechaza la permutación de dos enlaces S/T; una prueba que rehízo mapa y actas pasó, mostrando que los hashes locales no acreditan custodia. El [control cronológico añadido](../experiments/development/preparation_rating_chronology_2026-09-26.json) exige ahora el JSON de juicios, comprueba su digest y estructura y rechaza actas fechadas igual o después del primer bloqueo declarado de `Q`. Antes se verificaban dos actas aun con esa cronología imposible. No ejecuta la receta ni autentica relojes, cierre real, paquetes o fuentes; deja `criterion_4: not_assessed`.

El [control de linaje de evidencia](../experiments/development/evidence_lineage_2026-09-26.json) reprodujo dos falsos verdes con el motor anterior: nueve fases aceptadas pese a una observación simulada huérfana, y `specify` listo al juntar una norma de `p1` con evidencia de `p2`. El motor actual bloquea ambos; también bloquea atribuir a evidencia ya protocolizada un problema de un protocolo hermano y rechaza indicadores cuya única ruta al problema normativo usa otra métrica o unidad declarada. Una fuente publicada independiente todavía puede interpretarse bajo un protocolo citado por su inferencia. Son verificaciones estructurales sintéticas; los campos de medición ausentes siguen siendo soporte provisional y no se autentican fuentes ni se revisa automáticamente su contenido.

El [control de desglose de Q](../experiments/development/q_case_reporting_2026-09-26.json) conserva media, IC y pesos previos en una matriz sintética, pero muestra `Q(T)−Q(S) = −20` en R-F aunque el agregado sea `+26,67`. Informa cada celda y su estado; no incorpora por sí solo incidentes críticos, evaluadores, proveedores ni custodia, por lo que el criterio 4 permanece sin evaluar.

El [registro operativo nuevo](../experiments/development/wheel_recovery_2026-09-26.json) añade, en esos dos entornos recién instalados, interrupción real del proceso CLI con `SIGKILL` tras un checkpoint de 3 y 4 eventos, reanudación del mismo manifiesto por MCP, conteos aplicados/omitidos, IDs únicos, paridad de `status` y replay sin mutación. Dos procesos CLI con actores declarados distintos y precondiciones de versión conservaron ambos ítems al salir de una barrera común. Esa barrera no prueba que hayan leído la misma revisión ni un reintento del wheel; la prueba de colisión forzada sigue siendo de desarrollo. `SIGKILL` después de un checkpoint no simula una caída durante la sustitución atómica ni del host. Ninguna de estas fixtures autentica agentes de modelo o aprobación humana.

La [prueba posterior de paridad entre transportes](../experiments/development/wheel_transport_parity_2026-09-26.json) coteja 13 operaciones sobre dos casos sintéticos con iguales decisiones y `approval-challenge` sobre el mismo caso firmado. Para escrituras compara secuencia, actor, tipo y payload, comprueba cada respuesta contra el ledger propio y acota el tiempo UTC del evento; para lecturas exige resultado idéntico y ausencia de mutación. Ejercita además una firma Ed25519 válida por `approve --signature` CLI y otra por MCP, con verificación de estado y revocación de confianza. La prueba no compara todos los errores posibles ni constituye una prueba formal de equivalencia en cualquier estado.

La [corrida directa de dos subagentes nativos](prueba_multiagente.md#cli-instalada-invocada-por-dos-subagentes-nativos) añadió recibos de comandos del wheel instalado. En la primera ronda los ocho ítems se conservaron pero los intervalos no se solaparon; en la segunda, una barrera y pausas deliberadas permitieron 387 033 229 ns de solapamiento de procesos y 20 escrituras alternadas, sin pérdida. El [verificador](../scripts/check_native_direct.py) coteja recibos y cadena de hashes. Las etiquetas y archivos no autentican por sí mismos al modelo, y la prueba no mide ventaja de coordinación.

Para el criterio 3, la [extracción estructurada de tabla 15 de FAO](../cases/mango/fao_table15_loads.json) deja por separado tres cargas observadas en 2016, con ubicación, duración, masas y porcentaje publicado; las fechas exactas y la incertidumbre están ausentes. Sus tres ítems se anexaron al [ledger de mango](../cases/mango/organon.json) sin reescribir los 27 eventos previos; el [registro de anexo](../experiments/development/mango_table15_ledger_2026-09-26.json) coteja el seed, los porcentajes y el estado de las compuertas. La primera pérdida se estimó parcialmente; la tercera muestra una discrepancia entre porcentaje impreso y recálculo de masas. Es evidencia histórica descriptiva de otra investigación, sin trazabilidad de un mismo lote hasta consumo ni intervención atribuible.

El [caso escolar público](../cases/school_waste/README.md) aporta un XLSX original con 155 días y un [análisis reproducible](../experiments/development/school_waste_2026-09-26.json) según un [plan comprometido antes de leer resultados](plan_escuela_residuos.md). PW+KSW bajó de 45,095972 a 29,068510 g/comensal entre la base y los 20 días finales. Una jornada basal carece de KSW y dos filas contienen discordancias en columnas calculadas; el analizador utiliza masas fuente en kg y declara exclusiones. Los días finales agrupan cuatro conceptos distintos, uno por semana. La comparación de períodos y la sensibilidad por menú son descriptivas: no controlan estacionalidad ni constituyen un efecto causal, y el conjunto solo cubre consumo y cocina/servicio.

La [sensibilidad temporal posterior](sensibilidad_temporal_escuela.md) deja trazables 116 ventanas basales candidatas de 20 jornadas, 18 excluidas por la única fila sin KSW y 98 completas; el total de los 20 días finales (29,068510 g/comensal) es inferior al de cada ventana completa (34,359730–52,145109). La última ventana dio 39,909542; las cuatro semanas finales y la exclusión de las dos filas con columnas derivadas discordantes están desglosadas. Un [control negativo basal](../scripts/school_waste_placebo_cutoffs.py) compara las dos mitades de cada bloque basal de 40 jornadas: 78 de 96 cortes tienen los componentes completos y **9** muestran una caída de PW+KSW al menos tan grande como los −10,841032 g/comensal del final frente a la última ventana. Los cortes se solapan y el análisis fue posterior a la observación: ese recuento no es un valor p ni estima un efecto. Dos [revisores de modelos](../experiments/development/school_temporal_model_review_2026-09-27.json) recibieron el mismo resumen textual, coincidieron en los límites principales y no inspeccionaron el XLSX ni ejecutaron el toolkit; algunas propuestas inferenciales se descartaron. La revisión no constituye el contraste N/SDD/T del criterio 4. No se estimó efecto ni se cambió el veredicto del criterio 3.

El [piloto textual de desarrollo](../experiments/development/school_design_text_pilot_2026-09-27/v2/findings.md) aplicó N, S y A-M manual a una tarea común sobre ese caso, con Gemini Low, Gemini High y MiniMax M3: nueve respuestas de dos familias. Ocho cumplieron el límite de 900 palabras; dos juezas puntuaron las nueve antes de revelar el mapa, pero la nota de la respuesta larga se conserva solo como suplementaria. En los cuatro pares primarios completos, A-M−N/A-M−S fue `+7/+8,5` en Gemini Low y `+9,5/−4` en MiniMax. El primer rechazo de ruta seguido de una revisión v2 incumplió la prohibición de sustitución del protocolo original. La ceguera efectiva, la configuración aplicada por el proveedor, tokens y coste no están autenticados. A-M no ejecutó el toolkit ni hubo réplicas; estos resultados no cambian el veredicto **No demostrado** del criterio 4 ni prueban el criterio 3.

El [expediente de pan noruego](../cases/bread_norway/README.md) selecciona una cadena real documentada por un ACV y audita sus [fuentes y huecos](../cases/bread_norway/source_audit.md). Hay datos publicados de molienda, panificación y distribución, pero cultivo y parte del consumo son modelados o estimados; no se dispone de registros por lote que unan producción y hogares. Los escenarios de empaque no miden menos desperdicio atribuible. El expediente sirve para diseñar una solicitud de datos y un ensayo prospectivo, sin convertir cifras de Egipto, Italia o Suecia en observaciones de Noruega. Criterio 3 permanece **No demostrado**.

El [flujo documental de pan](../cases/bread_norway/frame_manifest.json) ejecutó 19 ítems, con nueve evidencias de dos PDF archivados, en un caso real con política `signed`. Un actor con etiqueta distinta revisó el encuadre de `frame`; el replay histórico avanzó a revisión 21 y `critique` se detuvo ante `n_bread_harm requires a verified human approval`. La [sonda CLI/MCP histórica](../experiments/development/bread_frame_cli_mcp_2026-09-27.json) cotejó cinco lecturas mediante un cliente stdio real, dos replays de 20 pasos sin eventos nuevos y el rechazo sin mutación de un manifiesto inválido. El ledger actual conserva esos eventos, pero la revisión carece de firma y `frame.accepted=false`. La diferencia de etiquetas no acredita independencia de personas ni autoridad. No se aprobaron valores, no hubo intervención ni efecto de campo, y el criterio 3 sigue **No demostrado**.

El [análisis secundario de la encuesta](../experiments/development/bread_survey_bounds_2026-09-27.json) fija el PDF y la transcripción de su tabla 1, comprueba las siete frecuencias publicadas y calcula límites descriptivos a partir de 1.000 respuestas: 97 hogares declaran al menos siete rebanadas semanales, con rango 9,7–13,0 % al asignar los 33 «no sabe»; la suma mínima declarada es 1.720 rebanadas y la categoría abierta impide una cota superior finita. Una revisión independiente detectó que dos frecuencias podían cambiar de forma compensada conservando el total y el hash del PDF; el analizador ahora rechaza esa transcripción alterada. Son estimaciones autodeclaradas de pan fresco en general, sin incertidumbre muestral calculada ni línea base del pan seleccionado. `critique` y el criterio 3 continúan **No demostrados**.

El [cotejo nuevo de contenido de los PDF del pan](../experiments/development/bread_pdf_content_binding_2026-09-27.json) verifica las nueve cifras del manifiesto y ledger contra pasajes publicados y fija el texto y alcance de esas nueve afirmaciones del caso. El revisor independiente reprodujo primero falsos verdes de valor o procedencia escritos en texto y de un campo adicional que afirmaba vínculo doméstico por lote; el chequeo final rechaza esos expedientes incluso con cadena de hashes reconstruida. Pasaron 31 pruebas focales y el replay CLI/MCP. Los dos locators que citan además la tabla 1 para masa y origen del trigo tienen la sección correcta, usada por el parser. La extracción depende de Poppler y el texto fijado es un contrato revisado de este expediente, no validación semántica general. No aparecen registros unitarios de la cadena ni efectos de intervención; criterio 3: **No demostrado**.

La [nota prospectiva sobre perjuicios](enmiendas_protocolo.md#2026-09-27--registro-pendiente-de-perjuicios-por-actor-y-etapa) registra que §5.2 nombra agua, tiempo y distribución de daños, mientras la fila 3 de §7 cuantifica solo algunos márgenes. Antes de asignar grupos faltan resultados, fuentes y márgenes aprobados por actor y etapa. La nota no cambia umbrales tras conocer resultados ni autoriza un ensayo.

El [control alimentario de fuentes declaradas](../experiments/development/field_source_controls_2026-09-26.json) reprodujo cuatro falsos verdes de desarrollo: fuentes de inocuidad o nutrición fechadas antes de la salida del producto, o copiadas de otro grupo. El preflight ahora exige fecha no anterior a la salida y `load_id` coincidente en ambas fuentes; acepta observaciones retrospectivas dentro del período. Los identificadores y fechas son autodeclarados: no autentican la muestra ni prueban impacto.

La [regresión de consumo y fuentes terminales](../experiments/development/field_consumption_lineage_2026-09-26.json) cerró dos falsos verdes del esquema 2: fuentes terminales copiadas de otra carga y una ruta completa que ocultaba otra rama consumida demasiado corta. El [contraejemplo de mezcla](../experiments/development/field_mixing_limit_2026-09-26.json) sigue pasando esquema 2 con balance 140/140 aunque la entrada de ruta larga pueda salir toda a compost. La [regresión de esquema 3](../experiments/development/field_schema3_conservative_lineage_2026-09-26.json) rechaza esa asignación, acepta 20 kg declarados de ruta completa y rechaza un falso enlace en dos mezclas sucesivas. La revisión independiente encontró y ayudó a corregir falsos rechazos por ignorar asignaciones incidentes, ramas que convergen antes de etapas comunes y complementos exactos de filas. Pasaron 96 pruebas focales. Todo es sintético y declarativo: no hay observación de campo ni cálculo de `V` o `G`.

La [regresión histórica de transferencia de Citi Bike](../experiments/development/citibike_transfer_replay_2026-09-26.json) sembró el expediente en un caso temporal y reprodujo la revisión de `s_proxy` mediante la CLI instalada. Confirmó 12 descendientes obsoletos, el requisito candidato en la traza, `frame` aceptada entonces por diferencia de etiquetas y el bloqueo de `critique` y `specify`; una aprobación sin firma no modificó el ledger. La prueba actual usa una clave de revisor efímera en una copia temporal para ejercitar la nueva compuerta; el ledger original conserva revisión sin firma y `frame.accepted=false`. No se descargó el feed ni se calculó disponibilidad o efecto. Las cadenas literales de bloqueadores en `revision_check.json` corresponden al motor de cuando se produjo esa salida; la regresión coteja el estado semántico vigente.

## Distinciones que deben mantenerse

El funcionamiento técnico probado corresponde a las rutas ensayadas, no a todas las condiciones de aceptación. El rigor de las compuertas se prueba con controles sintéticos y revisión documental. Los casos reales usan `approval_policy="signed"`; la verificación criptográfica liga la decisión al caso registrado, la cabeza previa del ledger y la revisión exacta, mientras identidad y autoridad humana siguen requiriendo un proceso externo. La clave Ed25519 del smoke se generó en memoria para un caso sintético: no representa consentimiento humano. Una fixture solo puede aprobar con `ORGANON_ALLOW_FIXTURES=1` en una ruta no registrada; sin esa variable, su ledger se lee pero la compuerta no acepta la aprobación simulada. Los resultados simulados y de fixture no demuestran mejora material. La ventaja metodológica frente a trabajo libre y SDD no se infiere del número de documentos o de que el grafo supere un control sintético.

## Evidencia reproducible y pendientes externos

- [Preparación N/S/T desde la entrega](../experiments/development/staged_visible_run_2026-09-27.json): el stage privado validó un calendario candidato y una entrega por vez, copió solo los insumos visibles, extrajo el ZIP del caso, dejó `work/` vacío y excluyó bytes ocultos. Una T sintética con el bundle real CPython 3.11 conservó su SHA-256 y target. Regresiones posteriores bloquean cambios del ZIP durante extracción, mutación del árbol extraído, enlace simbólico en `work` y un error después de escribir el manifiesto temporal; una prueba nueva conserva los límites del calendario verificado aunque el llamador altere su objeto en memoria. `stage.json` declara `execution_ready: false`; faltan aislamiento, topes reales, proveedor, recibos y custodia. El criterio 4 sigue `not_assessed`.
- [Relectura del stage](../experiments/development/staged_readback_2026-09-27.json): 26 pruebas del verificador y 41 junto al publicador cubren N/S/T, bundle, estructura, permisos, mutaciones y lectura sin escritura. Una revisión independiente reprodujo un falso verde: el ZIP fijado tenía un tráiler inválido, pero una sustitución temporal del ancestro daba al inspector por ruta una copia limpia. La inspección ahora usa el descriptor fijado o bytes capturados desde él; el mismo ataque y su control sin sustitución fallan. La suite completa pasó 954 pruebas. Es una verificación puntual contra un calendario no autenticado, sin sello, ejecución ni defensa contra alteración posterior; el criterio 4 sigue `not_assessed`.
- [Ejecución local de herramienta N/S/T](../experiments/development/staged_local_tool_sealed_2026-09-27.json): tres stages sintéticos ejecutaron una herramienta con los bytes sellados en `memfd`, generaron el mismo entregable y conservaron insumos visibles y recibos separados; `provider_calls: 0`, `measured_tokens: null`, `runtime_image_verified: false` y `criterion_4: not_assessed`. La revisión independiente reprodujo sustituciones del ejecutable y política entre comprobaciones y ejecución, y un falso rechazo de directorios de trabajo; tras reparar, confirmó sellos `0xf`, escritura al descriptor denegada y repetición de los swaps. Pasaron 39 pruebas focales, 1093 globales y Ruff. El sello cubre los bytes del programa lanzado, no el intérprete, bibliotecas o stage frente a carreras del mismo UID. No hay proveedor, presupuesto global, custodia ni comparación de calidad; el criterio 4 sigue **No demostrado**.
- [Interrupción dentro del commit](../experiments/development/ledger_commit_crash_2026-09-27.json): una CLI de wheel instalado murió con `SIGKILL` antes y después de `os.replace` al publicar el segundo ítem; las revisiones recuperadas fueron 1 y 2, y MCP reanudó el mismo manifiesto hasta 3 sin duplicados ni cambio de bytes en replay. Se repitió en Python 3.11 y 3.12; el control de hook ausente falló bajo ejecución normal y optimizada. No prueba persistencia ante apagón o caída del host ni todos los puntos de interrupción; el criterio 1 sigue `not_assessed`.
- [Bundle T para CPython 3.11](../experiments/development/released_toolkit_bundle_py311_2026-09-26.json): 28 dependencias se cotejaron por nombre, tamaño y SHA-256 con `uv.lock`; el ZIP se reconstruyó byte idéntico y pasó el gate de una entrega T sintética con el target 3.11. Desde los bytes copiados se instalaron offline 29 paquetes en un entorno CPython 3.11.15 nuevo; `uv pip check` y el smoke CLI/MCP pasaron. CPython 3.12.3 rechazó `cffi` de ABI `cp311`. El inspector conserva `static_format_checked: false` y `execution_ready: false` porque no abre los interiores dependientes ni comprueba aislamiento, topes, proveedor o custodia. El criterio 4 sigue `not_assessed`.
- [Instalación offline acotada](../experiments/development/offline_wheelhouse_py312_2026-09-26.json): 28 wheels descargados coincidieron con los hashes/tamaños de `uv.lock` y, junto con SpecOrganon, permitieron instalar sin red, índice ni caché en CPython 3.12.3 linux-x86_64. `uv pip check` y el smoke sintético instalado pasaron; el mismo conjunto falló en 3.11.15 por ABI de `cffi`. En ese corte, el wheelhouse fue temporal y no se liberó en T; tampoco prueba proveedores, límites o aislamiento. El criterio 4 sigue `not_assessed`.
- [Inspección estática T](../experiments/development/toolkit_wheel_static_2026-09-26.json): el wheel reconstruido pasó estructura ZIP y `RECORD`, módulos, dependencias declaradas y entrypoints, con SHA-256 `b06599f47ba8913e046ebd38c4ee14cea41ab28167c610d8fc4e8442bbc5085a`. Pasaron 34 pruebas del inspector y 10 del gate N/S/T; en ese corte el total era 845. Reproducciones independientes de ancestro sustituido y árbol de ZIP imposible fallan después de corregirlas. Ese wheel T puro no incluye las dependencias, y la inspección no instala ni ejecuta; `execution_ready: false` y criterio 4 `not_assessed`.
- [Formatos visibles y gate de entrega](../experiments/development/released_payload_format_2026-09-26.json): 41 pruebas del ZIP, 37 de política y 9 de inspección integrada pasaron; la suite completa sumaba 810 en ese corte. D-E se empaquetó dos veces con bytes idénticos y se extrajo con igualdad de sus tres fuentes. Una carrera real de ancestro y rutas padre simbólicas se corrigieron tras revisión; otra revisión no halló falsos verdes pendientes dentro del contrato offline. Los controles no aplican la política, no instalan T, no detectan respuestas parafraseadas y no prueban aislamiento, proveedor ni reserva sellada; el criterio 4 sigue `not_assessed`.
- [Bundle T liberado en desarrollo](../experiments/development/released_toolkit_bundle_py312_2026-09-26.json): un ZIP de 9 688 897 bytes contiene el wheel local, 28 wheels dependientes y `uv.lock`; su SHA-256 exterior es `3606e7862cc5fd10686827b909b28bfef29ac42e29f427d03c275b5f640444c7`. El preflight lo copió como único activo T de una corrida sintética; su copia pasó inspección de contenedor, wheel raíz, lock y digests. Extraída la copia, un entorno nuevo de CPython 3.12.3 instaló 29 paquetes con índice y caché deshabilitados, pasó `uv pip check` y el smoke sintético de 14 comandos CLI y 14 herramientas MCP; CPython 3.11.15 rechazó `cffi` de ABI `cp312`. Pasaron 885 tests y Ruff. El inspector no abre internamente los wheels dependientes, por lo que informa `static_format_checked: false` y `execution_ready: false`; la instalación solo cubre ese destino y host. El ZIP local está bajo `dist/`, ignorado por Git, sin custodia externa. No hay aislamiento, topes aplicados, recibos autenticados ni matriz de modelos o campo; el criterio 4 sigue `not_assessed`.
- `uv run pytest -q` ejecuta pruebas funcionales y adversariales; el [registro técnico complementario](../experiments/development/technical_followup_2026-09-26.json) conserva la iteración anterior de 97 tests, comandos, wheel, resultados y límites. El [registro de preparación de matriz](../experiments/development/matrix_preflight_2026-09-26.json) separa las 68 pruebas nuevas y su alcance. `python3 prototypes/compare.py --output prototypes/results/compare.json` más `python3 prototypes/check_results.py prototypes/results/compare.json` comprueban los 33 escenarios mecánicos.
- `uv build --wheel` y el procedimiento de [README](../README.md#instalar-y-verificar) ejecutaron el wheel endurecido en Python 3.11.15 y 3.12.3. Cada salida informó `phases_accepted=9`, `items=29`, `decisions=11`, `revision=49`, 14 comandos CLI, rechazo de entrada inválida y replay idempotente. En una verificación anterior, `tests/test_interfaces.py` pasó 3/3 en cada instalación y descubrió las 14 herramientas MCP; el smoke actual invocó las 14 y probó precondiciones de versión. En ambos smokes, `approval-challenge` CLI y `approval_challenge` MCP produjeron el mismo mensaje sin mutación; `approve` rechazó firma ausente o inválida, aceptó una firma Ed25519 sintética por MCP y perdió la aprobación efectiva al retirar el registro de confianza.
- [Recuperación en wheel instalado](../experiments/development/wheel_recovery_2026-09-26.json): dos entornos nuevos ejecutaron CLI→`SIGKILL`→MCP, preservaron checkpoints y no duplicaron eventos ni alteraron el ledger en replay. Conservaron dos escrituras CLI protegidas y actores declarados distintos; no se afirma que sus lecturas se solaparan.
- [Paridad CLI/MCP instalada](../experiments/development/wheel_transport_parity_2026-09-26.json): 13 operaciones en casos gemelos y desafío de firma en el mismo caso, con efectos y no mutación verificados; aprobación firmada exitosa por ambos transportes en un escenario sintético.
- [Prueba multiagente](prueba_multiagente.md): autor y revisor nativos completaron 29 ítems y nueve revisiones de fixture; dos escritores nativos sobre ítems disjuntos conservaron 41 eventos sin solapamiento observable. Una prueba sintética de desarrollo posterior conserva la primera ronda negativa y, tras reintentos, un segundo ledger con 81 eventos, 80 IDs de escritores disjuntos, 80 cambios de actor y 487 098 218 ns de solapamiento de intervalos activos. `python3 scripts/check_native_overlap.py` verifica los archivos archivados; no hay condición control de un solo agente ni matriz de modelos/esfuerzos.
- [CLI directa de agentes nativos](../experiments/development/native_direct_2026-09-26.json): primer intento serial y segunda ronda con barrera bloqueante, 20 eventos alternados y 387 033 229 ns de intervalos solapados; el nuevo verificador comprueba guardas, salidas, recibos y ledger. Es desarrollo sintético con pausas inducidas, no una medida de beneficio.
- [Fuentes alimentarias por carga](../experiments/development/field_source_controls_2026-09-26.json): el antes/después reproduce cuatro aceptaciones falsas y su rechazo posterior; 57 pruebas focales verifican cronología, enlace de carga y controles positivos. La fuente física no queda autenticada y `criterion_3` sigue `not_assessed`.
- [Control de etapas alimentarias declaradas](../experiments/development/field_stage_witness_2026-09-26.json): este registro documenta el primer contrato de esquema 2, que exigía un camino testigo de operaciones enlazadas por grupo/período con producción, almacenamiento, transporte, dos transformaciones y consumo. Rechaza grafos abreviados y roles repartidos por ramas, sin alterar la aceptación explícitamente limitada del esquema 1. El camino no prueba qué material siguió cada salida de una operación mezclada, ni todas las ramas o fuentes físicas; `criterion_3` sigue `not_assessed`.
- [Testigo por consumo y carga](../experiments/development/field_consumption_lineage_2026-09-26.json): 84 pruebas focales cubren el contrato actual de esquema 2, rechazan fuentes terminales de otra carga y una rama consumida corta al lado de otra completa, y aceptan dos ramas completas con testigos separados. El esquema 1 y la mezcla dentro del lote conservan límites explícitos; `criterion_3` sigue `not_assessed`.
- [Preparación de matriz](preparacion_matriz.md): `scripts/plan_confirmatory.py` genera solo un calendario candidato a partir de hashes suministrados; `scripts/analyze_confirmatory.py` comprueba su estructura y calcula diferencias e intervalos de `Q` cuando se le entregan puntuaciones. No existe registro sellado, custodia de casos, ejecución, telemetría, doble evaluación ciega ni análisis de todos los umbrales. El [panel investigado](panel_modelos_preliminar.md) no está congelado.
- [Preflight de activos](preparacion_matriz.md#comprobación-de-bytes-y-paquete-de-una-corrida): `scripts/preflight_assets.py` coteja bytes de 15 archivos con un calendario candidato y libera solo los visibles para un `run_id` en un directorio nuevo. Sus 24 tests de desarrollo incluyen CLI real, alteraciones, referencias ausentes y selección N/S/T. La [evidencia de preflight](../experiments/development/asset_preflight_2026-09-26.json) registra alcance y límites: no prueba que los archivos estén sellados, sin respuestas incrustadas o bajo custodia independiente.
- [Entrega y observación local](preparacion_matriz.md#comprobación-de-bytes-y-paquete-de-una-corrida): `scripts/verify_released_run.py` coteja una entrega con un calendario candidato separado y rechaza manifiestos, roles, bytes o rutas alterados; `scripts/observe_development_run.py` comprueba materiales y trazas del piloto D-E y vuelve a derivar el uso agregado. Pasaron 46 y 33 pruebas focales, incluidas integraciones con el runner y CLI falsas Codex/Agy. Dos revisiones independientes no encontraron fallos pendientes dentro de los contratos locales. Ninguna ruta ejecuta proveedores, autentica coste, prueba topes globales ni emite intentos de recibo para corridas reservadas; el criterio 4 sigue `not_assessed`.
- [Firma y recibos de desarrollo](preparacion_matriz.md#firma-offline-del-diseño-candidato): el desafío exige el hash original de GOAL.md, protocolo y 15 activos; el verificador comprueba Ed25519 contra una clave pública suministrada por separado. El auditor de recibos comprueba orden, reintentos y límites en declaraciones sintéticas. La [evidencia técnica](../experiments/development/matrix_controls_2026-09-26.json) registra pruebas y límites: aún falta custodia independiente, proveedor real y evaluación ajena a los ejecutores.
- [Conciliación, juicios y flujos](../experiments/development/measurement_controls_2026-09-26.json): el cotejo exige recibo terminal y digest del artefacto para cada `Q`; el auditor ciego preserva dos juicios y el arbitraje exigido; el preflight alimentario detecta balances y tiempos imposibles en un grafo declarado. Son contratos ensayados con datos sintéticos, sin firma de custodio, proveedor ejecutado, evaluadores acreditados ni campo observado.
- [Ensamblaje de Q](../experiments/development/rated_q_assembly_2026-09-26.json): vincula juicios por ID opaco con corridas mediante un mapa privado y distingue digests terminales y cegados. Conserva faltantes, arbitraje y `E` por corrida como declaraciones; no verifica el acta de preparación ni los bytes. Sus 31 pruebas del ensamblador son sintéticas.
- [Cotejo de actas preexistentes](../experiments/development/preparation_records_2026-09-26.json): 15 pruebas históricas verificaron archivo crudo, vínculos, intento y receta declarados; FIFO, intercambio S/T, extras durante lectura y destinos incorrectos fallaron sin revelar el mapa privado. El [control cronológico](../experiments/development/preparation_rating_chronology_2026-09-26.json) amplió a 19 las pruebas focales y coteja la fecha declarada del acta con el primer bloqueo declarado de `Q`. No autentica custodia, bytes fuente ni cuándo ocurrió realmente ese bloqueo.
- [Rechazo vigente de ítems](../experiments/development/item_review_rejection_2026-09-26.json): bloquea fases antes aceptadas hasta revisar y avanzar de nuevo; los snapshots de tres ledgers existentes permanecen válidos. El wheel corregido pasó en dos versiones de Python, con datos sintéticos.
- [Análisis secundario](../experiments/development/secondary_metrics_2026-09-26.json): coteja calendario, recibos, ensamblaje y mediciones declaradas; recalcula `E`, mantiene el peso igual por modelo, suma tokens de reintentos y no convierte faltantes o una mediana S nula en una ventaja. Sus pruebas son sintéticas. Ningún puntero hash demuestra custodia, proveedor, evaluador, evento o factura.
- [Incertidumbre secundaria](../experiments/development/secondary_uncertainty_2026-09-26.json): aplica las mismas remuestras pareadas a `E/T/R/W/P` y conserva costes decimales exactos. La revisión detectó y corrigió redondeos de sumas e IC con magnitudes mixtas; los intervalos son marginales y derivan solo de entradas declaradas.
- [Controles de integridad](../experiments/development/integrity_controls_2026-09-26.json): documenta la resolución de pares cuantitativos, fuentes prospectivas declaradas de campo y cotejo de actas/parejas terminales en el análisis secundario. La revisión independiente encontró la suite de 452 tests verde, sin autenticar ninguna fuente externa.
- [Escrituras concurrentes protegidas](../experiments/development/guarded_put_2026-09-26.json): el motor exige versiones explícitas para reintentos internos seguros, el runner fija referencias externas y una prueba fuerza una colisión entre dos procesos. El wheel final pasó el smoke en Python 3.11.15 y 3.12.3. Solo comprueba exactitud bajo el contrato ensayado; no acredita agentes reales, ganancia de velocidad ni contexto semántico fuera de las referencias directas.
- [Sondeo GBFS de desarrollo](../experiments/development/citibike_gbfs_probe_2026-09-26.json): registra una lectura pública única, hashes y fallos de tipo de indicadores. Los bytes no se conservaron y el feed mutable no permite repetir exactamente esa observación; el resultado suspende, no estima, la disponibilidad por estación.
- [Replay documental de Citi Bike](../experiments/development/citibike_transfer_replay_2026-09-26.json): una prueba con la CLI instalada y una copia temporal coteja 30 cargas iniciales, revisión 31, 12 obsoletos, traza, compuertas y rechazo de firma ausente sin modificar el expediente comprometido. No es una serie de estaciones ni reserva ciega; `criterion_5` sigue `not_assessed`.
- [Inventario del wheel instalado](../experiments/development/interface_wheel_inventory_2026-09-26.json): dos entornos nuevos, Python 3.11 y 3.12, invocaron todos los comandos y herramientas MCP públicos, con efectos sintéticos inspeccionados. No representan aprobación humana ni observación de campo.
- [Mango](../cases/mango/organon.json) y [Citi Bike](../cases/citibike/organon.json) conservan trazas versionadas. Las decisiones de valor siguen sin aprobación humana auténtica.
- Para intentar los criterios 3–5 hacen falta sitio y permisos de campo, participantes/actores que fijen equivalencias y umbrales, datos de resultado, acceso a modelos y telemetría comparable, evaluadores independientes, presupuesto aprobado y una nueva reserva que no se haya visto durante desarrollo. El protocolo propone recursos, pero no autoriza gasto ni ensayo.
