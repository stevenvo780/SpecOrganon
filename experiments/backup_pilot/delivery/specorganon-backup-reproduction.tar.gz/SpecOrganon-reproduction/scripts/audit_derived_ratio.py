"""Checkout wrapper for the installed ``python -m specorganon.ratio_audit`` route."""

from __future__ import annotations

import sys
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from specorganon.ratio_audit import main


if __name__ == "__main__":
    raise SystemExit(main())
