# Distancia hasta la validación de GOAL

## MVP local activado

El [recorrido local](uso_local.md) ya produjo dos entregas con nueve fases,
revisión entre agentes, ejecución real, replay y control de invalidación.
Está disponible para proyectos en un workspace de confianza, usando los
recursos presentes. [Verificación](../experiments/development/mvp_local_2026-10-01/results.md).
Los criterios finales de GOAL siguen separados; este hito no declara
superioridad frente a SDD ni eficacia causal alimentaria. Los apartados
siguientes describen las etapas y cortes anteriores.

## Hito inmediato acordado · 2026-10-01

Primero cerraremos el [MVP usable](mvp.md) con proyectos locales y recursos
presentes. Su activación exige una entrada clara, un resultado útil
comprobado, revisión técnica y reanudación. Las puertas del estudio
confirmatorio descritas debajo siguen pendientes para sus propias
afirmaciones; no son requisitos para empezar todos los proyectos del MVP.
GOAL y los criterios finales conservan su alcance. El hito todavía no se
declara cumplido.

## Actualización D-124 · 2026-10-01 UTC

El [ingreso de evaluaciones](../experiments/development/external_rating_ingress_2026-10-01/README.md)
ya lee originales privados sin modificarlos y verifica formato/hashes.
87pruebas por Python3.11/3.12 y siete CLI sintéticos por intérprete; incidentes
visibles incluso con suma100 y declaraciones de identidad/independencia/
custodia sin verificar. P2 de archivado `..` corregido y cerrado por revisión;
fuentes, originales, archivos y evidencia anterior preservados.

La [activación siguiente](../experiments/development/external_rating_ingress_2026-10-01/next_activation.md)
requiere personas competentes y custodia, elección del dueño y autorización
de gasto/acceso, telemetría y medidas reales. El dueño indica un revisor y
custodio disponibles; se pidió aclarar si son personas distintas. Competencia,
independencia, custodia y cegamiento efectivos aún no verificados; el panel
confirmatorio sigue pendiente. La respuesta no autoriza gasto.
Luego doceR1→adaptación/freeze→doceR2/selección→confirmación→campo/transferencia.
**C1 técnico; C2–C5 No demostrado; 0/24.** Ninguna nota sintética equivale a Q
humana, ni repetir estos controles demuestra aporte o impacto real.
Los cortes siguientes permanecen históricos.

## Actualización D-123 · 2026-10-01 UTC

La [entrada controlada](../experiments/development/authorized_route_entry_2026-10-01/README.md)
ya permite futuros steps reales ligados a una declaración del operador;
los gates sólo probaron loopback sintético y rechazo OpenAI sin permiso.
74pruebas por Python3.11/3.12, seis controles completos A/B/C,
146CLI/110sends completos más dos incomplete retenidos. Uso declarado7µUSD
y reserva133µUSD son columnas alternativas por run, no sumables ni factura.
Archivos y fuentes conservados; fallos/timeouts anteriores explícitos.

La [puerta siguiente](../experiments/development/authorized_route_entry_2026-10-01/next_activation.md)
mantiene pendientes elección/autorización/acceso, identidad/esfuerzo/consumo
efectivos y evaluaciones externas con H/costos completos. El ingreso de
evaluaciones puede adelantarse sin API y sin asignar Q. Espera local acotada
no acredita cancelación remota; indeterminate no se reejecuta.
**C1 técnico; C2–C5 No demostrado; 0/24.** Ningún gate autoriza gasto/R1.
Los cortes anteriores siguen históricos.

## Actualización D-122 · 2026-10-01 UTC

La [propuesta R1](../experiments/development/real_route_proposal_2026-10-01/README.md)
ya fija opciones Astra/Luna `high`, recursos comunes, cuatro bundles
build/verify originales y cotas condicionales de tokens de modelo.
Saldo propuesto: USD 60 Astra o USD 0,60 Luna para doce R1, sin selección
ni autorización. No son costes completos ni evidencia de calidad.
El [registro de puertas](../experiments/development/real_route_proposal_2026-10-01/readiness.md)
identifica transporte real, alias/snapshot, uso/incomplete, capacidad,
evaluación y decisiones del dueño. No se ha ejecutado una celda formal:
**C1 técnico; C2–C5 No demostrado; 0/24.** El corte D121 siguiente permanece
como historia; sus capacidades locales siguen vigentes y sus pendientes de
tarifas/configuración se precisan aquí sin declarar la ruta operativa.

**Corte:** 2026-10-01 UTC, revisión D-121. Este documento resume las puertas para pasar del desarrollo a pruebas externas. Los requisitos y el veredicto completo están en [GOAL.md](../GOAL.md), [la auditoría actual](validacion_actual.md) y [el protocolo prospectivo](protocolo_experimental.md). El [inventario D-109 de 24 celdas](../experiments/development/activation_readiness_2026-09-30/planned_development_cells.json), el [contrato común D-118](../experiments/development/coordinated_contract_2026-10-01/README.md), el [runtime persistente D-119](../experiments/development/coordinated_runtime_2026-10-01/README.md), el [lector D-120](../experiments/development/coordinated_measurement_2026-10-01/README.md) y el [observador D-121](../experiments/development/coordinated_observation_2026-10-01/README.md) son desarrollo mecánico: cero celdas formales. Este documento no cambia umbrales ni autoriza llamadas a proveedores, gasto o intervención de campo.

| Criterio de GOAL | Evidencia actual | Puerta pendiente |
| --- | --- | --- |
| 1. Funcionamiento completo | **Cumplido en alcance técnico.** El wheel D-107 pasó instalación limpia, workflows de nueve fases y **23/23 operaciones públicas por CLI y cliente MCP real** en Python 3.11 y 3.12, con efectos, interrupción y reanudación verificados; D-108 reutilizó ese wheel sin cambiar producción. [Recibos y límites D-107](../experiments/development/indicator_retirement_2026-09-30/README.md). | Conservar la paridad técnica al cambiar el producto. Custodia, autoridad humana, comparación y campo se evalúan en C2–C5; su ausencia no revoca este veredicto técnico. |
| 2. Integridad metodológica | Hay controles e inyecciones adversariales de desarrollo, linaje versionado y bloqueo de revisiones sin firma. D-107 añadió retiro explícito sin ocultar historia; D-108 enlazó una derivación documental, pero no los cuatro indicadores de intervención. | Banco **sellado** de 21 inyecciones y auditoría externa de todos los requisitos e indicadores de R-F/R-M; revisores competentes, procedencia y anclas bajo custodia independiente. |
| 3. Resolución alimentaria | Fuentes publicadas, preflights y derivaciones documentales; **no hay línea base actual enlazada ni ensayo de intervención**. La energía D-108 no mide eficacia. | Sitio y permisos, valores aprobados, diseño y potencia defendibles, originales custodiados y resultado causal hasta consumo con daños y costes por actor. |
| 4. Aporte frente a N y SDD | Tres prototipos y ensayos expuestos; la terna D-099 solicitó Luna seis veces, pero no produjo `Q`, telemetría y costes autenticados ni una de las 24 celdas del desarrollo predefinido. D-089–D-092 usan proveedor falso para los controles de presupuesto. | Cerrar primero dos rondas/24 celdas A/B/C; luego candidato congelado, panel y reserva N/S/T, topes globales efectivos, telemetría/versiones/costes verificables, trío real, jueces ciegos y ablaciones. |
| 5. Generalización | Citi Bike es desarrollo expuesto: D-107 preservó la historia de retiro y enlazó la reproducción documental, sin fases aceptadas ni transferencia reservada. | R-M nuevo y sellado, R-S distinto del desarrollo, especialista de dominio y auditor externo; aplicar el núcleo sin cambios específicos del dominio y evaluar ciclos completos. |

**Veredicto actual: 1/5, C1 cumplido en alcance técnico; C2–C5 no demostrados.** La suite local y las variantes documentales no son puntuaciones `Q`, aprobaciones competentes, reserva independiente ni impacto de campo. No hay una fecha de cierre defendible a partir del número de pruebas.

## Puerta 0: cerrar el desarrollo antes de abrir la reserva

D-121 añade observación nueva de W local, conteos/envíos/tools con reloj
monotónico y boot hash. Freeze `892d6a8`, 88 pruebas por Python 3.11/3.12
y seis controles NUEVOS A/B/C × D-E con 118 CLI/110 count/110 send/66 tools
originales, 770 tokens sintéticos. Cobertura exacta y send dentro de receipts
D119, publicación/guard/replay nativos y conciliación D120. Dos releases
históricos rechazados; fuentes/HEAD/baseline y doce originales intactos.
W incluye pausas/guard/I/O hasta su marca de entrega; no recepción externa,
H o remoto. D118/D119 ya fijaron contrato común y saldo/contexto/claim
preventivos; los nulos D109 son históricos. El freeze R1 real requiere
ruta/modelo/esfuerzo/telemetría/tarifas y autorización concreta, personas
competentes y recursos de revisión. No se pide aprobar placeholders ni
sobres completos del estudio. Ver [siguiente puerta](../experiments/development/coordinated_observation_2026-10-01/next_activation.md).
Los cortes siguientes son históricos; el faltante W D120 queda resuelto
sólo en estos controles locales D121, sin inferir métricas de los runs anteriores.

D-120 agrega conciliación local de request/response/receipt/ledger por
corrida/rol/brazo y herramientas, con snapshot único, guard/replay/publicación
nativos y salida sanitizada. Freeze `8576cc6`, 51 pruebas por Python 3.11/3.12
y doce CLI de lectura de originales D119; fuentes/HEAD y runtimes intactos,
2283 pins iguales durante capturas. Se concilian 113 requests, 69 tools y 791 tokens
sintéticos por entorno, sin reejecuciones ni nuevos sends/tools/celdas.
Coste por request usa tarifa declarada y no factura; send, sandbox/host y lease
se presentan separados. W/H, conteos/actividad remota, desglose completo de
tokens, costes de tools/revisión/puntuación/estudio y ruta real verificable
siguen faltantes. Se necesitan antes de R1 cuando correspondan; no se infieren
ventajas de coste/tiempo de estas medidas. Sólo los docs activos avanzan,
con sus versiones D119 conservadas; los cortes siguientes son históricos.

D-118 fija contrato/rúbrica públicos, información común y 12 IDs R1 con cuatro
roles iguales A/B/C. D-119 implementa los adapters persistentes originales:
init del líder, delegaciones repetidas, replay/merge, análisis final vigente
y reviewer comparten un único ledger/contexto/claim. La admisión del wrapper
coteja la publicación específica D118 y el intérprete registrado; el broker
liga los dos SHA de tool_policy a launchers/ejecutables efectivos y reapertura.
Freeze corregido `7de98c9`, 82 fuentes y 125 rutas históricas preservadas;
317pruebas por Python3.11/3.12,83registros before/after iguales y12recorridos
CLI/HTTP reabiertos por revisión independiente:112CLI/113sends/69tools de
fixture por intérprete, múltiples delegaciones y análisis final vigente.
Archivo37raíces conserva originales y negativos. Respuestas, usage y tarifas locales son
sintéticos: no proveedor autenticado, Q ni permiso de gasto.
Faltan rutas/modelos/esfuerzos autorizados, uso/coste y suma de actividad
efectiva medidos antes de iniciar R1. R2 continúa pendiente de R1 y adaptación
congelada prospectivamente. Los resultados D117/D118 siguientes son históricos.

D-117 cierra el bootstrap C desde work vacío: el líder crea el grafo por init
sellado y comparte ledger/contexto/claim con las ramas D116, reviewer y merge.
Pasaron 98 pruebas por Python 3.11/3.12 y seis trazas originales HTTP/CLI con
herramientas reales y respuestas sintéticas: 14 requests/10 tools cada una,
incluidos 3 requests/2 tools del líder. Ya no recibe un grafo del caller.
Ese cierre mecánico no acredita nueve fases completas, runtimes coordinados
comparables A/B/C, consumo/actividad remotos, proveedor o celda formal.
El prototipo y el motor metodológico tienen modelos de fases distintos; su
continuidad necesita un contrato explícito. Protocolo §2 exige las24 corridas,
sin imponer solo ni las nueve fases internas del toolkit a cada prototipo.
La decisión solo es local del compilador D112. No se relabelan calendarios ni
se entrega a C información factual exclusiva.

D-110–D-113 añaden admisión antes de efectos, contexto compartido, preparaciones
originales y análisis con estado protegido. D-113 conservó fuentes e inventarios,
verificó seis trazas de fixtures por intérprete y cuatro CLI de preparación:
470passed3.11/178passed3.12, proveedor falso. Se resolvieron análisis aislado y
lectura común de PDF; D116 integra análisis y D117 añade arranque sin seed
externo en C. D118 fija preparación y contrato/rúbrica comunes sin respuestas;
faltan ejecución coordinada comparable y ruta/modelo/telemetría/autorización. El
oráculo D-113 valida su contrato de fixtures, no Q ni cualquier output de tarea.
Los topes locales compartidos no autentican consumo/precio/cancelación remotos.

El [protocolo §2](protocolo_experimental.md#2-registro-casos-y-separaci%C3%B3n-entre-desarrollo-y-reserva) exige **24 ejecuciones futuras en total**: tres prototipos A/B/C × dos casos públicos D-F/D-E × dos rondas × dos repeticiones. El [inventario D-109](../experiments/development/activation_readiness_2026-09-30/planned_development_cells.json) enumera las 24 tuplas y deja **cero filas ejecutadas bajo ese diseño**. A/B/C son arquitecturas de desarrollo; **N/SDD/T son brazos de la comparación confirmatoria posterior**. Ni las 33 ejecuciones mecánicas de fixtures, ni los intentos A/B/C parciales de D-094, ni las seis llamadas Luna de D-099 se reclasifican como esas 24 corridas o como evaluación `Q`.

Antes de iniciar una celda se fijan prospectivamente instancia de caso, instrucciones y contrato comunes, versión de cada prototipo, modelo y configuración comparables, orden, límites, registro de fuentes, método de puntuación y coste proyectado. No existe un piloto adicional de seis brazos N/S/T obligatorio antes de estas 24; las seis preparaciones D-E anteriores fueron exploratorias y quedan en sus recibos. Tras la **segunda ronda** se documentan resultados positivos y negativos, se selecciona o combina una alternativa con razones y se congela **una versión candidata**. No se repiten celdas por un resultado desfavorable ni se añaden rondas para obtener una favorable. Si falta una capacidad, se registra NO-GO y la evidencia permanece pendiente.

## Antecedentes técnicos de cortes históricos

Las notas D-074–D-086 siguientes preservan sus recibos y límites originales. Sus menciones de veredictos pertenecen a esos cortes; el veredicto vigente está arriba.

Los controles [D-074](decisiones.md#d-074--vincular-localmente-las-tres-corridas-de-una-familia-a-un-plan-piloto) y [D-075](decisiones.md#d-075--reconciliar-el-denominador-alimentario-declarado-con-cada-entrada-externa) redujeron dos brechas de preparación: fijaron una configuración local por tripleta N/S/T y derivaron el techo aditivo declarado de servicio desde todas las entradas externas. No demostraron por sí solos C2–C5.

Los controles [D-076](decisiones.md#d-076--conservar-autor%C3%ADa-y-procedencia-de-aprobaciones-en-la-revisi%C3%B3n-firmada) y [D-077](decisiones.md#d-077--auditar-fracciones-derivadas-con-contrato-de-unidades-fijado-por-hash) cierran dos falsos verdes locales de revisión y hacen explícitas las unidades de una derivación de movilidad. Son pruebas sintéticas y retrospectivas: no certifican personas, fuente física, reserva de caso ni éxito de GOAL.

La [sonda de nueve fases firmadas](../scripts/probe_signed_full_workflow.py) amplía el control técnico: usa un caso temporal `signed`, dos aprobaciones y nueve revisiones con claves generadas en memoria, verifica el ledger y los artefactos, y comprueba replay y revocación. Su [prueba de instalación](../tests/test_signed_full_workflow.py) reconstruye un wheel y ejecuta CLI y MCP stdio desde un entorno nuevo. Tras [D-078](decisiones.md#d-078--exigir-un-reporte-de-ejecución-firmado-para-cada-test-de-un-caso-real), deriva una copia temporal del manifiesto, ejecuta el `argv` de `t1` sin shell, coteja streams y artefacto y registra el reporte firmado antes de revisar `build`. La fixture original conserva el `passed:true` inventado; ya no habilita por sí solo un caso `signed`. El recibo resumido es reproducible mediante esa prueba; el ledger temporal se elimina al terminar. Ninguna firma de esa sonda pertenece a una persona que haya juzgado el caso o autorizado una intervención, y el motor no inspecciona los bytes que declara el ejecutor.

En los cinco ledgers de casos reales versionados (`mango`, `citibike`, `citibike_march2024`, su derivación de linaje y `bread_norway`), el evento histórico de revisión de `frame` sigue visible. Al releerlos sin una firma de revisor verificada, `frame.accepted=false` y `review_provenance=legacy_unverified`. Para reabrir esa fase hace falta registrar una clave pública custodiada, revisión sustantiva nueva, firma del snapshot vigente y avance nuevo; las etiquetas históricas no demuestran independencia de personas.

El [auditor D-082](../scripts/audit_signed_test_execution.py) permite repetir explícitamente un test `signed` vigente bajo sandbox, con bytes de ejecutable fijados por SHA-256 y cotejo acotado de salidas y artefactos declarados. Un reporte firmado con hashes inventados puede seguir dando `signed_passed` en el motor, pero la repetición no lo confirma. Su resultado distingue firma y observación local; no cambia la compuerta histórica, no ejecuta comandos mediante MCP y no certifica al firmante ni la corrida original.

El [modo D-085](decisiones.md#d-085--exigir-una-repetición-firmada-y-bytes-conservados-en-un-modo-de-test-estricto) permite exigir esa repetición para casos **nuevos** `signed_observed`: fija entrada y ejecutable antes del reporte, registra observación firmada por actor diferente y relee el bundle al evaluar la compuerta. Conserva la política anterior para casos existentes. Una clave y un bundle pueden fabricarse bajo el mismo UID; sin custodia separada no se demuestra que el proceso corrió, por lo que esta capacidad técnica no cierra la puerta de aceptación.

La [sonda D-086](../scripts/probe_signed_full_workflow.py) ejercita ese modo en un workflow completo y no modifica el manifiesto histórico. En entornos limpios Python 3.11 y 3.12 pasó instalación offline, `uv pip check` y el recorrido CLI/MCP con 51 eventos; los [recibos](../experiments/development/signed_observed_full_workflow_2026-09-28/) conservan límites y hashes. Un mismo proceso genera las claves de ejecutor y observador; los bundles se eliminan al acabar la sonda. Es prueba técnica repetible, no custodia externa ni ejecución histórica autenticada.

## Puerta A: ensayo alimentario de campo

Antes de asignar grupos, el operador y un custodio independiente deben fijar un sitio elegible sin mirar desenlaces, permiso de intervención y acceso a originales, grupos separables, control e intervención, estratos, seguimiento hasta consumo y contaminación posible. Los actores competentes deben aprobar las equivalencias que definen el servicio inocuo y útil `V` y los perjuicios, fuentes, unidades, márgenes y reglas de parada por actor y etapa; una firma sobre declaraciones locales no autentica su autoridad ni la observación física. La [preparación de campo](preparacion_campo.md) define las entradas y límites de los auditores.

Se necesitan datos **previos del sitio** de varios grupos con series semanales, volumen basal, fuentes originales y custodia para estimar dispersión y correlación. La [enmienda abierta](enmiendas_protocolo.md#2026-09-27--cuesti%C3%B3n-estad%C3%ADstica-abierta-del-ensayo-alimentario) distingue dos eventos: 80 % de potencia para detectar `G = 0,10` frente a cero y éxito solo cuando el límite inferior del IC 95 % alcanza `0,10`. Un responsable estadístico y los actores competentes deben aprobar el evento de dimensionamiento, un efecto verdadero supuesto y la simulación de cobertura y potencia del análisis previsto antes de asignar. El mínimo técnico de dos grupos por celda brazo × estrato permite intentar el remuestreo; **no garantiza** potencia ni cobertura del intervalo.

**GO para asignar:** registro previo custodiado y aprobado, potencia/cobertura defendibles para el sitio, equivalencias y perjuicios aprobados, permisos y plan de captura/custodia de fuentes. Hasta entonces, `decision_ready:false` y criterio 3 `no demostrado`.

El `service.schema:3` opcional rechaza un denominador inflado frente a las entradas y coeficientes declarados y exige que las reglas y masas coincidan con extractos abiertos antes de una nueva firma. Esa concordancia de bytes no establece que las entradas reales estén completas, que los coeficientes estén aprobados por personas competentes o que el máximo teórico sea factible. Por ello no adelanta el GO para asignar ni permite inferir `V` observado.

## Puerta B: comparación entre modelos

**Canal MiniMax M3.1:** la documentación actual restringe Flash Preview a M Plan
y MiniMax Code. No se acredita acceso por API ordinaria de pago por uso; su
aparición en la documentación de Responses no habilita una ruta facturable.

La comparación **confirmatoria N/SDD/T** se prepara después de cerrar las 24 ejecuciones de la Puerta 0, documentar la selección y congelar candidato y registro previo. La ejecución solo empieza cuando el custodio independiente libera el paquete reservado según el registro. Las preparaciones públicas D-E de seis celdas N/S/T fueron exploratorias: no son una etapa obligatoria entre las 24 celdas y la reserva, ni equivalen a las 24 ejecuciones de desarrollo.

**Antecedente del piloto D-E.** El [dossier offline inicial](../experiments/development/energy_pilot/activation_dossier_2026-09-27.json) fijó hashes de insumos, prompts, rúbrica y wheel **congelados entonces**, enumeró seis celdas sin seleccionar modelos y dejó `no_go_for_provider_calls`. La [sonda inicial](../experiments/development/energy_pilot/offline_preparation_probe_2026-09-27.json) cotejó seis instantáneas `--prepare-only`; la [sonda estricta posterior](../experiments/development/energy_pilot/strict_dossier_preparation_2026-09-27.json) exigió el SHA aportado del dossier y validó sus nueve activos. Ninguna llamó proveedores ni instaló T. El wheel de D-072 tiene otro hash; cualquier nuevo piloto necesitaría dossier nuevo. El modo genérico no impone el dossier y el estricto solo prueba concordancia con el digest aportado por el invocador: ninguno autentica custodia o autoriza ejecución. Para cualquier comparación posterior se fijan **mismo ID, versión, esfuerzo efectivo y demás parámetros de modelo para N/S/T dentro de cada familia**, herramientas genéricas iguales, servicio humano equivalente, aislamiento, topes globales de tiempo/tokens/herramientas, telemetría por solicitud, tarifas, techo de gasto y regla de parada. T mantiene política `signed`; faltan decisiones y revisiones competentes. Los fallos se conservan y no se sustituyen según el resultado.

El [runner D-E](../scripts/run_development_arm.py) y su [observador](../scripts/observe_development_run.py) comprueban bytes y trazas locales. D-080 añade un plazo monotónico acumulado para una invocación; D-081 fija la misma cifra solicitada en N/S/T de un plan local. Ninguno autentica el tiempo declarado ni aplica el límite global de recursos de la [sección 3 del protocolo](protocolo_experimental.md#3-brazos-panel-y-comparabilidad). Tampoco autentican identidad de proveedor, versión, factura o todos los agentes. La presencia de ejecutables locales no demuestra acceso. El [panel preliminar](panel_modelos_preliminar.md) tampoco congela modelos: M3 no cambia profundidad al solicitar bajo/alto y M2.x no ofrece ese contraste; esa pareja histórica MiniMax M3/M2.7 no cumple el esfuerzo efectivo dentro de la familia. La documentación más reciente de MiniMax describe `MiniMax-M3.1-Flash-Preview` con control bajo/alto efectivo, pero sigue siendo **candidato documental**: la ruta consultada en D-109 ofreció M3/M2.7, no M3.1, y faltan acceso, versión estable, telemetría y dos niveles de capacidad verificables en esa familia. Antes de cualquier piloto facturable se requiere autorización específica con acceso, parámetros, telemetría, tarifas y topes verificables de solicitudes, tokens y gasto; una corrida puede hacer múltiples solicitudes facturables. Un piloto adicional de seis brazos sería exploratorio y **no es requisito previo** de las 24 corridas ni satisface C4.

La [ruta D-089 de una solicitud de texto](presupuesto_solicitudes_modelo.md) añade, separadamente, conteo antes del envío, reserva duradera de tokens compartida por roles y conciliación posterior. Sus pruebas usan un proveedor falso y HTTP local. No modifica el runner D-E opaco ni ejecuta sus herramientas; tampoco aplica tiempo activo o límite de llamadas de herramienta. Por ello no habilita el piloto facturable ni cambia el NO-GO anterior.

La [extensión D-090 de conversación](presupuesto_solicitudes_modelo.md) ejecuta dos o más turnos de texto bajo un único ledger y temporizador monotónico del proceso, conserva el `output` completo entre turnos y deja una corrida truncada o incierta sin reintento. La extensión D-091 añade un perfil de tarifas declarado y una reserva de microUSD al mismo ledger; la CLI exige ambos antes de enviar. D-092 enlaza, en una ruta de desarrollo separada, una función de Responses con una herramienta sellada de un stage, dos turnos y el mismo ledger. Sus pruebas son offline. Si el conteo previo difiere del uso informado tras el envío, un cargo real podría superar la reserva. El control no se extiende a varios agentes ni una corrida N/S/T real, y no autentica tarifas, factura o gasto; `global_run_limits_enforced:false` y `criterion_4:not_assessed` permanecen.

La [plantilla lateral D-074 de esquema 1](../experiments/development/energy_pilot/pilot_triplet_plan_template_v1.json) sigue legible para corridas históricas. El modo piloto vivo requiere la [plantilla de esquema 2](../experiments/development/energy_pilot/pilot_triplet_plan_template_v2.json), también NO-GO con modelos, esfuerzos y presupuesto en `null` hasta fijarlos. Un plan completado y fijado por SHA obliga a usar la misma tupla CLI/modelo/esfuerzo solicitados por familia y la misma cifra local de tiempo en N/S/T antes de crear una corrida; el observador relee copias locales, sin autenticar que el vínculo existiera antes de la llamada. El plan no verifica la configuración efectiva ni constituye permiso para llamar un proveedor o gastar. No sustituye los límites, evaluadores ni custodia exigidos arriba.

**GO para iniciar la confirmación:** candidato y 24 ejecuciones de desarrollo exigidas por el protocolo cerrados; cuatro modelos de dos familias y dos niveles de capacidad por familia, con al menos un contraste bajo/alto efectivo por familia; tres casos nuevos reservados bajo custodia independiente; configuraciones solo/trío, réplicas, ablaciones, límites globales efectivos en todos los agentes y herramientas, recibos por solicitud y costes autenticados, revisiones humanas equivalentes, dos jueces finales ciegos y un árbitro tercero separados de quienes revisan fases. También se necesita proyección actual de capacidad y coste antes de solicitar gasto. El [presupuesto máximo propuesto](protocolo_experimental.md#8-presupuesto-parada-y-publicaci%C3%B3n) no es autorización. Mientras falte cualquiera de estas condiciones, criterio 4 `no demostrado`.

El [auditor D-083](../scripts/audit_development_triplet.py) comprueba después de las corridas que las seis carpetas locales correspondan a celdas únicas del plan aportado, compartan insumos y dossier y conserven su uso y estado, incluidos fallos. Su positivo de desarrollo usa CLI falsas y un ledger T con política `signed` declarada, sin firma Ed25519 verificada. Aun si la cobertura local queda completa, informa `signed_toolkit_workflow_verified:false` y `controlled_comparison_eligible:false`; no sustituye los recibos ni límites efectivos del protocolo.

## Insumos externos que desbloquean la siguiente fase

1. **Operador del sitio alimentario:** permisos de intervención, grupos elegibles, datos previos con originales y seguimiento verificable hasta consumo. **Responsable estadístico:** evento de potencia, diseño, cobertura y análisis del sitio antes de asignar grupos.
2. **Actores competentes para cada decisión normativa:** equivalencias de servicio `V`, márgenes y perjuicios por actor y etapa, con identidad y autoridad verificadas fuera del ledger. **Revisores sustantivos de fase:** personas distintas de los agentes ejecutores; su firma y competencia se documentan, y el servicio de revisión es equivalente entre N/S/T.
3. **Custodio independiente del desarrollo y la ejecución:** selección y resguardo de R-F/R-M/R-S, fuentes originales, registro previo y anclas externas, secuencia de liberación y trazas, claves públicas confiadas y mapa de cegamiento. **Especialista de movilidad R-M:** evaluación de fuentes y supuestos del nuevo caso sin reutilizar Citi Bike expuesto.
4. **Evaluación final externa:** dos jueces ciegos que fijen `Q` antes de abrir trazas y un tercer árbitro para las discrepancias previstas; son personas distintas de quienes ejecutaron o revisaron fases.
5. **Comparación de modelos:** acceso legítimo y verificable a dos familias, identidades/versiones y esfuerzos efectivos, telemetría por solicitud y facturación; proyección de recursos y autorización específica para cada etapa facturable.

Las autorizaciones y cuotas tampoco implementan por sí solas el corte global de tokens, tiempo activo y herramientas entre todos los agentes, ni prueban versión, esfuerzo efectivo, uso o coste real. El protocolo propone **USD 72 500 y 1 200 horas humanas**, pero ese techo **no está autorizado**; antes de pedir gasto se necesita una proyección actual por desarrollo, confirmación y campo, con tarifas y capacidad de las personas. D-109 solo prepara el inventario: **cero solicitudes a modelos reales, cero corridas de sus 24 celdas, cero apertura de reserva y cero intervención de campo**. Estas puertas dejan C1 técnico cumplido y C2–C5 no demostrados.
