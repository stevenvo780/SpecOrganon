import os,sys
os.chdir("/fixture/root")
sys.stderr.write('chdir("/tmp") = 0\n');sys.stderr.flush()
os.readlink("link")
import sys
sys.stdout.write('{"files":[{"bytes":3,"path":"probe.txt"}],"symlinks":["link"],"total_bytes":3}\n')
