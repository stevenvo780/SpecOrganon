# PolicyPick

PolicyPick is a strict, deterministic rule-matching engine implemented in standard Python 3.12 without third-party dependencies.

## Installation & Requirements
- Python 3.12+ (standard library only).
- No additional package installation or virtualenv configuration required.

## CLI Interface
Invocations must have no command-line arguments:
```bash
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py
```
Passing any CLI arguments (including `--help`) causes immediate failure prior to reading stdin.

## Input & Output Formats
- **Input**: Exactly one UTF-8 JSON object on standard input (up to 65,536 bytes) with the exact structure `{"rules":[...],"queries":[...]}`.
  - Each rule has `{"name": string, "priority": int, "requires": [strings]}`.
  - Each query has `{"id": string, "tags": [strings]}`.
- **Output**: On success, exit 0, empty stderr, and exactly one line on stdout with `{"decisions":[{"id":...,"rule":...},...]}\n`.

## Limits and Constraints
- Maximum stdin payload: 65,536 bytes.
- Maximum 1,000 rules and 1,000 queries.
- Maximum 1,000 strings in each `requires` and `tags` list.
- Strings: non-empty, maximum 64 UTF-8 bytes, containing no NUL, CR, or LF bytes, and no unencodable surrogates.
- Priorities: JSON integers in `[-1000000000, 1000000000]` (no floats, booleans, or strings).
- Names of rules must be unique among rules; IDs of queries must be unique among queries.
- Duplicate entries inside a rule's `requires` or a query's `tags` are treated as sets and are valid.
- Unknown query tags are ignored; empty requires match all queries.

## Error Handling
Any schema violation, invalid character, duplicate rule/query identifier, duplicate JSON key, NaN/Infinity token, or extra argument results in exit code 2, empty stdout, and exact stderr output:
```json
{"error":"invalid_input"}
```

## Semantics & Tie Breaking
A rule matches if its `requires` set is a subset of the query's `tags` set. When multiple rules match, PolicyPick chooses the rule with the highest priority. If priorities tie, it chooses the rule whose name is minimal in Unicode code point order. If no rule matches, `rule` is `null`.

## Public Examples

### Example 1
Command:
```bash
printf '{"rules":[{"name":"default","priority":0,"requires":[]},{"name":"staff","priority":2,"requires":["internal"]}],"queries":[{"id":"q1","tags":["internal","internal"]},{"id":"q2","tags":[]}]}' | python3 policypick.py
```
Output:
```json
{"decisions":[{"id":"q1","rule":"staff"},{"id":"q2","rule":"default"}]}
```

### Example 2
Command:
```bash
printf '{"rules":[{"name":"z","priority":3,"requires":["x"]},{"name":"A","priority":3,"requires":["x"]}],"queries":[{"id":"yes","tags":["x"]},{"id":"no","tags":[]}]}' | python3 policypick.py
```
Output:
```json
{"decisions":[{"id":"yes","rule":"A"},{"id":"no","rule":null}]}
```

## Test Command
Run test scenarios with Python 3:
```bash
python3 -c '
import subprocess, json

def run(inp, args=[]):
    p = subprocess.run(["python3", "policypick.py"] + args, input=inp.encode("utf-8"), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return p.returncode, p.stdout.decode("utf-8"), p.stderr.decode("utf-8")

# Test 1: Example 1
rc, out, err = run("{\"rules\":[{\"name\":\"default\",\"priority\":0,\"requires\":[]},{\"name\":\"staff\",\"priority\":2,\"requires\":[\"internal\"]}],\"queries\":[{\"id\":\"q1\",\"tags\":[\"internal\",\"internal\"]},{\"id\":\"q2\",\"tags\":[]}]}")
assert rc == 0 and json.loads(out) == {"decisions": [{"id": "q1", "rule": "staff"}, {"id": "q2", "rule": "default"}]}

# Test 2: Example 2 (tie-break on Unicode code points: A < z)
rc, out, err = run("{\"rules\":[{\"name\":\"z\",\"priority\":3,\"requires\":[\"x\"]},{\"name\":\"A\",\"priority\":3,\"requires\":[\"x\"]}],\"queries\":[{\"id\":\"yes\",\"tags\":[\"x\"]},{\"id\":\"no\",\"tags\":[]}]}")
assert rc == 0 and json.loads(out) == {"decisions": [{"id": "yes", "rule": "A"}, {"id": "no", "rule": None}]}

# Test 3: Reject CLI flags
rc, out, err = run("", ["--help"])
assert rc == 2 and err == "{\"error\":\"invalid_input\"}\n" and out == ""

# Test 4: Reject duplicate JSON keys
rc, out, err = run("{\"rules\":[],\"rules\":[],\"queries\":[]}")
assert rc == 2 and err == "{\"error\":\"invalid_input\"}\n"
print("All tests passed.")
'
```
