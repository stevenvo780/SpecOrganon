import hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[1]); c=json.loads((p/'case.json').read_bytes())
observed=[]
for row in c['files']:
 raw=(p/row['path']).read_bytes()
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 observed.append({'path':row['path'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
m=json.loads('{"additional_observation": "No scientific observation is claimed by this synthetic mechanism control.", "appliances_daily": {"2016-12-17": {"base": "original public case", "reason": "Synthetic runtime control; scientific calculation and independent review pending.", "unit": "not evaluated", "value": null}}, "appliances_weekly": {"base": "original public case", "reason": "Synthetic runtime control; scientific calculation and independent review pending.", "unit": "not evaluated", "value": null}, "intervals": {"continuity_checked": false, "count": 0, "issues": ["Interval calculations deliberately pending in the synthetic runtime control."]}, "source_audit": ["Actual readonly script verifies every listed file size and digest. Passage interpretation remains unverified."]}')
m['observed_source_inventory']=observed
m['classification']='synthetic_delivery_structure_not_scientific_results'
print(json.dumps(m,sort_keys=True,allow_nan=False))
