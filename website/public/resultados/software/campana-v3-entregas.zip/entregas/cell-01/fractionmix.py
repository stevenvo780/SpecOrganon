"""Exact rational summation through the FractionMix stdin interface."""

import json
import sys
from math import gcd


class InvalidInput(ValueError):
    pass


def object_without_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidInput('duplicate key')
        result[key] = value
    return result


def reject_constant(value):
    raise InvalidInput('non-JSON constant')


def read_terms():
    raw = sys.stdin.buffer.read(65537)
    if len(raw) > 65536 or raw.startswith(b'\xef\xbb\xbf') or b'\x00' in raw:
        raise InvalidInput('invalid bytes')
    try:
        document = json.loads(
            raw.decode('utf-8', errors='strict'),
            object_pairs_hook=object_without_duplicates,
            parse_constant=reject_constant,
        )
    except (ValueError, UnicodeError, RecursionError) as error:
        raise InvalidInput('invalid JSON') from error
    if type(document) is not dict or set(document) != {'terms'}:
        raise InvalidInput('invalid top-level object')
    terms = document['terms']
    if type(terms) is not list or len(terms) > 1000:
        raise InvalidInput('invalid terms')
    for term in terms:
        if type(term) is not dict or set(term) != {'numerator', 'denominator'}:
            raise InvalidInput('invalid term object')
        numerator = term['numerator']
        denominator = term['denominator']
        if type(numerator) is not int or not -1000000000 <= numerator <= 1000000000:
            raise InvalidInput('invalid numerator')
        if type(denominator) is not int or not 1 <= denominator <= 1000000000:
            raise InvalidInput('invalid denominator')
    return terms


def sum_terms(terms):
    numerator, denominator = 0, 1
    for term in terms:
        other_numerator = term['numerator']
        other_denominator = term['denominator']
        common = gcd(denominator, other_denominator)
        left_factor = other_denominator // common
        right_factor = denominator // common
        numerator = numerator * left_factor + other_numerator * right_factor
        denominator *= left_factor
        reduction = gcd(numerator, denominator)
        numerator //= reduction
        denominator //= reduction
    return {
        'numerator': numerator,
        'denominator': denominator,
        'term_count': len(terms),
    }


def invalid_input():
    sys.stderr.buffer.write(b'{"error":"invalid_input"}\n')
    return 2


def main():
    if len(sys.argv) != 1:
        return invalid_input()
    sys.set_int_max_str_digits(0)
    try:
        terms = read_terms()
    except InvalidInput:
        return invalid_input()
    result = sum_terms(terms)
    output = json.dumps(result, separators=(',', ':'), ensure_ascii=True)
    sys.stdout.buffer.write(output.encode('utf-8') + b'\n')
    return 0


if __name__ == '__main__':
    sys.exit(main())
