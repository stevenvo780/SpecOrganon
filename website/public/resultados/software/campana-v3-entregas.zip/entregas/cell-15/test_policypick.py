import copy
import json
import subprocess
import unittest

CMD = ['/opt/specorganon/venv/bin/python', '-E', '-s', '-B', '/input/delivery/policypick.py']


def rule(name='r', priority=0, requires=None):
    return dict(name=name, priority=priority, requires=[] if requires is None else requires)


def query(identifier='q', tags=None):
    return dict(id=identifier, tags=[] if tags is None else tags)


def doc(rules=None, queries=None):
    return dict(rules=[] if rules is None else rules, queries=[] if queries is None else queries)


class PolicyPickTests(unittest.TestCase):
    def run_input(self, value):
        raw = value if isinstance(value, bytes) else json.dumps(value).encode()
        return subprocess.run(CMD, input=raw, capture_output=True, timeout=3)

    def good(self, value, pairs):
        result = self.run_input(value)
        self.assertEqual((result.returncode, result.stderr), (0, b''))
        self.assertTrue(result.stdout.endswith(b'}\n'))
        body = result.stdout[:-1]
        self.assertEqual(body, body.strip())
        def unique(items):
            result = {}
            for key, item in items:
                self.assertNotIn(key, result)
                result[key] = item
            return result
        self.assertEqual(json.loads(body.decode('utf-8'), object_pairs_hook=unique),
                         {'decisions': [dict(id=i, rule=r) for i, r in pairs]})

    def bad(self, value):
        result = self.run_input(value)
        self.assertEqual((result.returncode, result.stdout, result.stderr),
                         (2, b'', b'{"error":"invalid_input"}\n'))

    def test_examples(self):
        self.good(doc([rule('default'), rule('staff', 2, ['internal'])],
                      [query('q1', ['internal', 'internal']), query('q2')]),
                  [('q1', 'staff'), ('q2', 'default')])
        self.good(doc([rule('z', 3, ['x']), rule('A', 3, ['x'])],
                      [query('yes', ['x']), query('no')]), [('yes', 'A'), ('no', None)])

    def test_selection_and_literal_strings(self):
        rules = [rule('z', -1), rule('é', 9, ['x', 'x']), rule('Z', 9, ['x']),
                 rule('high', 10, ['x', 'y'])]
        queries = [query('z'), query('second', ['x', 'unknown', 'x']),
                   query('third', ['y', 'x'])]
        for ordered in (rules, list(reversed(rules))):
            self.good(doc(ordered, queries), [('z', 'z'), ('second', 'Z'), ('third', 'high')])
        for tag in [' x', 'x ', 'X', 'é', 'e\u0301', '\t', ' ']:
            with self.subTest(tag=tag):
                self.good(doc([rule(tag, 0, [tag])], [query(tag, [tag]), query('miss', ['x'])]),
                          [(tag, tag), ('miss', None)])
        self.good(doc([], [query()]), [('q', None)])
        self.good(doc([rule()], []), [])
        self.good(b' \r\n\t{"queries":[], "rules":[]}\t\n', [])

    def test_limits(self):
        for priority in [-1000000000, 1000000000]:
            self.good(doc([rule(priority=priority)], [query()]), [('q', 'r')])
        for field in ['rules', 'queries', 'requires', 'tags']:
            value = doc([rule()], [query()])
            target = value if field in ('rules', 'queries') else value['rules' if field == 'requires' else 'queries'][0]
            items = [rule(str(i)) for i in range(1000)] if field == 'rules' else [query(str(i)) for i in range(1000)] if field == 'queries' else ['x'] * 1000
            target[field] = items
            expected = [('q', '0')] if field == 'rules' else [(str(i), 'r') for i in range(1000)] if field == 'queries' else [('q', None)] if field == 'requires' else [('q', 'r')]
            self.good(value, expected)
            items.append(copy.deepcopy(items[0]))
            self.bad(value)
        raw = b'{"rules":[],"queries":[]}'
        self.good(raw + b' ' * (65536 - len(raw)), [])
        self.bad(raw + b' ' * (65537 - len(raw)))

    def test_string_validation_every_position(self):
        for field in ['name', 'requires', 'id', 'tags']:
            for text in ['a' * 64, 'é' * 32, '', 'a' * 65, 'é' * 32 + 'a', '\x00', '\r', '\n', '\ud800', '\udfff']:
                with self.subTest(field=field, text=repr(text)):
                    value = doc([rule()], [query()])
                    target = value['rules' if field in ('name', 'requires') else 'queries'][0]
                    target[field] = [text] if field in ('requires', 'tags') else text
                    if text in ('a' * 64, 'é' * 32):
                        self.good(value, [(text if field == 'id' else 'q', None if field == 'requires' else text if field == 'name' else 'r')])
                    else:
                        self.bad(value)

    def test_invalid_structure_and_full_validation(self):
        cases = [None, [], {}, {'rules': []}, {'queries': []}, dict(doc(), extra=0)]
        for field in ('rules', 'queries'):
            for item in [None, {}, 'x', 1]:
                value = doc()
                value[field] = item
                cases.append(value)
            value = doc()
            value[field] = [None]
            cases.append(value)
        for collection, fields in [('rules', ['name', 'priority', 'requires']), ('queries', ['id', 'tags'])]:
            for field in fields + ['extra']:
                value = doc([rule()], [query()])
                target = value[collection][0]
                if field == 'extra':
                    target[field] = 0
                else:
                    del target[field]
                cases.append(value)
        for priority in [True, False, 1.0, '1', None, -1000000001, 1000000001]:
            cases.append(doc([rule(priority=priority)]))
        cases += [doc([rule(), rule()]), doc([], [query(), query()]),
                  doc([rule('winner', 10), rule('loser', -10, [None])], [query()]),
                  doc([rule()], [query(), query('later', [1])]),
                  doc([rule(name=1)]), doc([], [query(identifier=False)]),
                  doc([rule(requires='x')]), doc([], [query(tags={})])]
        for index, value in enumerate(cases):
            with self.subTest(index=index):
                self.bad(value)

    def test_wire_errors(self):
        for raw in [b'', b'{}{}', b'[]', b'{', b'\xef\xbb\xbf{}', b'\xff',
                    b'{"rules":[],"queries":[]}\x00',
                    b'{"rules":[],"rules":[],"queries":[]}',
                    b'{"rules":[],"rul\\u0065s":[],"queries":[]}',
                    b'{"rules":[{"name":"r","name":"s","priority":0,"requires":[]}],"queries":[]}',
                    b'{"rules":[],"queries":[{"id":"q","tags":[],"tags":[]}]}',
                    b'{"rules":[],"queries":[],}',
                    b'{"rules":[],"queries":[]} trailing']:
            with self.subTest(raw=raw):
                self.bad(raw)
        for token in [b'NaN', b'Infinity', b'-Infinity', b'1e0', b'1.0', b'01', b'9' * 5000]:
            self.bad(b'{"rules":[{"name":"r","priority":' + token + b',"requires":[]}],"queries":[]}')

    def test_arguments_rejected_without_reading(self):
        for arg in ['--help', 'unexpected']:
            process = subprocess.Popen(CMD + [arg], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                self.assertEqual(process.wait(timeout=3), 2)
                out, err = process.communicate(timeout=3)
                self.assertEqual((out, err), (b'', b'{"error":"invalid_input"}\n'))
            finally:
                if process.poll() is None:
                    process.kill()
                process.communicate()


if __name__ == '__main__':
    unittest.main()
