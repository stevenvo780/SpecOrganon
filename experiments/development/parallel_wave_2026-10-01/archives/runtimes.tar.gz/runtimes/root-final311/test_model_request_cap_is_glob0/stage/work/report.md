sealed shared work
