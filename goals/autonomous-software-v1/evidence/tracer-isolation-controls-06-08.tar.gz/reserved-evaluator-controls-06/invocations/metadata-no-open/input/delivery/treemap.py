import os
assert os.lstat('/fixture/root/probe.txt').st_size == 3
import sys
sys.stdout.write('{"files":[{"bytes":3,"path":"probe.txt"}],"symlinks":["link"],"total_bytes":3}\n')
