# PolicyPick

PolicyPick selecciona reglas con Python 3.12 y sólo la biblioteca estándar. Instale copiando `policypick.py` a `/input/delivery/policypick.py`, con permiso de lectura, y disponga de Python 3.12 en `/opt/specorganon/venv/bin/python`. No requiere paquetes ni acceso a red.

La invocación es `/opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py`, sin argumentos. Cualquier argumento, incluido `--help`, produce error antes de leer stdin.

## Ejemplos públicos

Ejemplo 1, comando completo:

```sh
printf '%s' '{"rules":[{"name":"default","priority":0,"requires":[]},{"name":"staff","priority":2,"requires":["internal"]}],"queries":[{"id":"q1","tags":["internal","internal"]},{"id":"q2","tags":[]}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py
```

stdout, seguido por un LF:

```json
{"decisions":[{"id":"q1","rule":"staff"},{"id":"q2","rule":"default"}]}
```

Ejemplo 2, comando completo:

```sh
printf '%s' '{"rules":[{"name":"z","priority":3,"requires":["x"]},{"name":"A","priority":3,"requires":["x"]}],"queries":[{"id":"yes","tags":["x"]},{"id":"no","tags":[]}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py
```

stdout, seguido por un LF:

```json
{"decisions":[{"id":"yes","rule":"A"},{"id":"no","rule":null}]}
```

## Formato, semántica y límites

stdin contiene un único objeto JSON UTF-8 de hasta 65536 bytes: `{"rules":[...],"queries":[...]}`. Cada regla tiene exactamente `name`, `priority`, `requires`; cada consulta tiene exactamente `id`, `tags`. Todas las listas admiten hasta 1000 elementos. Las listas vacías son válidas.

Los strings son no vacíos, de hasta 64 bytes UTF-8 después de resolver escapes, sin NUL, CR, LF ni surrogates no codificables. Espacios, tabulaciones, mayúsculas y Unicode se conservan literalmente, sin normalización. Los nombres de reglas son únicos y los IDs de consultas son únicos, en espacios de nombres independientes. `priority` debe ser un entero JSON entre -1000000000 y 1000000000; bool, float y string no son válidos.

`requires` y `tags` se comparan como conjuntos: sus duplicados son válidos. Una regla coincide si todos sus requisitos aparecen entre los tags; requisitos vacíos coinciden siempre. Gana la prioridad más alta y, en empate, el nombre mínimo por puntos de código Unicode. El orden de reglas no influye. Tags desconocidos son válidos. Sin coincidencia se devuelve `null`; sin reglas todas las decisiones tienen `rule:null`; sin consultas se devuelve `{"decisions":[]}`.

Se permite whitespace JSON, incluidos LF, CR y tabulaciones, alrededor y dentro del objeto. Se rechazan BOM, NUL crudo, claves repetidas, claves adicionales u omitidas, NaN/Infinity, JSON mal formado y documentos concatenados. Se valida todo el documento antes de seleccionar reglas: una regla inválida invalida la entrada aunque no pudiera ganar.

Éxito: exit 0, stderr vacío y un objeto compacto en stdout seguido por exactamente un LF, sin whitespace externo. Cada consulta produce una decisión en su orden original. Error: exit 2, stdout vacío y stderr exactamente `{"error":"invalid_input"}` seguido por un LF.

El entorno especificado limita la ejecución a 3 segundos, 2 CPU, 1 GiB, 128 procesos y 2 MiB por stream, con red deshabilitada y entrega de sólo lectura. No se suministraron mediciones de ejecución. Esta implementación expresa la semántica local del contrato; no establece eficacia de control de acceso real ni cumplimiento legal. Valores, tokens y dinero son desconocidos.

## Comando de comprobación

Este comando ejecutable verifica los dos ejemplos públicos con comparación exacta de stdout, stderr y código de salida, además de una entrada inválida y el rechazo de argumentos. No se ha ejecutado aquí; su alcance es una comprobación básica, sin afirmar cobertura universal. No requiere crear archivos de tests.

```sh
/opt/specorganon/venv/bin/python -E -s -B - <<'PY'
import subprocess

command = ['/opt/specorganon/venv/bin/python', '-E', '-s', '-B', '/input/delivery/policypick.py']
cases = [
    (b'{"rules":[{"name":"default","priority":0,"requires":[]},{"name":"staff","priority":2,"requires":["internal"]}],"queries":[{"id":"q1","tags":["internal","internal"]},{"id":"q2","tags":[]}]}', b'{"decisions":[{"id":"q1","rule":"staff"},{"id":"q2","rule":"default"}]}\n'),
    (b'{"rules":[{"name":"z","priority":3,"requires":["x"]},{"name":"A","priority":3,"requires":["x"]}],"queries":[{"id":"yes","tags":["x"]},{"id":"no","tags":[]}]}', b'{"decisions":[{"id":"yes","rule":"A"},{"id":"no","rule":null}]}\n'),
]
for data, expected in cases:
    result = subprocess.run(command, input=data, capture_output=True, timeout=3)
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b'')
for args, data in [([], b'{}'), (['--help'], b'')]:
    result = subprocess.run(command + args, input=data, capture_output=True, timeout=3)
    assert (result.returncode, result.stdout, result.stderr) == (2, b'', b'{"error":"invalid_input"}\n')
print('Comprobaciones básicas completadas')
PY
```
