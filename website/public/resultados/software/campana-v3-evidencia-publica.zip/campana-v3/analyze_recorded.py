from pathlib import Path
import hashlib,json,ast,importlib.util
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SOURCE-MANIFEST.json').read_text())['files_sha256']
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for name,sha in manifest.items())
definition=root/'frozen-source/experiments/software_comparison_v3/analysis.py'
spec=importlib.util.spec_from_file_location('frozen_analysis',definition);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
tree=ast.parse((root/'frozen-source/experiments/software_comparison_v3/evaluation.py').read_text());function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='comparison_groups')
def require(condition,message):
 if not condition:raise ValueError(message)
namespace={'require':require,'descriptive_differences':module.descriptive_differences}
exec(compile(ast.Module(body=[function],type_ignores=[]),'frozen-comparison-groups','exec'),namespace)
comparison_groups=namespace['comparison_groups']
report=json.loads((root/'closure/report-posthoc-v1.json').read_text());rows=report['cells']
assert len(rows)==42 and comparison_groups(rows,nst_blocks=12,a_blocks=6)==report['comparisons']
for dimension,nst_count,a_count in [('task',4,2),('family',6,3)]:
 for identity,expected in report['strata'][dimension].items():
  assert comparison_groups([r for r in rows if r[dimension]==identity],nst_blocks=nst_count,a_blocks=a_count)==expected
definition=root/'frozen-source/experiments/software_comparison_v3/reserved.py'
spec=importlib.util.spec_from_file_location('frozen_reserved',definition);reserved=importlib.util.module_from_spec(spec);spec.loader.exec_module(reserved)
progress=json.loads((root/'original/evaluation-progress.json').read_text())
assert progress['complete'] and sum(len(v['rows']) for v in progress['cells'].values())==3500
for row in rows:
 assert module.functional_summary(reserved.recipes(row['task']),list(progress['cells'][row['opaque_id']]['rows'].values()),evaluated=True)==row['functional']
# Resolve every originally asserted pass with the exact frozen parser/resolver.
import math,re
from decimal import Decimal,InvalidOperation
namespace={'json':json,'math':math,'re':re,'Decimal':Decimal,'InvalidOperation':InvalidOperation,'Any':object}
tree=ast.parse((root/'frozen-source/src/specorganon/ledger.py').read_text())
names={'_reject_nonfinite','_finite_float','_object_without_duplicate_keys','strict_json_loads'}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'frozen-parser','exec'),namespace)
tree=ast.parse((root/'frozen-source/experiments/software_comparison_v3/audit_evidence.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'resolve','EvidenceError'}],type_ignores=[]),'frozen-resolver','exec'),namespace)
tree=ast.parse((root/'frozen-source/experiments/software_comparison_v3/evaluation.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='score_points'],type_ignores=[]),'frozen-points','exec'),namespace)
invalid=[]
for row in rows:
 qualitative=row['qualitative'];audit=qualitative['native_assertions']
 if audit:
  cell=root/'original/cells'/row['id'];packet=json.loads((cell/'final-packet.json').read_text());request=json.loads((cell/'final-request.json').read_text())
  assert packet['result']['audit']==audit
  for group in ['D','G','H']:
   for point,assertion in audit[group].items():
    errors=[]
    if assertion['status']=='pass':
     for locator in assertion['evidence']:
      try:namespace['resolve'](locator,request['documents'])
      except namespace['EvidenceError'] as exc:errors.append({'locator':locator,'exception_type':type(exc).__name__,'reason':str(exc)})
    status='fail' if errors else assertion['status']
    assert qualitative['point_verification'][group+'/'+point]=={'auditor_status':assertion['status'],'verified_status':status,'errors':errors}
    assert qualitative['points'][group][point]['status']==status
    if errors:invalid.append({'id':row['id'],'dimension':group,'point':point,'auditor_status':assertion['status'],'verified_status':'fail','score':0,'errors':errors})
 for group,points in qualitative['points'].items():assert namespace['score_points'](points)==qualitative['scores'][group]
 assert row['full_package']==(row['functional']['contract_complete'] and all(v['fail']==v['inconclusive']==0 for v in qualitative['scores'].values()))
assert invalid==report['aggregation']['invalid_points']
print(json.dumps({'recorded_analysis_matches':True,'cells':42,'new_subjects':0,'new_model_calls':0}))
