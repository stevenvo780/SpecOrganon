import unittest
import subprocess
import os
import shutil
import json

class TestTreeMap(unittest.TestCase):
    def setUp(self):
        self.scratch = "/tmp/treemap_scratch"
        if os.path.exists(self.scratch):
            shutil.rmtree(self.scratch)
        os.makedirs(self.scratch)
        self.target = "/input/delivery/treemap.py"
        self.python = "/opt/specorganon/venv/bin/python"

    def tearDown(self):
        if os.path.exists(self.scratch):
            shutil.rmtree(self.scratch)

    def run_cli(self, *args):
        return subprocess.run([self.python, self.target, *args], capture_output=True, text=True)

    def test_public_examples(self):
        tree = os.path.join(self.scratch, "tree")
        sub = os.path.join(tree, "sub")
        os.makedirs(sub)
        
        with open(os.path.join(tree, "a.txt"), "w") as f: f.write("hi")
        with open(os.path.join(tree, "z.bin"), "w") as f: f.write("z")
        with open(os.path.join(sub, "b.txt"), "w") as f: f.write("123")
        os.symlink("sub", os.path.join(tree, "shortcut"))

        res1 = self.run_cli("--root", tree, "--max-depth", "2", "--suffix", ".txt")
        self.assertEqual(res1.returncode, 0)
        out1 = json.loads(res1.stdout)
        self.assertEqual(out1["total_bytes"], 5)
        self.assertEqual(len(out1["files"]), 2)
        self.assertEqual(out1["files"][0]["path"], "a.txt")
        self.assertEqual(out1["files"][1]["path"], "sub/b.txt")
        self.assertEqual(out1["symlinks"], ["shortcut"])
        
        res2 = self.run_cli("--root", tree, "--max-depth", "1", "--suffix", ".txt")
        self.assertEqual(res2.returncode, 0)
        out2 = json.loads(res2.stdout)
        self.assertEqual(out2["total_bytes"], 2)
        self.assertEqual(len(out2["files"]), 1)
        self.assertEqual(out2["files"][0]["path"], "a.txt")
        self.assertEqual(out2["symlinks"], ["shortcut"])

    def test_empty_root(self):
        empty = os.path.join(self.scratch, "empty")
        os.makedirs(empty)
        res = self.run_cli("--root", empty)
        self.assertEqual(res.returncode, 0)
        out = json.loads(res.stdout)
        self.assertEqual(out["total_bytes"], 0)
        self.assertEqual(out["files"], [])
        self.assertEqual(out["symlinks"], [])

    def test_invalid_args(self):
        tests = [
            [], 
            ["--root", self.scratch, "--unknown", "val"], 
            ["--root", self.scratch, "--root", self.scratch], 
            ["--root", self.scratch, "--max-depth"], 
            ["--root", self.scratch, "positional"], 
            ["--root=" + self.scratch]
        ]
        for args in tests:
            with self.subTest(args=args):
                res = self.run_cli(*args)
                self.assertEqual(res.returncode, 2)
                self.assertEqual(res.stdout, "")
                self.assertEqual(json.loads(res.stderr), {"error": "invalid_input"})

    def test_invalid_root(self):
        file_root = os.path.join(self.scratch, "file")
        with open(file_root, "w") as f: f.write("x")
        
        sym_root = os.path.join(self.scratch, "sym")
        os.symlink(file_root, sym_root)

        tests = [
            file_root,
            sym_root,
            self.scratch + "/../" + os.path.basename(self.scratch)
        ]
        for r in tests:
            with self.subTest(r=r):
                res = self.run_cli("--root", r)
                self.assertEqual(res.returncode, 2)
                self.assertEqual(res.stdout, "")
                self.assertEqual(json.loads(res.stderr), {"error": "invalid_input"})

    def test_invalid_depth(self):
        tree = os.path.join(self.scratch, "tree_depth")
        os.makedirs(tree)
        tests = ["0", "9", "10", "A", "-1", ""]
        for d in tests:
            with self.subTest(d=d):
                res = self.run_cli("--root", tree, "--max-depth", d)
                self.assertEqual(res.returncode, 2)

    def test_invalid_suffix(self):
        tree = os.path.join(self.scratch, "tree_suffix")
        os.makedirs(tree)
        tests = ["txt", ".toolongextension1", ".", ".txt.txt", ".a_b", ".A"*13]
        for ext in tests:
            with self.subTest(ext=ext):
                res = self.run_cli("--root", tree, "--suffix", ext)
                self.assertEqual(res.returncode, 2)

    def test_visit_limit(self):
        tree = os.path.join(self.scratch, "tree_limit")
        os.makedirs(tree)
        for i in range(257):
            with open(os.path.join(tree, f"f{i}"), "w") as f:
                f.write("")
        res = self.run_cli("--root", tree)
        self.assertEqual(res.returncode, 2)
        self.assertEqual(json.loads(res.stderr), {"error": "invalid_input"})

    def test_path_length_limit(self):
        tree = os.path.join(self.scratch, "tree_deep")
        os.makedirs(tree)
        curr = tree
        for i in range(3):
            name = "a" * 200
            curr = os.path.join(curr, name)
            os.makedirs(curr)
        with open(os.path.join(curr, "b.txt"), "w") as f:
            f.write("test")
        res = self.run_cli("--root", tree, "--max-depth", "4")
        self.assertEqual(res.returncode, 2)
        self.assertEqual(json.loads(res.stderr), {"error": "invalid_input"})

    def test_ignore_special_files(self):
        tree = os.path.join(self.scratch, "tree_special")
        os.makedirs(tree)
        try:
            os.mkfifo(os.path.join(tree, "myfifo"))
        except Exception:
            pass
        with open(os.path.join(tree, "a.txt"), "w") as f:
            f.write("ok")
        res = self.run_cli("--root", tree)
        self.assertEqual(res.returncode, 0)
        out = json.loads(res.stdout)
        self.assertEqual(len(out["files"]), 1)
        self.assertEqual(out["files"][0]["path"], "a.txt")

if __name__ == '__main__':
    unittest.main()
