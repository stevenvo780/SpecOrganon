print('{"files":[],"total_bytes":0,"symlinks":[]}')
