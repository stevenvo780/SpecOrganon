import os
from pathlib import Path
assert os.getresuid() == (65534,65534,65534)
assert os.getresgid() == (65534,65534,65534)
assert int(Path('/proc/self/status').read_text().split('CapEff:')[1].splitlines()[0],16) == 0
for operation in [lambda: Path('/collector-output/trace.bin').write_bytes(b'forged'),
                  lambda: os.unlink('/collector-output/trace.bin'),
                  lambda: os.chmod('/collector-output',0o777),
                  lambda: Path('/collector-input/collector.py').read_text(),
                  lambda: os.open('/proc/1/fd/1',os.O_WRONLY),
                  lambda: os.kill(os.getppid(),9)]:
    try: operation()
    except PermissionError: pass
    else: raise AssertionError('collector boundary accessible to subject')
for fd in os.listdir('/proc/self/fd'):
    if int(fd) > 2:
        try: destination = os.readlink('/proc/self/fd/'+fd)
        except FileNotFoundError: continue
        raise AssertionError('unexpected inherited descriptor '+destination)
import sys
sys.stdout.write('{"files":[{"bytes":3,"path":"probe.txt"}],"symlinks":["link"],"total_bytes":3}\n')
