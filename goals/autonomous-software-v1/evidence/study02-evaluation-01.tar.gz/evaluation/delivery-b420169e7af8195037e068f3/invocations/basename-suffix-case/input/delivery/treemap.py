import sys
import os
import json
import re
import stat

def fail():
    try:
        sys.stderr.write(json.dumps({"error": "invalid_input"}) + "\n")
        sys.stderr.flush()
    except:
        pass
    sys.exit(2)

def main():
    try:
        args = sys.argv[1:]
        opts = {}
        idx = 0
        while idx < len(args):
            token = args[idx]
            if token in ("--root", "--max-depth", "--suffix"):
                if token in opts:
                    fail()
                if idx + 1 >= len(args):
                    fail()
                opts[token] = args[idx+1]
                idx += 2
            else:
                fail()

        if "--root" not in opts:
            fail()
        
        root = opts["--root"]
        if not root or ".." in root.split("/"):
            fail()
            
        depth = 4
        if "--max-depth" in opts:
            d_val = opts["--max-depth"]
            if len(d_val) != 1 or d_val not in "12345678":
                fail()
            depth = int(d_val)
            
        ext = None
        if "--suffix" in opts:
            ext = opts["--suffix"]
            if not re.fullmatch(r'\.[A-Za-z0-9]{1,12}', ext):
                fail()

        parts = [p for p in root.split("/") if p and p != "."]
        is_absolute = root.startswith("/")
        norm_root = "/" + "/".join(parts) if is_absolute else "/".join(parts)
        if not norm_root and is_absolute:
            norm_root = "/"
        elif not norm_root:
            norm_root = "."

        try:
            st = os.lstat(norm_root)
        except OSError:
            fail()
            
        if stat.S_ISLNK(st.st_mode) or not stat.S_ISDIR(st.st_mode):
            fail()

        files = []
        symlinks = []
        total_bytes = 0
        visited_count = [0]

        def traverse(curr_path, current_depth, current_rel):
            try:
                with os.scandir(curr_path) as it:
                    entries = list(it)
            except OSError:
                fail()
                
            for entry in entries:
                visited_count[0] += 1
                if visited_count[0] > 256:
                    fail()

                name = entry.name
                try:
                    name.encode('utf-8', errors='strict')
                except UnicodeError:
                    fail()

                rel_path = f"{current_rel}/{name}" if current_rel else name
                if len(rel_path.encode('utf-8')) > 512:
                    fail()

                try:
                    is_sym = entry.is_symlink()
                    is_dir = entry.is_dir(follow_symlinks=False)
                    is_file = entry.is_file(follow_symlinks=False)
                except OSError:
                    fail()

                if is_sym:
                    symlinks.append(rel_path)
                elif is_dir:
                    if current_depth < depth:
                        traverse(entry.path, current_depth + 1, rel_path)
                elif is_file:
                    if ext is None or name.endswith(ext):
                        try:
                            size = entry.stat(follow_symlinks=False).st_size
                        except OSError:
                            fail()
                        files.append({"path": rel_path, "bytes": size})
                        total_bytes += size

        traverse(norm_root, 1, "")

        files.sort(key=lambda x: x["path"])
        symlinks.sort()
        
        out = {
            "files": files,
            "total_bytes": total_bytes,
            "symlinks": symlinks
        }
        
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stdout.write(json.dumps(out, separators=(',', ':'), ensure_ascii=False) + "\n")
        sys.stdout.flush()
        sys.exit(0)

    except Exception:
        fail()

if __name__ == "__main__":
    main()
