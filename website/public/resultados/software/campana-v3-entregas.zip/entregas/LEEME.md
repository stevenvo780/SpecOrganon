# Las 42 entregas originales

Todos los archivos sellados conservan sus bytes, incluso entregas parciales o
ausentes. Cada metadata.json conserva el estado de generación, F y full_package.
No se selecciona la mejor repetición. cell-01 y cell-06 son las dos entregas T9
FractionMix completas: F84/84, D8/8, G6/6, H9/9. Las otras conservan su resultado.
Los ledgers y revisiones están en el ZIP de evidencia separado.

Uso de FractionMix: CPython3.12 y biblioteca estándar, desde cell-01:
python3 -E -s -B fractionmix.py < entrada.json
Su README original explica contrato, errores, recursos y ejemplos. La campaña
ejecutó estos mismos archivos en Docker con CPython3.12.3. El ZIP del toolkit
permite construir ese entorno; no se promete corrección para otras versiones.

La comparación completa está en campana-v3-informe.json. Se reparó sólo la
agregación tras exit1 primario, sin repetir casos ni modificar sus fuentes.
El hito local no demuestra superioridad general ni eficacia alimentaria de campo.
