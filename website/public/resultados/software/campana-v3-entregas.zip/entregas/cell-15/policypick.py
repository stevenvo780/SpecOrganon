"""PolicyPick: strict JSON input and deterministic policy selection."""

import json
import sys


MAX_BYTES = 65536
MAX_ITEMS = 1000
MAX_STRING_BYTES = 64
MAX_PRIORITY = 1000000000
ERROR = b'{"error":"invalid_input"}\n'


class InvalidInput(ValueError):
    pass


def reject_number(token):
    raise InvalidInput()


def parse_integer(token):
    # Bound conversion work independently of Python's integer digit limit.
    digits = token[1:] if token.startswith('-') else token
    if len(digits) > 10:
        raise InvalidInput()
    value = int(token)
    if not -MAX_PRIORITY <= value <= MAX_PRIORITY:
        raise InvalidInput()
    return value


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidInput()
        result[key] = value
    return result


def exact_object(value, keys):
    if type(value) is not dict or value.keys() != keys:
        raise InvalidInput()


def bounded_list(value):
    if type(value) is not list or len(value) > MAX_ITEMS:
        raise InvalidInput()
    return value


def valid_string(value):
    if type(value) is not str or not value:
        raise InvalidInput()
    if any(character in value for character in ('\x00', '\r', '\n')):
        raise InvalidInput()
    if len(value.encode('utf-8', errors='strict')) > MAX_STRING_BYTES:
        raise InvalidInput()
    return value


def string_set(value):
    return {valid_string(item) for item in bounded_list(value)}


def validate_document(document):
    exact_object(document, {'rules', 'queries'})
    raw_rules = bounded_list(document['rules'])
    raw_queries = bounded_list(document['queries'])
    rules = []
    queries = []
    names = set()
    identifiers = set()

    for rule in raw_rules:
        exact_object(rule, {'name', 'priority', 'requires'})
        name = valid_string(rule['name'])
        priority = rule['priority']
        if type(priority) is not int or not -MAX_PRIORITY <= priority <= MAX_PRIORITY:
            raise InvalidInput()
        required = string_set(rule['requires'])
        if name in names:
            raise InvalidInput()
        names.add(name)
        rules.append((name, priority, required))

    for query in raw_queries:
        exact_object(query, {'id', 'tags'})
        identifier = valid_string(query['id'])
        tags = string_set(query['tags'])
        if identifier in identifiers:
            raise InvalidInput()
        identifiers.add(identifier)
        queries.append((identifier, tags))

    return rules, queries


def decide(rules, queries):
    ordered_rules = sorted(rules, key=lambda rule: (-rule[1], rule[0]))
    decisions = []
    for identifier, tags in queries:
        winner = None
        for name, priority, required in ordered_rules:
            if required.issubset(tags):
                winner = name
                break
        decisions.append({'id': identifier, 'rule': winner})
    return {'decisions': decisions}


def main():
    if len(sys.argv) != 1:
        sys.stderr.buffer.write(ERROR)
        return 2

    try:
        raw = sys.stdin.buffer.read()
        if len(raw) > MAX_BYTES or raw.startswith(b'\xef\xbb\xbf') or b'\x00' in raw:
            raise InvalidInput()
        text = raw.decode('utf-8', errors='strict')
        document = json.loads(
            text,
            object_pairs_hook=unique_object,
            parse_int=parse_integer,
            parse_float=reject_number,
            parse_constant=reject_number,
            strict=True,
        )
        rules, queries = validate_document(document)
        result = decide(rules, queries)
        output = json.dumps(
            result, ensure_ascii=False, separators=(',', ':'), allow_nan=False
        ).encode('utf-8') + b'\n'
    except (ValueError, TypeError, RecursionError, OSError):
        sys.stderr.buffer.write(ERROR)
        return 2

    sys.stdout.buffer.write(output)
    return 0


if __name__ == '__main__':
    sys.exit(main())
