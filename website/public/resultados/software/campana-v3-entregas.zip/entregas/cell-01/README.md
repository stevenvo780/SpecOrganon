# FractionMix

Utilidad propuesta para sumar racionales exactamente mediante Python 3.12 y su biblioteca estándar. No necesita paquetes externos. Colocar fractionmix.py en /input/delivery; no requiere permiso de ejecución porque se invoca mediante el intérprete.

## Interfaz

Invocación completa:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Lee exclusivamente stdin. Cualquier argumento, incluido --help, produce el error contractual antes de leer stdin. El programa no consulta archivos auxiliares, red, credenciales ni variables de entorno. Los indicadores -E, -s y -B pertenecen al intérprete.

## Ejemplos públicos

Comandos y resultados especificados por el contrato; no son registros de ejecución de esta entrega.

```sh
printf '%s\n' '{"terms":[{"numerator":1,"denominator":2},{"numerator":1,"denominator":3}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Salida esperada, seguida de un LF:

```json
{"numerator":5,"denominator":6,"term_count":2}
```

```sh
printf '%s\n' '{"terms":[{"numerator":2,"denominator":4},{"numerator":-1,"denominator":2}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Salida esperada, seguida de un LF:

```json
{"numerator":0,"denominator":1,"term_count":2}
```

El éxito contractual exige exit 0 y stderr vacío. stdout contiene únicamente un objeto JSON, empieza con { y termina con } seguido de un LF. Las claves son numerator, denominator y term_count, todas con valores enteros.

## Validación y errores

Máximo 65536 bytes de entrada, incluido whitespace final. Se lee como máximo un byte adicional para detectar exceso. UTF-8 estricto, sin BOM inicial ni byte NUL. Se admite whitespace JSON exterior, pero se exige un único valor JSON; vacío, claves duplicadas tras decodificar escapes y NaN/Infinity/-Infinity son inválidos.

El objeto superior contiene exactamente terms: una lista de 0 a 1000 objetos. Cada objeto contiene exactamente numerator y denominator. Numerator es entero JSON entre -1000000000 y 1000000000; denominator entre 1 y 1000000000. Booleanos, floats, strings, propiedades adicionales y denominadores cero o negativos son inválidos. Se validan todos los términos antes del cálculo, incluidos ceros y términos que se cancelarían.

Todo error contractual produce exit 2, stdout vacío y stderr exactamente estos bytes UTF-8, incluido el LF final:

```text
{"error":"invalid_input"}
```

Timeout, OOM y otros fallos de ejecución deben conservarse como tales por el ejecutor. El programa no captura indiscriminadamente esos fallos para convertirlos en invalid_input.

## Aritmética y recursos

La suma usa enteros, denominadores comunes calculados mediante MCD y reducción en cada paso; no usa redondeo de punto flotante. El denominador permanece positivo y cero se reduce a 0/1. La lista vacía produce 0/1 con term_count=0. Se cuentan todos los términos, incluidos ceros, duplicados y cancelaciones, sin deduplicar.

Los resultados pueden superar los límites de los enteros de entrada y los 4300 dígitos decimales. Se desactiva explícitamente el límite de conversión decimal de CPython para conservar ese dominio. Los límites derivados del contrato son hasta 9001 dígitos para el denominador y 9013 para el numerador; no se introducen restricciones adicionales sobre resultados válidos.

Cada invocación está sujeta a 3 segundos, 2 CPU, 1 GiB, 128 procesos y streams de hasta 2 MiB, con entrega readonly y sin red. El aislamiento y esos límites corresponden al ejecutor externo; este programa no los configura ni modifica archivos de entrega. No hay mediciones suministradas de consumo o duración.

## Pruebas y alcance

Esta etapa program entrega únicamente implementación y documentación. No incluye archivos de pruebas ni registros de ejecución. La etapa tests deberá aportar test_fractionmix.py con casos propios reproducibles de éxito, error y bordes, vinculados al criterio y a la versión de implementación.

Comando propuesto para esa futura entrega de pruebas, pendiente de que exista el archivo:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/test_fractionmix.py
```

Deberá contrastar ambos ejemplos, lista vacía, reducción, ceros, duplicados, cancelación, orden, límites de bytes/términos/enteros, argumentos, UTF-8, BOM, NUL, JSON duplicado o adicional, tipos inválidos, formato exacto y resultados mayores de 4300 dígitos. Cada proceso de FractionMix deberá usar la invocación completa indicada arriba. Los registros y límites de aislamiento los proporciona el ejecutor externo.

Las 84 recetas candidatas no están suministradas ni fijadas en esta evidencia; las pruebas propias no las sustituyen. No se afirma conformidad medida, cobertura universal, superioridad general ni utilidad en personas. El alcance es una utilidad técnica para entradas sintéticas finitas.
