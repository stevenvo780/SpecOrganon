import sys
assert len(sys.stdin.buffer.read()) == 65536
import sys
sys.stdout.write('{"cost":1,"path":["A","B"],"reachable":true}\n')
