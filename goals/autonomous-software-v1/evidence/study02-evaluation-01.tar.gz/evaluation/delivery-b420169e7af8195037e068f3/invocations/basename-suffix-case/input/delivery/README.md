# TreeMap CLI

TreeMap es una utilidad de línea de comandos en Python 3.12 que genera un inventario determinista de archivos en un directorio, reportando tamaños y symlinks encontrados, sin modificar el árbol ni seguir enlaces. Emplea exclusivamente la biblioteca estándar de Python.

## Instalación

No requiere instalación de dependencias externas. Asegúrate de ejecutarlo en un entorno con Python 3.12.

## Ejemplos Públicos y Reproducción

Puedes crear el árbol de ejemplo temporal para pruebas usando los siguientes comandos bash:

```bash
mkdir -p /tmp/tree/sub
printf "hi" > /tmp/tree/a.txt
printf "z" > /tmp/tree/z.bin
printf "123" > /tmp/tree/sub/b.txt
ln -s sub /tmp/tree/shortcut
```

**Ejemplo 1 (Profundidad 2 con filtro .txt):**
```bash
python treemap.py --root /tmp/tree --max-depth 2 --suffix .txt
```

*Salida esperada (stdout):*
```json
{"files":[{"path":"a.txt","bytes":2},{"path":"sub/b.txt","bytes":3}],"total_bytes":5,"symlinks":["shortcut"]}
```

**Ejemplo 2 (Profundidad 1 con el mismo filtro):**
```bash
python treemap.py --root /tmp/tree --max-depth 1 --suffix .txt
```

*Salida esperada (stdout):*
```json
{"files":[{"path":"a.txt","bytes":2}],"total_bytes":2,"symlinks":["shortcut"]}
```

## Formato de Salida

En caso de éxito, devuelve en `stdout` un solo objeto JSON (UTF-8, con trailing newline y status code 0) con:
- `files`: Lista de objetos que contienen `path` (relativo a root) y `bytes` (tamaño metadata en bytes).
- `total_bytes`: Suma total exacta de los archivos contados.
- `symlinks`: Lista de nombres relativos a symlinks encontrados.

## Límites y Errores

- **Máximo entradas visitadas**: 256. Exceder esto produce error.
- **Límites de ruta**: Rutas relativas máximas de 512 bytes UTF-8.
- **Directorios ignorados**: Hijos a profundidad igual a `max-depth`.
- En cualquier error de parseo de argumentos, lectura o superación de límites, se produce `exit 2` de inmediato, imprimiendo el JSON `{"error":"invalid_input"}` en `stderr` (sin tracebacks ni otros mensajes).

## Comando de Tests

Los tests propios deben invocarse directamente sobre una entrega de solo-lectura, usando las siguientes referencias formales:

```bash
/opt/specorganon/venv/bin/python -m unittest discover tests
```
