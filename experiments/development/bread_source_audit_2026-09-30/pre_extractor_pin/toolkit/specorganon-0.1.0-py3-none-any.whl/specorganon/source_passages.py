"""Extract uniquely located passages from the exact bytes of a pinned PDF.

Selectors are reviewed caller input. Matching a passage checks a transcription;
it does not authenticate the authors, establish causality, or interpret a base.
"""

from __future__ import annotations

import hashlib
import os
import re
import stat
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path


class SourceAuditError(ValueError):
    """A source or uniquely located passage does not satisfy its contract."""


@dataclass(frozen=True)
class SourceSpec:
    bytes: int
    sha256: str


@dataclass(frozen=True)
class PdfPages:
    pages: tuple[str, ...]
    source_sha256: str
    source_bytes: int
    text_sha256: str
    extractor_version: str


def normalize_whitespace(text: str) -> str:
    """Collapse whitespace only; preserve numbers, punctuation and dash types."""
    return re.sub(r"\s+", " ", text).strip()


def read_pdf_pages(path: Path, spec: SourceSpec) -> PdfPages:
    """Hash once, then extract a private snapshot of those same source bytes."""
    if (type(spec.bytes) is not int or not 0 < spec.bytes <= 20_000_000
            or not isinstance(spec.sha256, str)
            or re.fullmatch(r"[0-9a-f]{64}", spec.sha256) is None):
        raise SourceAuditError("invalid PDF source pin")
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size != spec.bytes:
                raise SourceAuditError("PDF source size/type differs from pin")
            raw = stream.read(spec.bytes + 1)
    except OSError as exc:
        raise SourceAuditError(f"cannot read pinned PDF: {path.name}") from exc
    if len(raw) != spec.bytes or hashlib.sha256(raw).hexdigest() != spec.sha256:
        raise SourceAuditError("PDF source bytes differ from pin")
    try:
        with tempfile.TemporaryDirectory(prefix="organon-source-passage-") as folder:
            snapshot = Path(folder) / "source.pdf"
            snapshot.write_bytes(raw)
            extracted = subprocess.run(
                ["pdftotext", "-layout", "-enc", "UTF-8", str(snapshot), "-"],
                capture_output=True, timeout=20, check=True,
            )
        version = subprocess.run(
            ["pdftotext", "-v"], capture_output=True, timeout=5, check=True,
        )
        version_text = (version.stdout + version.stderr).decode("utf-8").splitlines()[0]
        text = extracted.stdout.decode("utf-8")
    except (OSError, subprocess.SubprocessError, UnicodeError, IndexError) as exc:
        raise SourceAuditError("Poppler pdftotext extraction failed") from exc
    if not text or len(extracted.stdout) > 2_000_000:
        raise SourceAuditError("PDF extraction empty or too large")
    pages = text.split("\f")
    if pages and not pages[-1].strip():
        pages.pop()
    if not pages or any(not page.strip() for page in pages):
        raise SourceAuditError("PDF extraction contains an empty page")
    return PdfPages(
        tuple(pages), spec.sha256, len(raw),
        hashlib.sha256(extracted.stdout).hexdigest(), version_text,
    )


def extract_passage(
    pdf: PdfPages, page: int, start: str, end: str, pattern: str,
    required: tuple[str, ...] = (),
) -> dict:
    """Require one page, one pair of anchors, and exactly one regex match.

    Passage/match digests use whitespace-normalized UTF-8; the page digest
    uses raw extracted UTF-8. Neither is a digest of the original PDF bytes.
    """
    if type(page) is not int or not 1 <= page <= len(pdf.pages):
        raise SourceAuditError("PDF page outside extracted source")
    raw = pdf.pages[page - 1]
    text = normalize_whitespace(raw)
    begin, finish = normalize_whitespace(start), normalize_whitespace(end)
    if not begin or not finish or text.count(begin) != 1:
        raise SourceAuditError("start locator missing or ambiguous")
    if text.count(finish) != 1:
        raise SourceAuditError("end locator missing or ambiguous")
    tail = text.split(begin, 1)[1]
    if tail.count(finish) != 1:
        raise SourceAuditError("end locator missing or ambiguous")
    passage = begin + " " + tail.split(finish, 1)[0].strip()
    for context in required:
        if normalize_whitespace(context) not in passage:
            raise SourceAuditError("required unit/base/provenance context missing")
    try:
        matches = list(re.finditer(pattern, passage))
    except re.error as exc:
        raise SourceAuditError("invalid reviewed passage pattern") from exc
    if len(matches) != 1 or not matches[0].groupdict():
        raise SourceAuditError("numeric locator missing, ambiguous or unnamed")
    if any(value is None for value in matches[0].groupdict().values()):
        raise SourceAuditError("numeric locator has unmatched groups")
    match = matches[0].group(0)
    return {
        "source_sha256": pdf.source_sha256,
        "page": page,
        "page_sha256": hashlib.sha256(raw.encode()).hexdigest(),
        "passage_sha256": hashlib.sha256(passage.encode()).hexdigest(),
        "matched_sha256": hashlib.sha256(match.encode()).hexdigest(),
        "normalization": "whitespace_only",
        "groups": matches[0].groupdict(),
        "matched_text": match,
    }
