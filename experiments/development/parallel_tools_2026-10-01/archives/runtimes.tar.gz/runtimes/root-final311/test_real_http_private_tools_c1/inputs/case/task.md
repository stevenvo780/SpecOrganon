Public synthetic facts for D-E-synthetic. No observed outcomes or normative approval.
