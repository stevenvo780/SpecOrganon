Public synthetic report of actual branch c-task-1.
