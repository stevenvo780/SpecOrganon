# ListPatch

Transformación local de listas para Python 3.12, sólo con la biblioteca estándar. No requiere paquetes externos.

## Instalación e interfaz

Desde el directorio que contiene el archivo entregado:

```sh
mkdir -p /input/delivery
cp listpatch.py /input/delivery/listpatch.py
```

Invocación pública, sin argumentos:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/listpatch.py
```

Lee stdin como JSON UTF-8 estricto. Cualquier argumento, incluido `--help`, falla antes de leer stdin. La salida exitosa tiene código 0, stderr vacío y un único objeto JSON seguido de LF, sin whitespace externo: `{"items":[...],"applied":n}`. `applied` es un entero igual al número de operaciones.

## Ejemplos públicos

```sh
printf '%s' '{"items":[10,20],"operations":[{"op":"insert","index":1,"value":15},{"op":"replace","index":0,"value":9},{"op":"delete","index":2}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/listpatch.py
```

Salida esperada, con LF final:

```json
{"items":[9,15],"applied":3}
```

```sh
printf '%s' '{"items":[],"operations":[{"op":"insert","index":0,"value":-2},{"op":"delete","index":0}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/listpatch.py
```

Salida esperada, con LF final:

```json
{"items":[],"applied":2}
```

## Formatos, errores y límites

La entrada admite como máximo 65536 bytes, incluyendo whitespace, y debe ser un único objeto con exactamente las claves `items` y `operations`. Ambas contienen listas de hasta 1000 elementos. Se permite whitespace JSON interno y externo; se rechazan objetos concatenados, BOM, NUL crudo, UTF-8 inválido, claves repetidas en cualquier objeto y constantes NaN/Infinity.

Los elementos de `items` y cada `value` deben ser enteros JSON entre -1000000000 y 1000000000 inclusive. Cada `index` debe ser un entero JSON entre 0 y 1000 inclusive. Booleanos, números decimales o con exponente y cadenas no cumplen estos tipos.

Las operaciones tienen exactamente estos formatos:

- `{"op":"insert","index":i,"value":v}`: inserta antes de `i`; permite `0 <= i <= longitud_actual`, incluido agregar al final. La longitud nunca puede superar 1000, ni temporalmente.
- `{"op":"replace","index":i,"value":v}`: sustituye una posición existente; exige `0 <= i < longitud_actual`.
- `{"op":"delete","index":i}`: elimina una posición existente; exige `0 <= i < longitud_actual`. No admite `value` ni otras claves.

Los nombres distinguen mayúsculas y minúsculas y no se normalizan. `remove` es inválido. Se validan los tipos, las claves y los límites estáticos de todo el documento antes de aplicar operaciones. Después se aplican en orden sobre una copia de la lista: cada índice se refiere al estado de su turno. Cada operación cuenta, sin deduplicación ni idempotencia. Un fallo invalida toda la solicitud; operaciones posteriores no lo compensan. Nunca se emite estado parcial y la lista de entrada no se modifica al aplicar operaciones.

En caso de error: código 2, stdout vacío y stderr exactamente estos bytes, incluido el LF final:

```text
{"error":"invalid_input"}
```

El entorno de evaluación indicado limita la ejecución a 3 segundos, 2 CPU, 1 GiB, 128 procesos y 2 MiB por stream; no tiene red y la entrega es de sólo lectura. Estas restricciones pertenecen al entorno, no se configuran mediante el programa.

## Comando de comprobación

Este comando ejecutable comprueba ambos ejemplos públicos, errores representativos, límites de bytes y listas, atomicidad ante un índice inválido, un exceso temporal de longitud y rechazo de argumentos. No se ha ejecutado aquí; no constituye evidencia de resultados ni cobertura universal. No se entregan archivos de tests todavía.

```sh
/opt/specorganon/venv/bin/python -E -s -B - <<'PY'
import json
import subprocess
import sys

command = [sys.executable, '-E', '-s', '-B', '/input/delivery/listpatch.py']
error = b'{"error":"invalid_input"}\n'

def run(payload, arguments=()):
    return subprocess.run(command + list(arguments), input=payload,
                          capture_output=True, timeout=3)

def invalid(payload, arguments=()):
    result = run(payload, arguments)
    assert (result.returncode, result.stdout, result.stderr) == (2, b'', error)

def encode(document):
    return json.dumps(document, separators=(',', ':')).encode('utf-8')

examples = [
    ({'items': [10, 20], 'operations': [
        {'op': 'insert', 'index': 1, 'value': 15},
        {'op': 'replace', 'index': 0, 'value': 9},
        {'op': 'delete', 'index': 2}]}, {'items': [9, 15], 'applied': 3}),
    ({'items': [], 'operations': [
        {'op': 'insert', 'index': 0, 'value': -2},
        {'op': 'delete', 'index': 0}]}, {'items': [], 'applied': 2}),
]
for document, expected in examples:
    result = run(encode(document))
    assert result.returncode == 0 and result.stderr == b''
    assert result.stdout.endswith(b'\n')
    assert json.loads(result.stdout) == expected

for payload in [
    b'{"items":[],"items":[],"operations":[]}',
    b'{"items":[true],"operations":[]}',
    b'{"items":[1.0],"operations":[]}',
    b'{"items":[NaN],"operations":[]}',
    b'{"items":[],"operations":[]}{}',
    b'\xef\xbb\xbf{"items":[],"operations":[]}',
    b'\x00', b'\xff',
]:
    invalid(payload)

for document in [
    {'items': [], 'operations': [{'op': 'remove', 'index': 0}]},
    {'items': [1], 'operations': [{'op': 'delete', 'index': 0, 'value': 1}]},
    {'items': [], 'operations': [
        {'op': 'insert', 'index': 0, 'value': 1},
        {'op': 'delete', 'index': 1}]},
    {'items': [0] * 1000, 'operations': [
        {'op': 'insert', 'index': 1000, 'value': 1},
        {'op': 'delete', 'index': 0}]},
    {'items': [0] * 1001, 'operations': []},
    {'items': [0], 'operations': [{'op': 'replace', 'index': 0, 'value': 0}] * 1001},
    {'items': [1000000001], 'operations': []},
    {'items': [], 'operations': [{'op': 'insert', 'index': 1001, 'value': 0}]},
]:
    invalid(encode(document))

base = b'{"items":[],"operations":[]}'
result = run(base + b' ' * (65536 - len(base)))
assert result.returncode == 0 and result.stderr == b''
invalid(base + b' ' * (65537 - len(base)))
invalid(b'', ['--help'])
print('Comprobaciones completadas')
PY
```

No se han suministrado mediciones públicas ejecutadas. La matriz candidata menciona 84 recetas, incluidas dos re-mediciones de ejemplos públicos y 82 entradas reservadas; no se afirma haberlas ejecutado. Esta entrega no demuestra eficacia de un editor real ni superioridad universal. Tokens y coste monetario desconocidos.
