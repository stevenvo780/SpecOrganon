from pathlib import Path
import os
assert set(os.listdir('/input')) == {'delivery'}
assert not Path('/var/run/docker.sock').exists()
assert not Path('/home/codex/.codex').exists()
assert not Path('/home/stev/.gemini').exists()
assert not Path('/output').exists()
Path('/tmp/private-scratch').write_text('ok')
try:
    Path('/input/delivery/forbidden.py').write_text('bad')
except OSError as exc:
    assert exc.errno == 30
else:
    raise AssertionError('delivery writable')
import sys
sys.stdout.write('{"cost":null,"path":[],"reachable":false}\n')
