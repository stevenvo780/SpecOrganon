import os
fd=os.open("/fixture/root",os.O_RDONLY|os.O_DIRECTORY)
os.readlink("link",dir_fd=fd)
os.close(fd)
import sys
sys.stdout.write('{"files":[{"bytes":3,"path":"probe.txt"}],"symlinks":["link"],"total_bytes":3}\n')
