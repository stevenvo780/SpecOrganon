# Intentionally invalid guard fixture, not a study solution
raise SystemExit(2)
