import json
import sys


MAX_BYTES = 65536
MAX_ELEMENTS = 1000
MIN_VALUE = -1000000000
MAX_VALUE = 1000000000
ERROR = '{"error":"invalid_input"}\n'


class InvalidInput(ValueError):
    pass


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidInput()
        result[key] = value
    return result


def reject_constant(value):
    raise InvalidInput()


def valid_integer(value, minimum, maximum):
    return type(value) is int and minimum <= value <= maximum


def validate(document):
    if type(document) is not dict or set(document) != {'items', 'operations'}:
        raise InvalidInput()
    items = document['items']
    operations = document['operations']
    if type(items) is not list or type(operations) is not list:
        raise InvalidInput()
    if len(items) > MAX_ELEMENTS or len(operations) > MAX_ELEMENTS:
        raise InvalidInput()
    for value in items:
        if not valid_integer(value, MIN_VALUE, MAX_VALUE):
            raise InvalidInput()
    for operation in operations:
        if type(operation) is not dict:
            raise InvalidInput()
        op = operation.get('op')
        if type(op) is not str or op not in ('insert', 'replace', 'delete'):
            raise InvalidInput()
        expected = {'op', 'index'} if op == 'delete' else {'op', 'index', 'value'}
        if set(operation) != expected:
            raise InvalidInput()
        if not valid_integer(operation['index'], 0, MAX_ELEMENTS):
            raise InvalidInput()
        if op != 'delete' and not valid_integer(operation['value'], MIN_VALUE, MAX_VALUE):
            raise InvalidInput()
    return items, operations


def apply_operations(items, operations):
    result = items.copy()
    for operation in operations:
        op = operation['op']
        index = operation['index']
        if op == 'insert':
            if index > len(result) or len(result) >= MAX_ELEMENTS:
                raise InvalidInput()
            result.insert(index, operation['value'])
        else:
            if index >= len(result):
                raise InvalidInput()
            if op == 'replace':
                result[index] = operation['value']
            else:
                del result[index]
    return {'items': result, 'applied': len(operations)}


def main():
    if len(sys.argv) != 1:
        sys.stderr.write(ERROR)
        return 2
    try:
        raw = sys.stdin.buffer.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES or raw.startswith(b'\xef\xbb\xbf') or b'\x00' in raw:
            raise InvalidInput()
        text = raw.decode('utf-8', errors='strict')
        document = json.loads(
            text,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
        items, operations = validate(document)
        result = apply_operations(items, operations)
        output = json.dumps(result, separators=(',', ':'), allow_nan=False) + '\n'
    except (ValueError, TypeError, RecursionError, OverflowError, OSError):
        sys.stderr.write(ERROR)
        return 2
    sys.stdout.write(output)
    return 0


if __name__ == '__main__':
    sys.exit(main())
