#!/usr/bin/env python3
"""Sum strictly validated JSON rational terms using exact arithmetic."""

import json
import sys
from fractions import Fraction

MAX_BYTES = 65536
MAX_TERMS = 1000
MAX_INTEGER = 1000000000
ERROR = b'{"error":"invalid_input"}\n'


def reject_constant(value):
    raise ValueError("Non-JSON constant")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate key")
        result[key] = value
    return result


def validate(raw):
    if len(raw) > MAX_BYTES or b'\x00' in raw:
        raise ValueError("Invalid byte stream")
    text = raw.decode('utf-8', errors='strict')
    if text.startswith('\ufeff'):
        raise ValueError("Initial BOM")
    document = json.loads(
        text,
        object_pairs_hook=unique_object,
        parse_constant=reject_constant,
    )
    if type(document) is not dict or set(document) != {'terms'}:
        raise ValueError("Invalid top-level object")
    terms = document['terms']
    if type(terms) is not list or len(terms) > MAX_TERMS:
        raise ValueError("Invalid terms list")
    for term in terms:
        if type(term) is not dict or set(term) != {'numerator', 'denominator'}:
            raise ValueError("Invalid term object")
        numerator = term['numerator']
        denominator = term['denominator']
        if type(numerator) is not int or not -MAX_INTEGER <= numerator <= MAX_INTEGER:
            raise ValueError("Invalid numerator")
        if type(denominator) is not int or not 1 <= denominator <= MAX_INTEGER:
            raise ValueError("Invalid denominator")
    return terms


def invalid_input():
    sys.stderr.buffer.write(ERROR)
    return 2


def main():
    if len(sys.argv) != 1:
        return invalid_input()
    # Both parsing and output conversion must handle the full contractual domain.
    sys.set_int_max_str_digits(0)
    raw = sys.stdin.buffer.read(MAX_BYTES + 1)
    try:
        terms = validate(raw)
    except (ValueError, UnicodeError, RecursionError):
        return invalid_input()

    total = Fraction(0, 1)
    for term in terms:
        total += Fraction(term['numerator'], term['denominator'])
    result = {
        'numerator': total.numerator,
        'denominator': total.denominator,
        'term_count': len(terms),
    }
    output = json.dumps(result, separators=(',', ':'), ensure_ascii=True)
    sys.stdout.buffer.write(output.encode('ascii') + b'\n')
    return 0


if __name__ == '__main__':
    sys.exit(main())
