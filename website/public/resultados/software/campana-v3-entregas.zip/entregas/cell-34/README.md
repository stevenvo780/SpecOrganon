# ListPatch

Transformación local y atómica de listas con Python 3.12 y únicamente la biblioteca estándar.

## Instalación e interfaz

Guarde `listpatch.py` en `/input/delivery/listpatch.py`. No requiere paquetes adicionales. Ejecútelo sin argumentos:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/listpatch.py
```

La entrada se recibe por stdin hasta EOF. Cualquier argumento, incluido `--help`, produce un error antes de leer stdin.

## Ejemplos públicos

Ejemplo 1:

```sh
printf '%s\n' '{"items":[10,20],"operations":[{"op":"insert","index":1,"value":15},{"op":"replace","index":0,"value":9},{"op":"delete","index":2}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/listpatch.py
```

Salida, seguida de un LF:

```json
{"items":[9,15],"applied":3}
```

Ejemplo 2:

```sh
printf '%s\n' '{"items":[],"operations":[{"op":"insert","index":0,"value":-2},{"op":"delete","index":0}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/listpatch.py
```

Salida, seguida de un LF:

```json
{"items":[],"applied":2}
```

## Formatos, límites y errores

La entrada admite como máximo 65536 bytes, incluido el whitespace. Debe ser UTF-8 estricto sin BOM ni NUL crudo y contener un único objeto JSON. Se permite whitespace JSON externo e interno. Se rechazan claves repetidas en cualquier objeto, NaN, Infinity, objetos concatenados y contenido posterior distinto de whitespace.

El objeto contiene exactamente `items` y `operations`, ambas listas de hasta 1000 elementos. Cada elemento de `items` y cada `value` es un entero JSON entre -1000000000 y 1000000000, inclusive. Cada `index` es un entero JSON entre 0 y 1000, inclusive. Booleanos, números de punto flotante y cadenas no son enteros admitidos.

Operaciones admitidas, con exactamente las propiedades indicadas:

- `{"op":"insert","index":i,"value":v}` inserta antes de `i`. Requiere `0 <= i <= longitud actual`; el extremo final agrega un elemento. La longitud nunca puede superar 1000, ni temporalmente.
- `{"op":"replace","index":i,"value":v}` sustituye el elemento en `i`. Requiere `0 <= i < longitud actual`.
- `{"op":"delete","index":i}` elimina el elemento en `i`. Requiere `0 <= i < longitud actual`. No admite `value`.

Los nombres distinguen mayúsculas y minúsculas y no se normalizan. `remove` es inválido. Primero se validan tipos, propiedades y límites de todo el documento; después se aplican las operaciones en orden sobre una copia de la lista. Cada índice se interpreta sobre el resultado de las operaciones anteriores. Cada operación cuenta, incluso si repite otra o si cambios posteriores la compensan. Un índice inválido en su turno y cualquier exceso temporal de longitud invalidan toda la solicitud. No se modifica el documento recibido por `transform` ni se emite estado parcial.

Éxito: código 0, stderr vacío y un único objeto JSON en stdout con exactamente `items` y `applied`, sin whitespace externo salvo un LF final. `applied` es el número entero de operaciones.

Error: código 2, stdout vacío y stderr exactamente `{"error":"invalid_input"}\n`, donde `\n` representa un LF real.

Los límites del entorno descrito son 3 segundos, 2 CPU, 1 GiB, 128 procesos, red deshabilitada, entrega de solo lectura y 2 MiB por stream. No son mediciones de esta implementación. Tokens y coste monetario desconocidos.

## Comprobaciones ejecutables

Desde cualquier directorio, el siguiente comando comprueba los dos ejemplos públicos, el rechazo de `remove`, claves repetidas, un booleano y un fallo secuencial sin salida parcial. También comprueba que `--help` falla sin esperar EOF en stdin. Es un alcance limitado, sin garantía de cobertura universal; no se ha ejecutado en esta entrega.

```sh
/opt/specorganon/venv/bin/python -E -s -B - <<'PY'
import json
import subprocess
import sys

command = [sys.executable, '-E', '-s', '-B', '/input/delivery/listpatch.py']
examples = [
    ('{"items":[10,20],"operations":[{"op":"insert","index":1,"value":15},{"op":"replace","index":0,"value":9},{"op":"delete","index":2}]}', {'items': [9, 15], 'applied': 3}),
    ('{"items":[],"operations":[{"op":"insert","index":0,"value":-2},{"op":"delete","index":0}]}', {'items': [], 'applied': 2}),
]
for text, expected in examples:
    result = subprocess.run(command, input=text.encode(), capture_output=True, timeout=3)
    assert result.returncode == 0 and result.stderr == b''
    assert result.stdout.endswith(b'\n')
    assert result.stdout[:1] == b'{' and result.stdout[-2:] == b'}\n'
    assert json.loads(result.stdout) == expected

invalid = [
    b'{"items":[1],"operations":[{"op":"remove","index":0}]}',
    b'{"items":[],"items":[],"operations":[]}',
    b'{"items":[true],"operations":[]}',
    b'{"items":[1],"operations":[{"op":"delete","index":0},{"op":"replace","index":0,"value":2}]}',
]
for data in invalid:
    result = subprocess.run(command, input=data, capture_output=True, timeout=3)
    assert (result.returncode, result.stdout, result.stderr) == (2, b'', b'{"error":"invalid_input"}\n')

process = subprocess.Popen(command + ['--help'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
try:
    assert process.wait(timeout=3) == 2
    assert process.stdout.read() == b''
    assert process.stderr.read() == b'{"error":"invalid_input"}\n'
finally:
    if process.poll() is None:
        process.kill()
        process.wait()
    process.stdin.close()
    process.stdout.close()
    process.stderr.close()
print('Comprobaciones completadas')
PY
```
