# RoutePlan

CLI local para Python 3.12 que calcula rutas mínimas en un grafo dirigido con costes positivos. Usa exclusivamente la biblioteca estándar. No predice tráfico, seguridad vial ni utilidad de campo.

## Instalación e invocación

Coloque `routeplan.py` en el directorio de entrega. No necesita instalar dependencias. Ejecute `python routeplan.py` sin argumentos adicionales y proporcione el JSON por stdin hasta EOF. Los comandos siguientes usan la ubicación de entrega y el intérprete indicados en el contrato.

## Ejemplos públicos reproducibles

```sh
/opt/specorganon/venv/bin/python /input/delivery/routeplan.py <<'JSON'
{"nodes":["A","B","C","D"],"edges":[{"source":"A","target":"D","cost":4},{"source":"A","target":"C","cost":2},{"source":"C","target":"D","cost":2},{"source":"A","target":"B","cost":1},{"source":"B","target":"D","cost":3}],"query":{"source":"A","target":"D"}}
JSON
```

Salida esperada:

```json
{"reachable":true,"cost":4,"path":["A","B","D"]}
```

```sh
/opt/specorganon/venv/bin/python /input/delivery/routeplan.py <<'JSON'
{"nodes":["West","East"],"edges":[],"query":{"source":"West","target":"East"}}
JSON
```

Salida esperada:

```json
{"reachable":false,"cost":null,"path":[]}
```

## Formatos y errores

La entrada debe ser exactamente un objeto JSON UTF-8 sin BOM, con las claves `nodes`, `edges` y `query`. Se permiten espacios JSON iniciales y finales. Se rechazan claves duplicadas a cualquier nivel, números decimales, NaN, Infinity, contenido adicional y fallos de decodificación o parseo, incluidos los límites de conversión de enteros del intérprete.

`nodes` contiene entre 1 y 32 strings únicos que cumplen `[A-Za-z][A-Za-z0-9_]{0,15}`. `edges` contiene entre 0 y 128 objetos con exactamente `source`, `target` y `cost`. Los extremos deben existir y el coste debe ser un entero JSON entre 1 y 1000; los booleanos no son costes válidos. No puede repetirse un par dirigido. Se admiten arcos inversos y bucles propios positivos. `query` tiene exactamente `source` y `target`, ambos existentes.

Una entrada válida produce exit 0, stderr vacío y un objeto JSON en stdout terminado en newline. Sus únicas claves son `reachable`, `cost` y `path`. Una ruta alcanzable incluye ambos extremos y minimiza el coste total; los empates se resuelven comparando lexicográficamente la lista completa de IDs ASCII. El orden de los nodos o arcos no influye. Si origen y destino coinciden, devuelve coste 0 y una lista con ese ID. Si no hay ruta, devuelve `false`, `null` y `[]` respectivamente.

Una entrada o argumentos inválidos producen exit 2, stdout vacío y exactamente `{"error":"invalid_input"}` seguido de newline en stderr, sin traceback.

## Algoritmo y límites

Se calculan las distancias al destino mediante Dijkstra sobre los arcos invertidos. Luego se elige el menor ID entre las continuaciones que conservan el coste mínimo. Los costes positivos garantizan que la distancia restante disminuye y la reconstrucción termina.

El límite de entrada es 65536 bytes inclusive; la lectura solicita como máximo 65537 bytes para detectar exceso. Los límites de evaluación son 3 segundos por invocación en 2 CPU y 1 GiB. No se han proporcionado mediciones de ejecución. El programa no abre archivos de usuario, usa red ni instala dependencias.

## Comando de tests

Esta etapa no incluye archivos de tests y no se han ejecutado pruebas. Cuando estén disponibles los tests propios, el comando de descubrimiento será:

```sh
/opt/specorganon/venv/bin/python -m unittest discover -s /input/delivery -p 'test_*.py'
```

Los tests que invoquen la CLI deberán usar el argv absoluto `['/opt/specorganon/venv/bin/python', '/input/delivery/routeplan.py']`. La entrega se considera readonly; cualquier trabajo temporal de los tests puede realizarse en `/tmp`.
