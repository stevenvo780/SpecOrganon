#!/usr/bin/env python3
"""Select rules from a fully validated JSON document using only the stdlib."""

import json
import sys


MAX_INPUT_BYTES = 65536
MAX_ITEMS = 1000
MAX_STRING_BYTES = 64
MAX_PRIORITY = 1000000000
ERROR = '{"error":"invalid_input"}\n'


class InvalidInput(ValueError):
    pass


def reject_constant(value):
    raise InvalidInput('Non-JSON numeric constant')


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidInput('Duplicate object key')
        result[key] = value
    return result


def check_object(value, keys):
    if type(value) is not dict or value.keys() != keys:
        raise InvalidInput('Incorrect object fields')


def check_list(value):
    if type(value) is not list or len(value) > MAX_ITEMS:
        raise InvalidInput('Invalid list')


def check_string(value):
    if type(value) is not str or not value:
        raise InvalidInput('Invalid string')
    if any(character in value for character in ('\x00', '\r', '\n')):
        raise InvalidInput('Forbidden string character')
    if len(value.encode('utf-8', errors='strict')) > MAX_STRING_BYTES:
        raise InvalidInput('String exceeds byte limit')


def string_set(value):
    check_list(value)
    for item in value:
        check_string(item)
    return set(value)


def validate(document):
    check_object(document, {'rules', 'queries'})
    check_list(document['rules'])
    check_list(document['queries'])

    rules = []
    names = set()
    for rule in document['rules']:
        check_object(rule, {'name', 'priority', 'requires'})
        name = rule['name']
        check_string(name)
        if name in names:
            raise InvalidInput('Duplicate rule name')
        names.add(name)
        priority = rule['priority']
        if type(priority) is not int or not -MAX_PRIORITY <= priority <= MAX_PRIORITY:
            raise InvalidInput('Invalid priority')
        requires = string_set(rule['requires'])
        rules.append((priority, name, requires))

    queries = []
    identifiers = set()
    for query in document['queries']:
        check_object(query, {'id', 'tags'})
        identifier = query['id']
        check_string(identifier)
        if identifier in identifiers:
            raise InvalidInput('Duplicate query id')
        identifiers.add(identifier)
        tags = string_set(query['tags'])
        queries.append((identifier, tags))
    return rules, queries


def decide(rules, queries):
    rules.sort(key=lambda rule: (-rule[0], rule[1]))
    decisions = []
    for identifier, tags in queries:
        selected = None
        for priority, name, requires in rules:
            if requires.issubset(tags):
                selected = name
                break
        decisions.append({'id': identifier, 'rule': selected})
    return {'decisions': decisions}


def fail():
    sys.stderr.write(ERROR)
    return 2


def main():
    # Reject arguments before touching stdin, including --help.
    if len(sys.argv) != 1:
        return fail()
    try:
        raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
        if len(raw) > MAX_INPUT_BYTES:
            raise InvalidInput('Input exceeds byte limit')
        if raw.startswith(b'\xef\xbb\xbf') or b'\x00' in raw:
            raise InvalidInput('BOM or raw NUL')
        text = raw.decode('utf-8', errors='strict')
        document = json.loads(
            text,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
        rules, queries = validate(document)
        result = decide(rules, queries)
        output = json.dumps(result, ensure_ascii=True, separators=(',', ':'))
    except (ValueError, TypeError, RecursionError, OverflowError):
        return fail()
    sys.stdout.write(output + '\n')
    return 0


if __name__ == '__main__':
    sys.exit(main())
