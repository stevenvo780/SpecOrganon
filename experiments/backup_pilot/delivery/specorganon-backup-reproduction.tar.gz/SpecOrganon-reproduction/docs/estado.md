# Estado de reanudación

## MVP local disponible

El [MVP](mvp.md) tiene una [entrada de uso](uso_local.md), skill para agentes,
política local explícita y reporte CLI/MCP. Dos proyectos recorrieron nueve
fases con revisión nativa separada y comandos reales. Se verificaron replay
sin duplicados, reanudación en procesos nuevos y reapertura al cambiar una
hipótesis; el original quedó intacto. La reproducción escolar fue exacta.
[Resultados y límites](../experiments/development/mvp_local_2026-10-01/results.md).

Pasaron 263 pruebas de regresión incluidas las 52 nuevas, estáticos y
validador de skill. Un wheel instalado fuera del árbol descubrió 24
herramientas MCP; report y replay de ambos proyectos coincidieron por
CLI/MCP sin modificar el ledger. `signed` conserva su valor inicial;
`local_declared` no autentica personas ni impacto de campo.

El siguiente trabajo es aplicar el MVP a nuevos encargos locales. Los
veredictos finales C2–C5 siguen no demostrados y las 24 celdas del estudio
original siguen pendientes; ese conteo no determina la disponibilidad del
MVP. Los apartados siguientes conservan los cortes anteriores.

## Prioridad del dueño · 2026-10-01: MVP usable

El siguiente hito es el [MVP de SpecOrganon](mvp.md): una evolución de SDD
con filosofía, ciencia e ingeniería, aplicada primero a proyectos locales
manejables con las herramientas y suscripciones actuales. El dueño define
propósito y límites; los agentes investigan, construyen, prueban y revisan.
La financiación y los estudios finales se abordan después. Esto ordena el
trabajo sin cambiar GOAL ni los criterios y resultados registrados.

Ya existen fases, CLI, MCP, trazabilidad y reanudación. Falta cerrar y
demostrar un recorrido sencillo que produzca una solución local útil,
incluida la integración de revisión técnica con las compuertas actuales.
Los registros D-124 y anteriores que siguen describen sus cortes
históricos; sus dependencias experimentales no bloquean todo el trabajo del
MVP. C1 técnico se conserva; C2–C5 siguen no demostrados.

**D-124 permite leer evaluaciones externas DEV:**
[dossier](../experiments/development/external_rating_ingress_2026-10-01/README.md).
API pura y CLI de lectura privada con hashes, cinco notas enteras0..20,
incidentes separados y originales sin cambios. Suma100 con incidente sigue
siendo una declaración; Q, independencia, custodia y aceptación no verificadas.

Plan776710a/freeze4459ae2: **87 pruebas por Python3.11/3.12**, estáticos0 y
siete CLI nuevos por intérprete (tres aceptados/cuatro rechazados). Dos archivos
de21 miembros cotejados contra originales; snapshots before/after persistidos,
ocho fuentes/HEAD intactos.19 archivos originales del borrador conservados.
P2 del archivado con rutas `..` detectado por revisión, corregido y reproducido
sin efectos; freeze/capturas anteriores permanecen. D123725 registros live y
cuatro docs históricos Git, recibo y cierre heredado preservados.

**C1 técnico D107; C2–C5 No demostrado; 0/24 formales.** Sin API experimental,
credenciales o notas humanas. La [puerta siguiente](../experiments/development/external_rating_ingress_2026-10-01/next_activation.md)
requiere elección/autorización/acceso, revisores/custodio y mediciones reales,
luego12R1→adaptación/freeze→12R2/selección→confirmación→campo/transferencia.
El dueño indica un revisor y custodio disponibles; falta aclarar si coinciden
en una persona y verificar los roles. El panel confirmatorio sigue pendiente.
Los controles sintéticos no sustituyen esa evidencia. Cortes siguientes históricos.

**D-123 agrega entrada Responses futura y lectura de respuestas rechazadas:**
[dossier](../experiments/development/authorized_route_entry_2026-10-01/README.md).
Flag de gasto y declaración privada ligada a run/modelo/recursos/fuentes,
guard antes del I/O real del hilo y clave leída sólo tras gates. Permiso local
cooperativo, sin autenticar al humano. Espera local≤90/deadline nativo;
resultados tardíos descartados, sin garantía de cancelación remota.
Outcomes lee bajo lock/guard original; indeterminate no afirma replay completo
ni reejecuta. Uso declarado y reservas son columnas alternativas.

Plan080acba/freeze7246936: **74 pruebas por Python3.11/3.12**, Ruff/sintaxis/diff0,
seis controles completos A/B/C nuevos,146CLI y110sends completos de fixture.
Dos incomplete adicionales: costo declarado7µUSD y reserva133µUSD/133tokens
por run, retenida sin publicación/reexec; ruta OpenAI sin permiso rechazada.
Archivos por bytes/modos y fuentes intactas; D1215875/D122121 pins+recibos
conservados y docs históricos Git. Fallo de lifecycle y dos timeouts600s
preservados, con sus límites de captura; repetición completa verificada.

**C1 técnico D107; C2–C5 No demostrado; 0/24 formales.** Sin clave real/API
pagada/Q/campo. Luna hizo dos intakes cotejados; equivalencia de calidad no
medida. Siguen elección/autorización/acceso/modelo efectivo, telemetría real,
evaluación competente/H/costos completos. Próximo trabajo local:
[ingreso de evaluaciones externas](../experiments/development/authorized_route_entry_2026-10-01/next_activation.md).
Luego12R1→adaptación/freeze→12R2/selección→confirmación→campo/transferencia.
Los cortes siguientes permanecen históricos.

**D-122 prepara una propuesta concreta para doce R1 reales:**
[dossier](../experiments/development/real_route_proposal_2026-10-01/README.md).
Opciones Astra/Luna `high`, misma información/roles/recursos y política de
orden original; alias declarado no acredita snapshot. Cuatro bundles
build/verify originales por Python 3.11/3.12, doce celdas cada uno; cero
envíos/runtimes/claims/R1. Tarifa Standard actual y cota condicional de sólo
tokens de modelo: USD 48,001536 Astra o 0,481536 Luna por doce celdas.
Saldos locales propuestos USD 60/0,60, ninguno autorizado; costes completos
desconocidos y calidad relativa no medida. Luna hizo inventario acotado.

D121 5.879 pins+receipt iguales antes/después del build, antes de avanzar
estos docs; cortes históricos en Git `9f90b79`. Faltan acceso/elección del
dueño, entrypoint real conservando guards/observación, binding modelo servido,
conteo/uso/incomplete, capacidad `high`/8192 y evaluación independiente.
[Puertas concretas](../experiments/development/real_route_proposal_2026-10-01/readiness.md).
**C1 técnico D107; C2–C5 No demostrado; 0/24 formales.** No se ha seleccionado
ni autorizado una ruta. Sigue 12 R1→adaptación/freeze→12 R2/selección,
confirmación independiente, campo causal y transferencia.

**D-121 observa prospectivamente una ejecución coordinada local:**
[dossier](../experiments/development/coordinated_observation_2026-10-01/README.md).
Journal separado de eventos/clocks/boot, locks distintos, tokens revocables;
proxy count/send y hook del broker real por instancia, delegación única y
timeout que incluye I/O. Snapshot/guard/replay/publicación D119 y conciliación
D120 verifican sets/digests/uso y containment de send; host/sandbox son
subconjuntos separados. W local mide liberación→marca de entrega verificada,
con pausas/guard/I/O; no recepción externa, H o CPU/remoto.

Plan `d8bbae8`, freeze `892d6a8`: 104 registros + extractor, 105 con self.
**88 pruebas por Python 3.11/3.12**, Ruff/sintaxis/diff 0. Seis runs NUEVOS
A/B/C × D-E, 118 CLI, 110 count/110 send y 66 tools originales;
770 tokens de fixture. Dos releases históricos rechazados sin observador.
Baseline D119/D120 2283/2439 pins con docs históricos en Git y los doce
inventarios originales iguales antes/después. Archives dos × 1369 entradas
por bytes/modos/membresía/raíces. Intentos negativos con fuentes/streams intactos.

**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.**
Sin modelo pagado/Q/autoridad/campo/reserva. Luna ayudó en inventario; no se
midió su calidad relativa. Siguen ruta/modelo/esfuerzo/telemetría/precios y
autorización concreta, H/remoto/costes de estudio; después 12 R1→adaptación/
freeze→12 R2/selección, confirmación independiente, campo causal y transferencia.
[Siguiente puerta](../experiments/development/coordinated_observation_2026-10-01/next_activation.md).
Los cortes siguientes conservan su alcance histórico y no se reinterpretan.

**D-120 concilia mediciones locales del runtime coordinado:**
[dossier](../experiments/development/coordinated_measurement_2026-10-01/README.md).
Lector separado con un lock original, guard/replay/publicación nativos,
conjuntos exactos request/response/receipt/ledger y herramientas. Uso y coste
declarado se cotejan por request/rol/brazo; caché y razonamiento no se cuentan
dos veces. Faltantes y alcances de send/sandbox/host/contexto quedan explícitos.
La API pura no afirma que haya ejecutado el guard; el CLI sí verifica ese
control local, sin autenticar proveedor, tarifa o factura.

Plan `357ac43`, freeze `8576cc6`: 92 registros y 93 con el propio freeze.
**51 pruebas nuevas por Python 3.11/3.12**, Ruff/sintaxis/diff exit 0 y fuentes/HEAD
iguales antes/después. Doce CLI de lectura sobre D119 terminado, sin
reejecución: 113 requests, 69 tools y 791 tokens sintéticos conciliados por entorno;
calendarios distintos. Todos los inventarios originales y 2283 pins D119
iguales antes/después de las capturas. Sólo después avanzan cuatro docs
activos; originales enGit `c64169c`, dossiers/fuentes/casos/GOAL intactos.
Tres gaps PURE reproducidos y cerrados con negativos; fuentes/streams
conservados y limitación del intento01 sin bytes originales explícita.

**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.**
Sin nuevas llamadas a modelo/tools, Q, autoridad humana o campo. Siguen W
prospectivo/H/conteo/actividad remota y ruta real autorizada con precios/uso
verificables; después 12 R1→adaptación/freeze→12 R2/selección, reserva y campo/
transferencia. Luna realizó inventario acotado, sin comparación de calidad.
Los cortes siguientes conservan su alcance histórico.

**D-119 implementa el runtime persistente coordinado A/B/C:**
[dossier](../experiments/development/coordinated_runtime_2026-10-01/README.md).
Work vacío/init original del líder, delegaciones repetidas, replay/merge,
reviewer público y análisis final vigente comparten un único saldo,
contexto y claim. A selecciona un worker; B/C permiten dos independientes.
Se conservan sus modos, cuatro fases, invalidaciones y normas pendientes.
El wrapper exige la publicación D118 y el intérprete exacto del bundle;
el broker coteja política, launchers y ejecutables antes de efectos y al reabrir.

Freeze corregido `7de98c9`: 82 fuentes + extractor, 125 rutas históricas
intactas. Se conservan la carrera de captura reproducida/corregida, el
prepare cross-interpreter aceptado y luego rechazado antes de IO, y los dos
timeouts de las primeras suites. La revisión independiente cerró el binding
y auditó los doce recorridos finales. **317 pruebas por intérprete**,
Ruff/sintaxis/diff0 y 83 fuentes before/after idénticas. Seis runs originales
D-F/D-E por Python:112 CLI,113 sends/69 tools de fixture, claim único y
métricas finales vigentes; A serial, B/C con solapamiento HTTP local.
Archivo37raíces:53.857regulares/12.643blobs/47.929.387B, SHA f7c7c884…,
18.234directorios/499symlinks/2FIFO sólo metadata, sin restaurar autoridad.

**C1 técnico D107 preservado; C2–C5 No demostrado; 0/24 formales.**
Respuestas/usage/precios son de fixture; no Q, aprobación normativa, uso o
actividad remota autenticados. El [intake de medición](../experiments/development/coordinated_runtime_2026-10-01/planning/next_measurement_intake.md)
separa deadline local, pared W y actividad acumulada. Siguen rutas y medición/autorización antes de
12 R1 reales, adaptación/freeze y 12 R2, selección independiente, reserva,
custodia/panel/jueces, campo causal y transferencia. Los cortes siguientes
conservan su alcance histórico.

**D-118 fija contrato y preparación comunes para desarrollo coordinado A/B/C:**
[dossier](../experiments/development/coordinated_contract_2026-10-01/README.md).
Calendario NUEVO de 12 IDs R1/cuatro bloques: líder, dos workers y reviewer,
mismo modelo/esfuerzo/acceso/saldo padre. Modos y cuatro fases originales
conservados; calendario solo anterior intacto. Build/verify usa 6+3 fuentes
originales, 38 derivados PDF comunes, herramientas y contrato/rúbrica públicos
sin cifras resueltas. Checker valida estructura/procedencia formal sin ejecutar
participante, autenticar métricas o asignar Q. Descriptor concordante sólo
declara binding: runtime_authenticated/execution_authorized siguen false.
Freeze `6a36197`, 62 pines repo y extractor externo: **265 passed por Python
3.11/3.12**, Ruff/compile/diff0, 63 registros before/after por gate intactos.
Dos integraciones CLI reales de preparación: 106 archivos verificados, 12
IDs, seis fixtures estructurales, 12 bindings y cuatro rechazos por intérprete;
cero requests de modelo y celdas formales. Luna inventarió 103 rutas históricas,
cotejadas íntegramente por root y revisor. Evidencia y revisión final en dossier.

**C1 técnico D107 preservado; C2–C5 No demostrado; formales 0/24.** Faltan
runtimes coordinados A/B, continuidad/binding C con el calendario nuevo,
medición auténtica de consumo y suma de actividad, rutas/autorización; luego
12 R1→adaptación/freeze→12 R2/selección. Digest de freeze/prompt declarado no
autentica runtime/custodia ni autoriza gasto. Siguen panel, reserva, jueces,
autoridades, campo y transferencia. Protocolo §2 no impone solo ni nueve fases
a prototipos; §3 N/S/T conserva solo/trío. GOAL/protocolo/core/producción/wheel/
casos y dossiers anteriores intactos. Los cortes siguientes son históricos.

**D-117 arranca C desde work vacío dentro de un único runtime padre:**
[dossier](../experiments/development/parent_analysis_2026-10-01/README.md).
El líder lee un bloque del caso, crea el grafo con init sellado real y publica
su texto. La transición deriva ramas privadas bajo el mismo ledger/contexto/
claim y saldo; reviewer y merge continúan esa contabilidad. Se validan cuatro
journals de merge antes de finish y al consultar completed. Rechazo de solapes
físicos de fuentes, run, stages y admisión antes de mkdir; replay y cache
conservan hashes, imports e historias. D113/D115/D116 permanecen intactos.
Freeze `25f8730`: **98 passed por Python 3.11/3.12**, Ruff/compile/diff 0,
55 pines fuente/90 base y 52 copias before/after por gate. Seis trazas físicas
originales D-F/D-E HTTP/CLI: 14 requests/10 tools/182 tokens de fixture cada
una; líder 3 requests/2 tools dentro del saldo, init real, dos métricas
vigentes, reparación CAS y normas pending. Archivo de 13 raíces: 23.985
regulares/3.568 blobs/10.026.409 B, SHA cf0a15f8…; cotejado entero por root y
revisor, sin P1/P2 abierto en alcance. Intentos fallidos conservados, incluida
colección sin runtime y validación incorrecta del JSON original del core.

**C1 técnico D107 vigente; C2–C5 No demostrado; formales 0/24.** D117 termina
una wave del prototipo: no equivale a las nueve fases del motor metodológico
ni fija aún coordinación/contrato/rúbrica comunes A/B/C. Siguiente:
continuidad y contrato prospectivo, medición auténtica de uso y suma de
actividad de agentes, ruta/modelo/esfuerzo/versiones/telemetría/autorización;
12 R1 reales, adaptación/freeze R2, 12 R2 y selección. Siguen custodia,
panel, jueces, autoridades, reserva, campo y transferencia. Luna hizo el
inventario de 90 rutas, cotejado por root y revisor; no fue ensayo de calidad.
GOAL/protocolo/producción/core/wheel/casos intactos. Los cortes siguientes
son históricos y conservan los pendientes que tenían entonces.

**D-116 integra análisis protegido y métricas frescas en las ramas de C:**
[dossier](../experiments/development/parallel_analysis_2026-10-01/README.md).
Manifest v2 y adapter nuevos sobre D115 intacto; mismo ledger/contexto/claim,
CAS de reparación y presupuesto sin reset. Host valida JSON, publica/retira
métricas y replay conserva before/after-child/after-host reales. Export sólo
con script y todo work no métricos vigentes; preflight de política antes de
crear run/branches. Consulta desde proceso nuevo con intérprete registrado.
Freeze `088bd2a`: **114 passed por Python 3.11/3.12**, Ruff/compile/diff0,
52 pines fuente/71 base intactos y 50 copias before/after por gate. Seis trazas
distintas de fuentes originales D-F/D-E HTTP/CLI con 11requests/8tools/143tokens
reportados por fixtures; JSON inválido reparado, dos métricas frescas, normas
pending y grafo original intacto. Archivo 9.739 regulares/3.580 blobs/8.445.310B
SHAfaaa70c… cotejado entero por root/revisor; sin P1/P2 abierto en alcance.
Fallos de fixture/policy, claim glob y afinidad de intérprete conservados.

**C1 técnico D107 vigente; C2–C5 No demostrado; formales 0/24.** El grafo
inicial aún lo aporta el caller: este perfil no prepara una comparación justa.
Siguiente: runtime padre desde work vacío, `init` real del líder sin abrir otro
ledger/claim, coordinación prospectiva comparable A/B/C. Protocolo§2 permite
coordinación; el solo del compilador D112 es una decisión local, no mandato.
Después contrato/rúbrica común sin respuestas, ruta/modelo/effort/versiones/
telemetría/autorización, R1/R2 reales y selección; siguen panel/custodia/jueces/
autoridades/banco sellado/campo/transferencia. Luna sólo hizo el inventario de
preservación, cotejado por root; no fue ensayo de calidad. GOAL/protocolo/
producción/core/wheel/casos originales intactos. Los cortes siguientes son históricos.

**D-115 ejecuta herramientas en ramas privadas e integra sus efectos:**
[dossier](../experiments/development/parallel_tools_2026-10-01/README.md).
Perfil nuevo con conversaciones privadas y pausas CAS, un claim padre,
ledger/reloj/topes comunes, sandbox sellado y ownership disjunto. Reviewer
serial sólo recibe artefactos públicos; replay de RAW/recibos/ledger/historia
antes de tools. Merge obligatorio reproduce operaciones con el core original,
reúne dos cambios y reportes y conserva invalidaciones/normas pending. Publicación
sólo tras finish y marcador válido; v1 textual conserva su contrato.
Freeze `9a6c4d8`: **272 passed en3.11 y272 en3.12**, Ruff/compile/diff0,
34 fuentes/38 base y41 copias por gate intactas. Seis corridas HTTP/CLI
sintéticas distintas:7requests/4tools/91tokens ficticios cada una. Archivo12.671
regulares cotejado por root y revisor; tres P2 cerrados y negativos conservados.

**C1 técnico D107 vigente; C2–C5 No demostrado; celdas formales0/24.**
Siguiente: integrar análisis/métricas D113 en este perfil C y preparaciones
comparables, fijar contrato/rúbrica común sin respuestas y ruta/modelo/effort/
versión/telemetría/autorización. Luego12R1 reales→adaptación/freeze→12R2,
selección; siguen panel, custodia, jueces, autoridades, reserva, campo y
transferencia. El wrapper C de este corte sólo expone el driver de método;
analysis_readonly del broker es un control aislado, sin validador genérico/Q.
GOAL/protocolo/producción/core/wheel/casos originales intactos. No hay proveedor
auténtico ni gasto/campo/autoridad humana acreditados. Los cortes siguientes
son históricos y conservan sus pendientes de esa fecha.

**D-114 ejecuta propuestas C en paralelo con presupuesto común:**
[dossier](../experiments/development/parallel_wave_2026-10-01/README.md).
WaveLedger schema 3 reserva el lote entero antes de cualquier envío; contexto
schema 2 optativo fija ese ledger, claim y plazo. Dos a cuatro workers con
contextos privados, reviewer serial, mismo modelo/esfuerzo solicitado. Host
conserva respuestas oportunas y sólo expone artefactos con cierre completed.
Normas de entrada sin autoridad no se aceptan; grafo intacto y cero tools.
Freeze `4e9de575`: **231 passed en 3.11 y 231 en 3.12**, Ruff/compile/diff,
24 fuentes y 38 base intactas. Seis trazas distintas HTTP/CLI sintéticas;
7.875 regulares archivados y cotejados por root/revisor. Tres P2 corregidos,
negativos y error de enumeración de alias conservados/documentados.

**1/5 C1 técnico D107; C2–C5 No demostrado; celdas formales 0.**
Siguiente: herramientas en branches privadas e integración C bajo presupuesto,
registro comparable y contrato/rúbrica común sin respuestas; ruta/modelo/
telemetría/autorización, 12 R1 reales, adaptación/freeze R2 y 12 R2, selección.
Siguen custodia, panel, jueces, autoridades, banco sellado, campo y transferencia.
El perfil nuevo no reinterpreta DEV solo/tríos; no demuestra calidad, identidad,
effort efectivo, factura ni cancelación remota. GOAL/protocolo/producción/core/
wheel/casos originales intactos. Los cortes siguientes son históricos.

**D-113 ejecuta análisis con estado protegido y fuentes comunes:**
[dossier](../experiments/development/isolated_analysis_2026-10-01/README.md).
Config/calendario/política2 optativos: dos tools sellados workspace/analysis_readonly,
mismo ledger/claim/contexto. Host valida JSON, liga script/métricas SHA y comprueba
inventario; errores normales se corrigen con replace CAS contado, sin reponer
límites ni aprobar normas. Se conservan6+3 originales y se añaden38 derivados
PDF comunes, todas35páginas. Freezec7979a8: **470passed3.11/178passed3.12**,
Ruff/compile y cuatro CLI build/prepare aprobados,49pins fuentes/38base intactos.
Seis trazas de fixture por intérprete D-F/D-E×A/B/C, cálculo/oráculo independiente
y norma pending; proveedor falso, **celdas formales0**. Revisión cerró tres P2,
negativos conservados; archivo27610regulares/4482blobs cotejado independientemente.

**1/5 C1 técnico D107; C2–C5 No demostrado.** Siguiente: C paralelo efectivo,
contrato/rúbrica comunes sin respuestas antes de R1, modelo/ruta/telemetría/
autorización;12reales R1→adaptación/freezeR2→12reales R2 y selección. Siguen
custodia/panel/jueces/autoridades/banco sellado/campo/transferencia. Oráculo del
corte sólo contrato de fixtures, no Q ni validador genérico. Señales/timeout/
tamper bloquean, frontera local sin atestación externa. GOAL/protocolo/producción/
wheel intactos. Los cortes siguientes son históricos y sus pendientes de su fecha.

**D-112 conecta preparaciones A/B/C con el ejecutor común:**
[dossier](../experiments/development/development_round_adapter_2026-10-01/README.md).
Esquema DEV explícito para12 preparaciones R1; D-F/D-E originales fijados a
Git98a1403, core embebido y modos reales, precio/topes comunes comprobados en
los runners. Freeze1c3cbf4:233passed3.11/142passed3.12, Ruff/compile/diff y
CLI build/prepare aprobados. Seis trazas mecánicas con sandbox, ocho tools,
ledger único y relevo sin reposición;150tokens/costo sintéticos por traza,
norma pending. Negativos y fuente previa conservados; fchmod incompatible
con sandbox corregido sin flexibilizarlo; revisión independiente cerrada
sin P1/P2 abierto en el alcance preparatorio.

**1/5 C1 técnico; C2–C5 No demostrado; cero nuevas celdas formales.**
Antes de R1 real faltan análisis aislado, lectura común de PDF/CSV bajo topes,
paralelismo real C y ruta/telemetría/autorización. Luego R1→mejoras/freezeR2,
24 ensayos y selección; siguen custodia/jueces/autoridades/campo/transferencia.
Ronda2 rechazada por el preparador hasta su adaptación prospectiva. Aceptación
mecánica de fases no significa revisión humana. GOAL/protocolo/producción/
wheel y fuentes originales intactos. Los cortes siguientes son históricos.

**D-111 integra un contexto de presupuesto y relevos por corrida:**
[dossier](../experiments/development/shared_run_context_2026-10-01/README.md)
y [contrato](presupuesto_solicitudes_modelo.md). Runner schema2: modelo/esfuerzo
únicos, ledger y sesión/claim compartidos, segmentos secuenciales de líder,
especialista y revisor. Checkpoint con CAS y fuentes/journals fijados; tokens,
costo declarado, solicitudes, herramientas y tiempo no se reinician al cambiar
de rol o proceso. Historial bruto privado por rol; solo entregables textuales
seleccionados pasan entre roles. Lease revocado y guard antes/después de efectos;
active incierto y cierre incompleto no pueden reanudarse.

Freeze0498de3 precede gates finales: 89passed3.11/36passed3.12; Ruff/compilación
aprobados, compatibilidad v1 y revisión independiente sin P1/P2 abierto en ese
alcance. Tres P2 de código cerrados con fuentes originales preservadas; negativo
del reloj2failed esperados antes del arreglo, luego10passed por Python. Primer
foco de integración25passed es exploratorio, no el freeze. Dos archivos conservan
4649regulares; symlinks/directorios solo metadata, sin imagen de sesión completa.
GOAL/protocolo/24módulos/wheel intactos; helper v1 recibe guard opcional explícito.

**1/5 en alcance técnico C1 D107; C2–C5 No demostrados.** Proveedores falsos y
fixtures públicas, sin factura/identidad autenticadas, Q, 24celdas, jueces, normas,
reserva nueva, campo o ejecución pagada. Siguiente: configuración y telemetría
operativas de las 24celdas A/B/C × D-F/D-E × dos rondas × dos repeticiones;
selección/freeze y custodia/evaluadores/sitio de campo independientes. Este
control no sustituye esas dependencias. Los cortes siguientes son históricos.

**D-110 corrige admisión antes de solicitudes del bridge:**
[dossier](../experiments/development/bridge_model_admission_2026-10-01/README.md).
Negativo pre-fix: dos copias textuales del mismo intento completaban2conteos/
2envíos falsos cada una. El bridge adquiere claim dentro del plazo activo antes
del primer conteo y lo revalida antes de cada conteo/envío. Copia bloqueada0/0,
ledger intacto; concurrencia, alteraciones e interrupción cubiertas. Python3.11
46passed y subset3.12 8passed/20deselected; Ruff/compile/diff de código pasan, revisión
independiente sinP1/P2. Planecd7ca5; source9dc2bc…/test51671b… estables.
Originales/negativos/77miembros de archivo conservados. Primer focal44pass/2fail
por expectativas erróneas de status: logs/hash conservados, bytes del test
intermedio no guardados; launcher127 previo a pytest separado. Scope local
cooperativo, sin identidad/coste/cancelación remotos ni límites globales.
Producción/wheel/GOAL/protocolo intactos, sin nuevos proveedores reales,
normas humanas, reserva/campo o celdas24. **1/5; C2–C5 No demostrados.**
Sigue pendiente el contexto común de presupuesto/admisión del ensayo y las
dependencias externas concretas de D109. Los cortes siguientes son históricos.

**D-109 ordena la activación del ensayo pendiente:**
[dossier](../experiments/development/activation_readiness_2026-09-30/README.md)
y [puertas actualizadas](activacion_validacion.md). Inventario no ejecutable de
24 celdas: A/B/C × D-F/D-E × dos rondas × dos repeticiones; cero ejecutadas.
Se separan de N/SDD/toolkit y de los pilotos expuestos. Se corrige el resumen
obsoleto de activación: **1/5, C1 técnico D107/23 operaciones; C2–C5 No demostrados**.
Cuotas y catálogos son observaciones públicas; Codex carece de sonda fiable,
Gemini ofrece etiquetas bajo/alto y MiniMax M3.1 añade una opción documental
de esfuerzo que aún no anuncia la herramienta local. No se congela panel,
reclasifica historial ni autoriza gasto. Tarifas API y cotas aritméticas de
tokens se distinguen de suscripción, factura y presupuesto completo.

Siguiente trabajo: integrar admisión/topes por corrida entre agentes,
solicitudes y herramientas; fijar configuración prospectiva de las 24 celdas.
Después de dos rondas y selección, congelar el candidato y pasar a custodia,
reserva y evaluación independiente. Faltan acceso/telemetría efectivos,
recursos y autoridad humanos, jueces y sitio alimentario. Sin nuevos modelos
experimentales, Q, firmas humanas, campo ni pruebas globales en D109.
Los cortes y sus resultados siguientes son históricos identificados.

**D-108 enlaza energía documental con el grafo alimentario:**
[dossier](../experiments/development/bread_energy_derivation_2026-09-30/README.md)
y [Pan68 publicado](../cases/bread_documentary_energy/README.md).
103/184kWh/kg de pan producido, racional exacto y HALF_EVEN24/error≤5e-25
sólo de representación. Tres fuentes publicadas fijadas por versión → nuevo
protocolo/inferencia/evidencia/indicador; revisión de cualquiera invalida los
cuatro nodos. Fecha UTC de derivación separada de publicación2018-12-21;
registros empresariales de fecha desconocida, incertidumbre física no cuantificada.

Plan880ccbd, instrumentosb7a1df6, freeze64aa0a8/89inputs presentes en Git.
Un intento por Python3.11/3.12 reutiliza wheel D107 sin rebuild/install:
CLI/MCP4puts por positivo,68eventos/prefijo64, replay0/4, discovery23;
58pares por entorno, tres revisiones de fuentes y dos controles de archivo,
siete negativos puros del constructor. 243registros por entorno incluyen
streams/modelos SDK, tiempos y comparaciones; no243invocaciones. Cuatro
pruebas de contrato pasan por Python, Ruff/compile pasan; global2674 sigue D107.
Dos tar/432regulares y diez copias publicadas sin locks; revisión independiente
confirma bytes/cadenas/24módulos/1555archivos por venv. Cero nuevas normas,
reviews o fases aceptadas; cuatro umbrales de intervención siguen nulos.

**Aceptación1/5; C1 técnico permanece en wheel D107, C2–C5 No demostrados.**
Sin modelos experimentales/Luna nuevo/Q/campo/reserva24. El constructor
específico verifica la división; put genérico no autentica semántica ni fuentes.
El cálculo no sustenta los cuatro indicadores de intervención ni resuelve
baseline/autoridad/eficacia. Próximo frente: evidencia técnica tipada de captura
y bases, evaluación final independiente y comparaciones/condiciones de campo.

Conservación Git D107 corregida en6b5ccb4: .gitignore/wheel ignorados en474ed13
incorporados con bytes originales;470pines finales verificados contra HEAD.
Reproducción D107 exige checkout combinado/nuevo registro prospectivo,
como explica su dossier. Las notas siguientes son históricas.

**D-107 añade retiro versionado y enlaza la reproducción con el grafo:**
[dossier/recibo](../experiments/development/indicator_retirement_2026-09-30/),
[Citi62 publicado](../cases/citibike_march2024_reproduced/README.md) y
[contrato](retiro_indicadores.md). Wheel137581B SHA63c58a91…:24módulos iguales
a src/site en Python3.11/3.12. 23/23operaciones CLI/MCP; cuatro workflows
signed_report/observed con9fases sintéticas/50–51eventos. Suite2674passed,
Ruff/compile aprobados. Retiro con versiones/revisión/reemplazos conserva
rechazo/historia; no oculta errores, consumidores o mínimos. Revisión signed
excluye autores históricos y del retiro. Cambios reabren; restauración exacta
sin evento duradero puede recuperar snapshots anteriores.

Cada sonda conserva182capturas,52pares/seis controles y dos positivos62eventos
con prefijo52. D106 queda como evidencia documental/inferencia; i_rows3 idéntico,
retirado. Study/explain conservan sólo el bloqueo previo para los dos defectos
D105 abordados. Citi sigue con cero fases aceptadas y normas/decisión sin aprobar.
Cuatro tar/596regulares, seis symlinks sólo metadata; revisión independiente coteja
bytes/cadenas/1555archivos por venv/23tools y nueve copias publicadas sin locks.
Fallo uv-symlink conservado (cero builds), reparación acotada a26b15b; freeze474ed13
precede cuatro ejecuciones exitosas sin retry. Build invocó alias de uv fijado
antes/después, sin atestación atómica del exec.

**Aceptación1/5; C1 técnico actualizado al wheel D107; C2–C5 No demostrados.**
Sin Q, generación experimental, Luna nuevo, norma humana, campo, rerun de filas
o corrida24. GOAL/matriz y evidencia histórica conservados. Notas D105/D106
siguientes son históricas. Próximo: energía documental del pan103/184kWh/kg,
aún no ejecutada; evaluación independiente, umbrales/baseline/autoridad de campo
y comparaciones siguen pendientes.

**D-105/D-106 añaden fracciones tipadas y repetición de filas:**
[variante reproducible Citi52](../cases/citibike_march2024_fractions/),
[ejecución y controles D-105](../experiments/development/citibike_fraction_lineage_2026-09-30/)
y [reproducción de conteos D-106](../experiments/development/citibike_raw_count_audit_2026-09-30/).
Dos evidencias e indicadores escalares conservan los racionales exactos,
representación HALF_EVEN24 y error≤5e-25; no es un umbral de eficacia.
El mismo wheel D-102 en Python3.11/3.12 aplica9puts por CLI y MCP releyó0/9:
22tools,25pares por entorno,5trazas y9gates. Prefijo42 intacto,52eventos;
reject técnico de i_rows3 no constituye aprobación humana. Denominador
revisado con datos idénticos invalida9descendientes, excluidos/huecos siguen
vigentes; alteración/eliminación del archive detectadas sin añadir eventos,
restauración exacta. Cuatro negativos de contrato rechazados por entorno.
Primeros dos intentos fallaron antes de puts: constructor asumía42puts y
eran40puts+review23+advance24. Fuentes/streams/tar conservados; corrección
acotada revisada y congelada antes de repetir en nuevos destinos. Cuatro
tar conservan240archivos; cada positivo retiene88capturas, incluidas25
comparaciones,32CLI,30MCP y preparación. No síntesis o fase completa:
study sigue bloqueado por el indicador histórico rechazado; explain por
s_rows_pair sin enlace de inferencia/evidencia, además de fases previas.

D-106 descargó/preparó el Parquet público fijado y ejecutó una vez el
analizador original desde bytes verificados sobre un memfd sellado15.
Resultado exit0,stdout/report/histórico byteidénticos1599B:1.812.548filas,
3.512excluidas,1.809.036elegibles, numeradores1.725.248/1.682.386,
820snapshots y2.212estaciones. Entorno nuevo offline3.11/PyArrow21/tzdata2026.4:
1382archivos públicos de dependencias idénticos. Dos P2 del lanzador
se corrigieron antes de ejecutar; fuente inicial no ejecutada conservada.
Revisiones independientes recalculan archivos, cadenas, pares y salida;
ningún mismatch. D-106 verifica pertenencia a la máscara de estas filas,
sin autenticar verdad física, acceso vivido o efecto de campo; no adjunta
el resultado al ledger D-105 ni reescribe sus flags históricos.
Producción24/GOAL/matriz intactos, sin global nuevo, Q, generación experimental,
aprobación normativa, campo o corrida24. **Aceptación1/5; C2–C5 No demostrados.**
Luna nuevo no arrancó por límite de threads; revisión reutilizó agente
existente, sin atribuirle identidad de modelo no autenticada.
Siguiente: resolver explícitamente retiro de indicadores y soporte de síntesis,
ligar la repetición raw al grafo, y completar reserva/evaluación independiente,
baseline, autoridad y métricas competentes de campo.

**D-104 audita integridad de desarrollo:**
[dossier, planes congelados y resultados](../experiments/development/method_integrity_audit_2026-09-30/).
Banco original de 21 inyecciones pasa en Python 3.11/3.12 contra el mismo
wheel D-102, sin omisiones: 42 ledgers conservados y cadenas recalculadas
por revisor independiente. E06 sigue listo en study y bloqueado en specify.
Auditor instalado lee 15 objetivos bread64/Citi42: cuatro indicadores nuevos
del pan y el indicador de fracciones Citi no tienen evidencia con métrica y
unidad exactas; bundles genéricos son provisionales. Masa documental del pan
tiene una coincidencia exacta. Rutas estructurales, normas pendientes y
umbrales sin definir no acreditan resolución; cero fases aceptadas.
Tres programas originales D-099 se ejecutaron en copias con sólo el SHA
manifestado incorrecto: N/T fallan antes de agregados; S devuelve flag falso
y agregados. El contrato no exigía exit no cero; el comparador excluye los
tres de admisión decisoria, sin Q o superioridad causal. 147 originales
intactos; tres tar/265 archivos regulares y streams conservados.
Revisión previa cerró pines autopreferentes, import mutable del sandbox y
allowlist incompleta antes de ejecutar. Ruff/compile ambos Python pasan;
ningún nuevo global, modelo experimental, ensayo de campo o corrida24.
Producción/GOAL/matriz sin cambios: **aceptación 1/5; C2–C5 No demostrados**.
Siguiente: variante Citi con fracciones derivadas y controles de invalidación,
evidencia técnica de captura y preparación de evaluación independiente/campo.

**D-103 cierra el criterio 1 en alcance técnico:**
[dossier, inventario y revisión independiente](../experiments/development/installed_complete_interface_2026-09-30/).
Mismo wheel D-102 instalado fuera del árbol, Linux Python 3.11.15/3.12.3:
22/22 operaciones positivas CLI/MCP por entorno, 24 módulos iguales al
wheel y src, descubrimiento stdio real y efectos comprobados. Nueve fases
signed_observed conservan 51 eventos, ejecución/observación y repetición
real Landlock ABI 9. Dos agentes nativos guardan cuatro ítems únicos por
entorno; ambos casos signed siguen sin aprobaciones, reviews o avances.
Solapamiento inducido de 184922046/173400743 ns; cuatro pares de lectura
CLI/MCP sin mutar por entorno. Smokes actuales cubren SIGKILL, recuperación,
errores, persistencia y replay; todos los controles críticos inventariados
pasan en ambos. Ocho tar conservan 196 archivos y streams originales.

Los dos primeros capturadores fallaron tras tres tests passed por nodeid
abreviado; se conservan recibos fallidos y enmienda. Agregador inicial
fallido también conservado. Ruff/compile de scripts y pip check de 34
paquetes por entorno pasan; no nuevo global (D-102: 2560 es evidencia
anterior). GOAL/matriz no cambian. C1 no exige humanidad de claves o
comparación confirmatoria: esos pendientes conservan sus ámbitos.
**Aceptación actual: 1/5**, C2–C5 No demostrados. Claves sintéticas y mismo
UID no acreditan autoridad, Q o impacto; smoke de 15 operaciones es resumen
con código fijado, sin raw por llamada. Recibos antiguos 0/5 son históricos.
Sin nuevas comparaciones, campo o corrida de las 24. Siguiente: auditar
linaje de requisitos/indicadores y salidas de modelos conservadas; preparar
evaluación independiente y baseline/autoridad reales.

**D-102 añadió captura incremental y un borrador alimentario:**
[dossier y límites](../experiments/development/lot_journal_prospectus_2026-09-30/).
El auditor nativo CLI/MCP comprueba balances húmedos/secos declarados,
transferencias y agua/coproductos; datos secos faltantes siguen pendientes
y evaporación terminal no se reutiliza. No autentica fuentes o lotes.
El borrador nuevo contiene 64 puts, 54 consultas actor×dimensión, tres
alternativas sin ranking y cuatro obligaciones de ingeniería. Umbrales,
aprobaciones, baseline, consumo y efectos siguen pendientes. Repite D-100
17/7 y conserva dos desacuerdos; el ejemplo es aritmética sintética.
Un wheel instalado en Python 3.11/3.12 fuera del árbol descubre 22
herramientas, rechazan seis negativos por ambos transportes y cotejan nueve
gates/cuatro trazas; CLI aplica 64, MCP 0/64. Todas las fases sin aceptar.
Pasaron 2560 pruebas globales, Ruff, compilación y smoke instalado 3.11.
Las 118 focales nuevas pasan en 3.11; en Python 3.12 global hay 116 y dos
skips por dependencia MCP, cubierto por la sonda real instalada. El primer
global 2538/21 falló por pins históricos D-099: tests usan ahora una snapshot
verificada y prueban rechazo del árbol actual; broker/plan intactos.
270 protegidos idénticos y dos interfaces actualizadas deliberadamente;
outputs, casos, negativos y artefactos previos conservados. La preparación
de 64 puts no tiene el controlador estricto de D-101 y persiste carrera por
el mismo UID después del último pin. Sin nuevas llamadas experimentales,
Q, aprobación humana, campo o corrida de las 24. **Aceptación 0/5**.
Siguiente frente: baseline actual enlazado, autoridad/consentimiento del sitio
y definición competente de métricas, márgenes y protocolo antes de asignar.

**D-101 integró una receta alimentaria auditable:** [dossier y límites](../experiments/development/audited_bread_recipe_2026-09-30/).
Prepara copias, repite D-100 y publica 37 ítems pendientes ligados a 17
cantidades y siete filas archivadas. Memfd protege el manifiesto CLI; MCP
recibe raíz y objeto explícitos. El checkpoint exige proyecto `signed` y
prefijo exacto: no acepta reviews ajenos, versiones nuevas o falso éxito sin
ledger. Pasaron 50 pruebas en cada Python 3.11/3.12, Ruff y compilación.
Ambos paquetes instalados recuperan SIGKILL real tras 16 puts: MCP 21/16,
CLI 0/37, y dirección inversa sin duplicados. Dieciocho controles de archivos
y 39 pares de estado/compuerta/próxima tarea por entorno verifican
invalidación, rechazo sin escrituras y restitución exacta. La firma del probe
es sintética y externa al controlador; éste sólo publica puts sin avances.
Un cambio concurrente de fuente puede dejar eventos escritos y rechazados:
no es una transacción atómica; `put` directo elude el cotejo semántico.
Fuentes y ensayos anteriores intactos, D-097 fallido conservado; sin nuevas
generaciones, Q, aprobación humana o campo. **Aceptación 0/5**.
Siguiente frente: ampliar crítica/especificación e ingeniería con obligaciones
ligadas a valores y bloqueos explícitos, sin avanzar normas pendientes.

**D-100 cotejó fuentes alimentarias:** [auditor y límites](../experiments/development/bread_source_audit_2026-09-30/).
Un primitivo genérico nuevo extrae pasajes únicos de los mismos bytes PDF
verificados; el adaptador coteja 17 afirmaciones y siete filas de Tabla 1,
con valores extraídos y bases/procedencia de un contrato revisado por Codex.
Conserva dos desacuerdos de prosa frente a tablas, sin reconciliarlos.
La revisión detectó un falso positivo por extractor sustituido vía PATH;
ahora el binario está fijado por SHA y ejecutado desde memfd sellado,
con snapshot PDF y entorno limpio. Los positivos anteriores al arreglo
siguen conservados como anteriores. Pasaron 82 pruebas en Python 3.11/3.12,
Ruff y dos instalaciones offline del wheel final; el módulo vino de
site-packages y ambos resultados fueron byte idénticos, 17/7 y dos avisos.
Host/bibliotecas y contrato son límites explícitos, sin aprobación humana,
Q, nuevas generaciones, campo o corrida de las 24. **Aceptación 0/5**.
Su siguiente frente de integración se implementó en D-101 con el alcance
documental inicial descrito arriba, manteniendo D-097 intacto.

**D-099 completó una terna de desarrollo N/SDD/T:** [resultados y límites](../experiments/development/subscription_method_trial_2026-09-30/RESULTS.md).
Plan en `3ab2982`, broker y pruebas en `842d618`, antes de seis invocaciones
CLI con Luna medio solicitado. Cada brazo produjo código e informe, consumió
un único replay sellado y un segundo turno, y pasó 18/18 cotejos numéricos y
de formato. Tiempo activo local: N 66,305 s; S 68,574 s; T 76,085 s, dentro
de 360 s por brazo; preparación y revisión de seguridad excluidas.
T ejecutó 11 comandos reales y siete escrituras: `frame` listo sin aceptar,
`critique` con cuatro bloqueos; su evidencia carece de procedencia completa
y `specify` señala un bloqueo compuesto. No se reparó candidato, informe o
grafo. Los tres estados archivados se leen como `completed` y no permiten
relanzar. Revisor cotejó 147 originales byte idénticos, 12 marcadores vacíos
separados y 272 archivos protegidos intactos. El orden S/T/N se verificó
en registros locales y fue aplicado por el operador, sin garantía del broker.
Pasaron 35 pruebas en Python 3.11 y 3.12 y Ruff antes de las generaciones.
No Q, calidad equivalente, ganador, intervención o corrida de las 24;
el tratamiento T es inicial, con todas las fases sin aceptar. Identidad
efectiva, RPC, gasto y límites globales siguen sin autenticar. **0/5**.
El cotejo posterior de las 17 claims y siete filas alimentarias se registra
en D-100; D-097 sigue fallido e intacto. El panel confirmatorio y la autoridad
humana siguen pendientes.

**D-097 conservó un análisis nativo fallido:** el [workflow y plan](../experiments/development/bread_continuation_2026-09-30/)
se congelaron en `6a8018c` antes de una sola generación con Luna medio
solicitado. Produjo código, fuentes e informe de 780 palabras en 134,488 s
de supervisor dentro de 240 s, sin errores ni herramientas observadas.
La revisión previa consideró seguro el script para el sandbox, pero predijo
un fallo al exigir espacios distintos de los textos fijados. Su único replay
sellado confirmó código 2 y el error de Tabla 1, sin timeout ni métricas.
**No se midieron los 25 cotejos ni los 23 contratos**, y las tres variantes
negativas quedaron sin ejecutar. Se conservaron 27 archivos byte idénticos;
otro proceso y el revisor confirmaron `failed` y replay/relanzamiento
bloqueados. Uso local: 57.670 tokens de entrada y 7.206 de salida; los 443
de razonamiento son un desglose de salida. No hubo reparación, reemplazo,
fallback API, juicio Q o cambio del checkpoint D-096. Pasaron 53 pruebas
del workflow/evaluador con CLI falsa y sandbox local real. Este resultado
no demuestra calidad equivalente de Luna ni cuenta entre las 24 corridas;
los cinco criterios siguen **No demostrados**.

**D-098 corrigió la sonda documental del pan:** la [evidencia actual](../experiments/development/bread_legacy_probe_validation_2026-09-30.json)
registra 16 pruebas repetidas por un revisor, 21 herramientas descubiertas
y siete verificaciones CLI/MCP. Todas las operaciones usan una copia
temporal y conservan los nueve archivos originales. `frame` está listo,
pero su revisión histórica es `legacy_unverified`, sin aceptación o firma;
la próxima acción es `review_phase`. Ambos replays saltan 19 pasos, no
escriben eventos y se detienen por `independent_review_required`. No se
añadieron revisión firmada o aprobación humana, ni se reescribieron
informes históricos. Fix y evidencia en `c971090`; aceptación **0/5**.

**D-096 creó un checkpoint inicial real:** el [plan y código](../experiments/development/prototype_checkpoint_compatibility_2026-09-30/)
se congelaron en `aa3e533` antes de una sola llamada con Luna medio solicitado.
Con el host empaquetado de Code Mode habilitado, el error observado en
D-095 no apareció en esta traza. El prompt es byte idéntico; no se acredita igualdad
del contexto interno completo. La CLI terminó en 27,071 s y el supervisor
en 27,415 s dentro de 120 s. `init` real creó 18 nodos pendientes, dos normas,
cuatro fases sin empezar y un solo evento de inicialización; un proceso
nuevo verificó hashes y estado. Se conservaron 23 archivos idénticos y no
se permite relanzar. Uso local: 17.576 tokens de entrada y 1.298 de salida;
coste y versión efectiva sin autenticar. El parser ahora rechaza cualquier
error explícito `item.*`, incluido `item.updated`; pasaron 281 pruebas del
parser y 22 del supervisor, Ruff y compilación. La revisión cerró el falso
verde reproducido. Esto permite continuar desde un estado pendiente;
no evalúa calidad, no completa el caso alimentario ni cuenta entre las 24
corridas. Los cinco criterios siguen **No demostrados**.

**D-095 cerrado como desarrollo, con resultado negativo:** el puente managed
respeta el plazo del calendario; commit `ca22ea6`, 172 pruebas y revisión
independiente. El [supervisor y plan](../experiments/development/prototype_checkpoint_2026-09-30/)
se congelaron en `0631922` tras 17 pruebas con CLI falsa y correcciones
adversariales. La única tentativa real solicitó Luna medio/graph con 120 s:
terminó en 21,127 s y produjo 15 nodos pendientes, pero la CLI emitió un error
de arranque de Code Mode por deshabilitar su host. El supervisor rechazó la
traza antes de `init`; **no existe checkpoint**. Un proceso nuevo conserva
`failed` y bloquea relanzar. Se archivaron 17 archivos idénticos, sin reparación
ni reemplazo. Uso local: 17.576 tokens de entrada y 956 de salida; coste e
identidad efectiva sin autenticar. D-096 registra una configuración nueva
y conserva este negativo. No cuenta entre las 24 corridas; veredicto **0/5**.

**Corte actual:** 2026-09-30 UTC. Objetivo íntegro en [GOAL.md](../GOAL.md), SHA-256 `e8341bea380cc357ad9e02ec4689a4ed47fe198ba06e4c98639f29264c314c36`. Rama `work/toolkit-foundation`; GOAL.md y los cinco ledgers reales permanecen intactos. El [gate D-093](../experiments/development/local_evidence_gate_2026-09-30/receipt.json) pasó **2114 pruebas globales**, Ruff y compilación. Un wheel con el motor final pasó instalación offline, `uv pip check` y la sonda de evidencia por CLI y MCP reales en Python 3.11 y 3.12; la revisión independiente repitió ambas pruebas instaladas sin skips. El [dossier D-E congelado](../experiments/development/energy_pilot/activation_dossier_2026-09-27.json) conserva sus hashes históricos y su NO-GO para llamadas. La [auditoría de aceptación](validacion_actual.md) mantiene **0/5 criterios demostrados**.

El [corte D-086](../experiments/development/signed_observed_full_workflow_2026-09-28/) prueba `signed_observed` desde la creación de un caso sintético de nueve fases. Un wheel instalado sin red en Python 3.11.15 y 3.12.3 ejecutó CLI y cliente MCP stdio real; el auditor repitió `t1` en Landlock ABI 9 con entrada y ejecutable fijados, y el observador sintético registró por MCP la observación firmada. Ambos recibos muestran 29 ítems, 51 eventos, dos aprobaciones, nueve revisiones, reporte y observación de test, replay sin escritura y reapertura al alterar insumo o artefacto o revocar clave. El [test de wheel instalado](../tests/test_signed_full_workflow.py) pasó en modos legado y estricto; revisión independiente sin P1/P2 confirmado. El bundle temporal y las claves no tuvieron custodia separada, y el recibo no atestigua la ejecución histórica. Los cinco criterios siguen **No demostrados**.

El [corte D-087](../experiments/development/citibike_march_crash_recovery_2026-09-28/) enlaza la muestra pública de Citi Bike marzo con una interrupción real del proceso CLI instalado tras el evento 16. La cadena de hashes y un lector CLI nuevo conservaron el prefijo; MCP reanudó el manifiesto con seis escrituras y 16 saltos, y el reintento CLI no duplicó eventos. Una revisión firmada por actor sintético habilitó `frame`; `critique` permaneció bloqueada por `n_scope`. El ledger terminó con 24 eventos y los ledgers versionados no cambiaron. Se reprodujo en Python 3.11.15 y 3.12.3 y un revisor read-only no confirmó P1/P2. La sonda no prueba apagón, lectura nueva del Parquet, independencia humana ni una segunda reserva confirmatoria. Criterio 5 **No demostrado**; veredicto global **0/5**.

El [corte D-088](../experiments/development/model_scope_calibration_2026-09-28/) comparó tres respuestas nativas a una tarea cerrada de la muestra pública, con modelos y esfuerzos **solicitados** como Luna bajo, Luna alto y Sol medio. La tarea y el puntuador se fijaron en el commit `c523ee4` antes de las respuestas; las tres obtuvieron 14/14 y un control con dos errores inyectados obtuvo 12/14. Las propuestas de medición conservaron la distinción entre filas del feed e intentos de viaje. El techo de puntuación no permite ordenar calidad entre modelos o esfuerzos; la identidad efectiva del modelo, tokens, coste y tiempo no tienen recibo autenticado, ni hubo brazos metodológicos o aislamiento verificable. La cuota Codex no se pudo leer con fiabilidad. Criterio 4 **No demostrado**; veredicto global **0/5**.

El [corte D-089](../experiments/development/managed_response_budget_2026-09-28.json) introduce una [ruta de desarrollo](presupuesto_solicitudes_modelo.md) para una solicitud de texto por OpenAI Responses. Un subagente Luna identificó el punto de control ausente y construyó el ledger local compartido; el adaptador cuenta entrada, reserva entrada más techo de salida antes de enviar, persiste la respuesta y concilia el uso sin duplicar caché o razonamiento. Las 28 pruebas focales pasaron con proveedor falso y HTTP local, incluidos caída tras reserva y rechazo de redirección con clave; no hubo llamada ni gasto real. La CLI opaca D-E sigue fuera de este control, y faltan herramientas, costes, tiempo, custodia, modelos y casos confirmatorios. Criterio 4 **No demostrado**; veredicto global **0/5**.

El [corte D-090](presupuesto_solicitudes_modelo.md) añade una conversación secuencial de 2 a 32 turnos sobre ese adaptador, con un solo ledger y un plazo monotónico del proceso. Guarda plan, solicitudes, respuestas y recibos en una carpeta privada; reenvía el `output` completo para preservar razonamiento cifrado y `phase`, y bloquea reintentos de una corrida iniciada o truncada. Pasaron **37 pruebas focales y Ruff**: las nueve pruebas nuevas cubren dos turnos, parada por presupuesto, `incomplete`, salida sin texto, fallo de envío, plazo absorbido, muerte del proceso hijo y bytes alterados. El revisor independiente reprodujo y cerró dos defectos iniciales de uso detallado y tiempo. No hubo proveedor real. El plazo no agrupa agentes ni herramientas, y faltan techo de dólares, custodia externa, panel y casos reservados. Criterio 4 **No demostrado**; veredicto global **0/5**.

El [corte D-091](decisiones.md#d-091--reservar-coste-declarado-junto-a-los-tokens-antes-del-env%C3%ADo) amplía esa ruta con un ledger opcional de coste estimado en microUSD, perfil de tarifas declarado para un modelo exacto y reserva conjunta con tokens antes del envío. Las CLI pagas rechazan una corrida sin perfil y techo local. Un revisor independiente encontró que el cotejo de recibos permitía modificar `held_tokens`; ahora se coteja el registro completo, modelo, tier y desglose del uso. **61 pruebas focales** pasaron sobre el código final; un gate global previo al último refuerzo del cotejo pasó **2026 pruebas**. También se reprodujo una discrepancia entre conteo previo y uso posterior: el ledger bloquea siguientes envíos, pero un cargo ya realizado podría exceder el techo local. Ni tarifas, tier, factura ni gasto tienen custodia externa; no se llamó al proveedor. El runner D-E, las herramientas y los otros agentes quedan fuera; criterio 4 **No demostrado** y veredicto global **0/5**.

El [corte D-092](decisiones.md#d-092--unir-la-conversaci%C3%B3n-medida-con-una-herramienta-sellada) integra una corrida de desarrollo de dos turnos con una función estricta y una herramienta local sellada: calendario, `run_id`, modelo, argumentos, reserva, terminal y replay quedan ligados al ledger de tokens y coste declarado. El adaptador cuenta el esquema de función; la sesión entrega argumentos JSON al ejecutable y conserva su digest. La [evidencia offline](../experiments/development/managed_tool_conversation_2026-09-28.json) registra **167 pruebas focales combinadas, 2095 globales, Ruff y compilación** verdes. La revisión adversarial detectó decimales que podían cambiar de valor, estados o historiales falsamente completos y un esfuerzo discordante con el calendario; las pruebas negativas y el cotejo del historial corrigen esos falsos verdes locales. El transporte de prueba es falso y el sandbox ejecuta solo un script sintético. No hubo proveedor real ni se unieron agentes o brazos N/S/T bajo un límite global; el estado conserva `criterion_4:not_assessed` y el veredicto **0/5**.

El [control D-093](decisiones.md#d-093--comprobar-los-bytes-de-evidencia-local-en-las-compuertas) verifica en el motor los archivos declarados por evidencias `signed` con `archive`/`source_sha256`. Su ausencia, alteración o enlace inseguro invalida las dependencias y la revisión de fase; dos digests incompatibles para la misma ruta se rechazan antes de leer. La [sonda instalada](../scripts/probe_local_evidence_gate.py), sobre copias temporales de los dos PDF del pan, pasó en Python 3.11.15 y 3.12.3 con CLI y MCP stdio reales: ocho evidencias y diez dependientes quedaron bloqueados al alterar, borrar o enlazar uno de los PDF; `advance` y `run` no escribieron, y restaurar los bytes recuperó la aceptación. Pasaron **17 pruebas focales, 2 instaladas y 2114 globales**, Ruff y compilación. Los [recibos](../experiments/development/local_evidence_gate_2026-09-30/receipt.json) conservan hashes, controles y límites. Las claves son sintéticas y el cotejo no evalúa el contenido de los documentos ni su custodia; criterios 1 y 2 **No demostrados**, veredicto global **0/5**.

El [ensayo D-094](../experiments/development/bread_prototype_feasibility_2026-09-30/) congeló un paquete alimentario público antes de tres intentos nativos A/B/C con configuración heredada común. Los tres fueron interrumpidos sin entrega terminal tras superar el plazo solicitado según el operador; se conservan once archivos originales. B dejó siete entregables y seis comandos reales; A/C, solo script y métricas. Los tres cálculos se repitieron con `pdftotext` en entorno limpio y concuerdan en 25/25 cotejos por intento; el sandbox rechazó los tres por impedir subprocesos. En B, filosofía se bloqueó por `N-consent` y la norma sigue vinculada al requisito; ingeniería se rechazó por fases previas, sin aislar la causa normativa. La revisión independiente corrigió esa sobreafirmación del inspector. No hay Q, ganador, tokens/coste medidos ni límite global aplicado; no cuentan entre las 24 corridas. Criterio 4 **No demostrado**; veredicto global **0/5**.

El [corte D-085](../experiments/development/signed_observed_test_gate_2026-09-27.json) añade `signed_observed` para casos nuevos. Requiere pin previo de ejecutable/entrada, reporte firmado, repetición local y recibo firmado por `observer:*` distinto de todos los autores del test; el replay verifica firma y bytes actuales del bundle y reabre la compuerta al cambiar reporte, entrada, artefacto o confianza. El runner pide `observe_test` también después de una observación negativa. Una prueba integrada usó sandbox real; **52 focales, 1963 globales en 182,80 s, Ruff y wheel instalado sin red en Python 3.11/3.12** pasaron, con 21 herramientas MCP descubiertas. La revisión adversarial halló y cerró tres fallos de autoría y recuperación. El modo legado conserva su huella; firmas y bundles sintéticos no prueban ejecución histórica, independencia personal ni custodia externa. Criterio 1 **No demostrado**; veredicto global **0/5**.

El [corte D-084](../experiments/development/citibike_march_challenge_2026-09-27.json) ejercita en una copia temporal del caso publicado Citi Bike marzo una impugnación manual del denominador bruto 1.812.548 frente al elegible 1.809.036 tras 3.512 exclusiones. La CLI instalada bloquea inferencia, indicador y requisito candidatos, exige síntesis posterior y revisión de ítem por actor distinto, y reabre la impugnación cuando se revisa `e_eligible` sobre los mismos bytes de fuente. El [ledger derivado](../experiments/development/citibike_march_challenge_case/README.md) conserva los 24 eventos históricos y once nuevos. Pasaron **1937 pruebas globales en 159,67 s y Ruff**; la revisión adversarial no halló falso verde en la sonda. La aritmética se coteja explícitamente contra el resultado fijado: el motor no detecta por sí solo el significado equivocado del denominador. Los tres actores son etiquetas emitidas por un script; no hay revisión humana independiente, caso reservado, intervención ni aprobación de la norma. Criterio 5 **No demostrado**; veredicto global **0/5**.

El [corte D-080](../experiments/development/local_active_run_budget_2026-09-27.json) aplica al runner D-E un plazo monotónico local de 1–5400 segundos por invocación, compartido por preparación T, CLI y consulta posterior T. Al agotarse conserva capturas parciales y deja `run_time_budget_exhausted`; el observador coteja sus bytes y que la suma de duraciones declaradas no supere el tiempo declarado de la corrida. Una revisión adversarial corrigió además el envío de `SIGKILL` después de recolectar al líder del grupo y el falso verde de tiempo total menor que las capturas. Pasaron **253 pruebas focales, 1886 globales y Ruff**. Otra falsificación coherente de `run.json` sigue pudiendo presentar como listo un agotamiento posterior a la CLI, pues ese intervalo no tiene captura custodiada; tampoco se autentican reloj o proveedor. El plazo no demuestra igualdad de presupuesto entre N/S/T, límite de tokens/herramientas, pausa humana ni reintentos. **0/5 criterios demostrados**.

El [corte D-081](../experiments/development/pilot_triplet_budget_binding_2026-09-27.json) exige que un plan piloto **nuevo de esquema 2** fije un único `active_budget_seconds` local para N/S/T antes de buscar la CLI o crear la corrida. La [plantilla v2](../experiments/development/energy_pilot/pilot_triplet_plan_template_v2.json) conserva `null` y NO-GO; el dossier y la plantilla v1 siguen intactos. El observador coteja plan copiado, binding y registro de tiempo. La revisión independiente halló primero que el cambio bloqueaba el replay de pilotos v1 históricos; se corrigió y reprodujo su observación y replay con y sin metadatos D-080. Pasaron **268 pruebas focales, 1901 globales y Ruff** con CLI falsas. El límite iguala una cifra **solicitada** bajo control local, sin autenticar cronología, proveedor o presupuesto efectivo; `cap_status:unknown`, `controlled_comparison_eligible:false` y **0/5 criterios demostrados**.

El [corte D-082](../experiments/development/local_signed_test_repeat_2026-09-27.json) añade una auditoría optativa de **repetición actual** de un test `signed`: ejecutable fijado por hash y sellado, sandbox local, hashes de stdout/stderr y artefactos declarados abiertos sin seguir enlaces. Un reporte firmado con hashes inventados que el motor aceptaba queda rechazado por esa repetición local. La revisión independiente no halló un falso verde en el alcance y verificó el rechazo de enlaces simbólicos en ancestros. El gate histórico no cambia: la repetición no autentica la ejecución pasada ni custodia externa y `argv[0]` llega al hijo como ruta `procfd`. Criterio 1 **No demostrado**.

El [corte D-083](../experiments/development/development_six_cell_local_audit_2026-09-27.json) concilia hasta seis carpetas D-E contra un mismo plan local y señala celdas faltantes o repetidas, archivos incompatibles, uso ausente y fallos conservados. Una prueba integrada con seis CLI falsas llega a `six_cell_recorded_local_completion:true` mediante el observador real. El ledger T de esa prueba solo **declara** política `signed` y eventos sintéticos; el informe explicita `signed_toolkit_workflow_verified:false`, `controlled_comparison_eligible:false` y criterio 4 `not_assessed`. La revisión independiente detectó primero que el positivo era solo un stub; la integración real y la limitación de firmas se añadieron y verificaron. **0/5 criterios demostrados**.

El corte [D-078](../experiments/development/signed_test_execution_2026-09-27.json) exige para todo test `signed` un `argv` explícito y el último reporte de ejecución Ed25519 válido de un actor `executor:*` registrado. Un `passed:true` declarado ya no habilita `build` ni un veredicto decisivo; un fallo firmado posterior bloquea, y revocar la clave reabre `build` y fases dependientes sin reescribir el ledger. La sonda de nueve fases deriva una copia temporal del manifiesto original, ejecuta `t1` con un wheel instalado, coteja salida y artefacto, compara los desafíos CLI/MCP y registra el reporte por CLI. El gate global pasó **1872 pruebas** y Ruff; un wheel SHA-256 `97b22b717c59a8332307f4993229e13c741f40d8304ecd8480bf0887d7107d80` se instaló offline en Python 3.11.15 y 3.12.3. En ambos pasaron `uv pip check`, la sonda firmada con CLI y MCP stdio y el smoke de nueve fases, 19 herramientas descubiertas y 15 operaciones comparadas. La revisión adversarial de las rutas públicas no encontró bypass P1/P2 en este alcance. El motor verifica **la declaración firmada**, sin observar el proceso ni cotejar los bytes reportados; las claves, actores y el comando de la sonda son sintéticos. No hay custodia externa ni juicio humano, comparación confirmatoria o impacto de campo. Veredicto GOAL: **0/5 demostrados**.

El [inventario D-079](../experiments/development/installed_public_interface_inventory_2026-09-27.json) completó la invocación de las **19/19 operaciones públicas** por CLI instalada y cliente MCP stdio real en los mismos entornos Python 3.11.15 y 3.12.3 del wheel D-078. El smoke verificó 15 operaciones en cada transporte; pruebas adicionales ejercieron las cuatro rutas de atestación de campo y de reporte de test firmado, incluidas escrituras válidas y sus efectos. El test de ejecución lanzó un comando sintético y cotejó streams y artefacto antes de enviar dos reportes firmados. El gate global pasó **1873 pruebas**, Ruff y `git diff --check`. Las salidas se generaron en directorios temporales y el recibo conserva hashes y resultados; no autentica claves o datos fuera del ensayo. La cobertura técnica aumenta, pero un caso real completo, revisión humana, coordinación confirmatoria e impacto siguen pendientes; **0/5 criterios demostrados**.

La compuerta nueva de revisión de fase `signed` exige una firma Ed25519 verificable sobre el snapshot vigente, vinculada a la clave pública del revisor en el registro externo y a un actor distinto de los autores de la fase. CLI y MCP exponen `phase-review-challenge`; el replay vuelve a verificar la firma con la confianza actual. Los eventos anteriores sin firma siguen visibles, pero los cinco ledgers reales versionados que contienen revisión de `frame` informan ahora `legacy_unverified` y `frame.accepted=false`, sin modificar sus bytes. El [corte D-072](../experiments/development/signed_phase_review_2026-09-27.json) pasó **1806 pruebas**, Ruff y `git diff --check`; el wheel nuevo SHA-256 `94762482eb54c4d42b41a712103bdb97df5a856c87d601e025f8c2c9746d2509` pasó instalación offline, `uv pip check`, smoke CLI/MCP y la sonda decisiva en Python 3.11.15 y 3.12.3. Registrar una clave pública no acredita identidad, competencia, independencia personal ni la calidad de la revisión. La [distancia a la meta](activacion_validacion.md) incluye esa puerta de custodia; no cambia ningún veredicto.

La [integración D-073](../experiments/development/signed_full_workflow_2026-09-27.json) construyó un wheel temporal SHA-256 `c0b08ccff88367f7e086af2c3177eb9b43aedbd21eb5923f347ad97dbc8cb8eb`, lo instaló sin red en Python 3.11.15 y 3.12.3 y pasó `uv pip check` en ambos. En cada entorno, una sonda con CLI instalada y cliente MCP stdio real recorrió las nueve fases de `synthetic_full.json` bajo política `signed`: 29 artefactos, dos aprobaciones y nueve revisiones firmadas, 49 eventos, replay sin escritura y reapertura al retirar la clave del revisor. El test focal pasó incluso con variables exteriores `ORGANON_ALLOW_FIXTURES` y `PYTHONPATH`; la sonda aísla el entorno de los subprocesos. El gate global pasó **1807 pruebas** y Ruff. El recibo fija hashes del wheel, script, test y manifiesto, pero resume un ledger temporal eliminado y no es una atestación criptográfica independiente. No hubo evaluador humano ni ejecución autenticada del comando inventado en `t1`; `ass1` mantiene `field/no_demostrado`. Los cinco criterios de GOAL siguen **No demostrados**.

El corte [D-074](../experiments/development/pilot_triplet_binding_2026-09-27.json) / [D-075](../experiments/development/field_denominator_reconciliation_2026-09-27.json) añadió un plan lateral NO-GO para vincular la configuración local de las tripletas N/S/T y `service.schema:3` para reconciliar el techo aditivo declarado con cada entrada externa y sus extractos abiertos. Dos revisiones adversariales independientes encontraron una carrera del wheel T, corregida antes del proveedor, y el límite de cronología de un vínculo local, ahora informado como `prelaunch_binding_authenticated:false`; no hallaron aprobación falsa de los criterios 3 o 4. Pasaron **1847 pruebas globales**, 240 focales del piloto, 229 focales de campo, Ruff y `git diff --check`. Un wheel nuevo SHA-256 `eb528cf5cce822d25927580e5669bc79288cb9a4d6cd31a3e24263f65245a75b` se instaló sin red en Python 3.11.15 y 3.12.3; `uv pip check`, importación de los módulos de campo desde `site-packages` y ayuda de CLI pasaron. Este wheel temporal no sustituye el activo T congelado del dossier previo. No hubo llamadas nuevas a modelos ni ensayo alimentario; los cinco criterios siguen **No demostrados**.

El [control D-076](../experiments/development/signed_review_dependency_2026-09-27.json) cierra dos falsos verdes del replay `signed`: un autor anterior no puede revisar su fase después de una republicación idéntica por otro actor, y una nueva aprobación válida de una norma cambia el snapshot que debe revisar y avanzar la fase dependiente. Los controles comprueban que una aprobación posterior inválida y otra ajena a la fase no causen invalidación espuria. La revisión independiente no encontró otro bypass en ese alcance; firmas, actores y claves de prueba son sintéticos, sin custodia de identidad o juicio humano. Criterio 2 **No demostrado**.

El [auditor D-077](../experiments/development/citibike_march_ratio_audit_2026-09-27.json) aplica un contrato de métricas retrospectivo a los conteos publicados de Citi Bike marzo: `1.725.248/1.809.036` para alquiler habilitado y `1.682.386/1.809.036` para devolución habilitada, como fracciones de **filas estación-instantánea elegibles**. Rechaza reetiquetar la afirmación como estación-minutos o junio de 2026 frente al contrato fijado. Si el mismo operador reescribe también el contrato y su pin, la etiqueta falsa puede pasar: falta custodia externa previa. El JSON auditado no prueba semántica ni pertenencia fila por fila del Parquet. No se consumió un caso reservado ni se midió impacto; criterio 5 **No demostrado**.

El [gate integrado del corte D-077](../experiments/development/signed_ratio_integration_gate_2026-09-27.json) pasó **1867 pruebas**, Ruff y la instalación sin red del wheel en Python 3.11.15 y 3.12.3; `uv pip check` verificó 29 paquetes en cada entorno. Desde `site-packages`, ambos calcularon las dos fracciones exactas y rechazaron un pin contractual errado con salida 2. Una revisión adversarial reprodujo y luego cerró la lectura no acotada de la CLI con una fuente dispersa de 64 MiB. En aquel corte, el test de nueve fases firmado aún tomaba `t1.passed:true` de una fixture sin ejecutar su comando; D-078 cerró esa brecha local. Ninguna de estas pruebas acredita impacto real ni cambia el veredicto **0/5**.

La [distancia a la meta y las puertas de activación](activacion_validacion.md) resumen por qué los cinco criterios siguen sin demostrarse y qué evidencias y decisiones externas requieren el ensayo alimentario y la comparación de modelos. El preflight del diseño alimentario ahora rechaza celdas brazo × estrato con un único grupo, que el candidato ajustado no puede remuestrear. Este mínimo estructural no resuelve la discrepancia entre el evento de potencia y el umbral de éxito, ni autentica datos o autoriza asignar grupos.

## Candidato ajustado implementado en desarrollo

El [análisis alimentario de esquema 2](preparacion_campo.md#aritmética-declarada-y-candidato-ajustado) recalcula un candidato ajustado de `G` con especificación y volumen basal declarados, un grupo por fila, efectos fijos de estrato, log volumen centrado y bootstrap por grupo dentro de brazo y estrato. Para una atestación nueva con `analysis.schema:2`, cada fila de volumen basal exige un extracto `volume_row` en bytes abiertos de rol `source_record`, cotejado por digest y locator con valor, unidad, ventana, fecha, método, estudio y definición exactos. El cálculo aislado continúa siendo declarativo. `field.service.schema:2` liga por separado las cifras de servicio a extractos abiertos y es independiente del esquema del análisis; los esquemas anteriores siguen disponibles. En su corte anterior, este control pasó **1625 pruebas y 1 fallo esperado estricto**. El intervalo es nominal, sin calibración para el sitio; el cotejo de bytes no prueba verdad ni custodia física, y no hay sitio, potencia aprobada, verificación de asignación ni datos de intervención. `decision_ready:false` y criterio 3 **no demostrado**.

## Implementado y verificado

- El [gate de evidencia decisiva](../experiments/development/decisive_indicator_measurement_2026-09-27.json) rechaza un `cumplido/incumplido` simulado que use una fuente de temperatura sin métrica para justificar masa desperdiciada. Cada indicador decisivo requiere evidencia vigente y protocolizada con métrica, unidad, valor y alcance; evidencia `observed` exige método textual no vacío. La provisionalidad temprana y `no_demostrado` se conservan. Pasaron 154 pruebas focales y revisión independiente; las fuentes siguen sin autenticación externa. Criterios 2 y 3 **no demostrados**.
- La [derivación de Citi Bike marzo](../cases/citibike_march2024_lineage/README.md) conserva los 24 eventos originales y añade dependencias explícitas a `i_rows`, un requisito candidato, invalidación tras cambiar el denominador elegible y reparación append-only hasta 42 eventos. Usa CLI instalada y MCP stdio real; la cifra falsa de 1.812.548 elegibles se rechaza frente al JSON publicado con 1.809.036. El [recibo](../experiments/development/citibike_march_indicator_lineage_2026-09-27.json), 11 pruebas y revisión adversarial verifican los límites: sin nuevo recálculo de Parquet, aprobación normativa, intervención ni efecto. Criterio 5 **no demostrado**.
- El [cotejo de identidad local Agy](../experiments/development/agy_conversation_identity_2026-09-27.json) rechaza un `init`/`result` con IDs de conversación distintos y falla cerrado ante un evento desconocido que antes podía ocultar un ID contradictorio. El observador relee la traza y expone solo el estado saneado; sin IDs históricos informa `local_identity_unverified`. Pasaron 180 pruebas focales, Ruff y revisión adversarial. No acredita identidad del proveedor ni comparación confirmatoria; criterio 4 **no demostrado**.
- El [parser estricto de telemetría JSONL](../experiments/development/strict_cli_usage_jsonl_2026-09-27.json) cierra un falso verde del runner Codex/Agy: `input_tokens` duplicado con 90 000 y luego 20 se interpretaba como 20, éxito y uso completo. El runner y el observador ahora rechazan claves duplicadas, números no finitos y UTF-8 inválido con error de línea; 155 pruebas focales, Ruff y una revisión independiente pasaron. Las trazas son locales y sintéticas, sin recibos de proveedor ni ensayo N/SDD/toolkit; criterio 4 **no demostrado**.
- El [recálculo de Citi Bike de marzo desde Parquet público](../experiments/development/citibike_march_source_recalculation_2026-09-27.json) recuperó los bytes del commit fijado, confirmó tamaño, SHA-256 y paridad con la copia temporal previa, y regeneró un JSON idéntico byte a byte al archivado en Python 3.11.15 con `pyarrow==21.0.0` y `tzdata==2026.4`. Un archivo alterado se rechazó con código 2. Es reproducibilidad de muestra histórica, no acceso observado ni efecto de intervención; criterio 5 **no demostrado**.
- El [cotejo documental de las nueve evidencias de pan](../experiments/development/bread_pdf_content_binding_2026-09-27.json) abre los dos PDF fijados y extrae las cifras de pasajes o tablas con Poppler. Liga valores, texto visible y procedencia al manifiesto y ledger; rechaza una merma comercial falsa de 99 % aunque la cadena de hashes siga válida, una falsa observación doméstica directa y metadatos añadidos que afirman vínculo por lote. La revisión independiente reprodujo los falsos verdes iniciales y los rechazos finales. Es un contrato de este expediente, dependiente de `pdftotext`, sin microdatos enlazados ni efecto causal; criterio 3 **no demostrado**.
- El [control de escritura MCP con Landlock](../experiments/development/mcp_landlock_root_write_2026-09-27.json) exige ABI 5 o superior al arrancar con `ORGANON_ROOT` explícito y falla cerrado si no puede instalar la regla. Un cliente stdio real ejecutó `init`, `put`, `run` y `status` dentro de la raíz; tras mover el caso fijado fuera de ella, el siguiente `put` falló sin cambiar el ledger externo. Los descriptores ya abiertos, el movimiento de la raíz, enlaces físicos internos y procesos pares del mismo UID siguen fuera de una garantía absoluta. Criterio 1 **no demostrado**.
- El [replay de Citi Bike de marzo](../experiments/development/citibike_march_workflow_replay_2026-09-27.json) aplicó por CLI 22 ítems del caso real, esperó revisión en `frame`, reanudó el avance mediante cliente MCP stdio y reintentó por CLI sin duplicados. La compuerta `critique` se detuvo ante `n_scope` sin aprobación. Se repitió desde ruedas instaladas sin red en Python 3.11.15 y 3.12.3. La revisión solo separa etiquetas de actor, no evalúa sustantivamente el caso; el Parquet original no se reanalizó en este probe. Criterio 5 **no demostrado**.
- El [control placebo escolar](sensibilidad_temporal_escuela.md#cortes-placebo-dentro-de-la-línea-base) compara cada par de ventanas contiguas de 20 jornadas dentro de la línea base del XLSX público fijado. Hay 96 cortes candidatos; 18 se excluyen por KSW ausente y 78 conservan PW, KSW y total con iguales días y denominadores. Nueve muestran una caída de total al menos tan grande como los −10,841032 g/comensal del período final frente a la última ventana basal; ocho de los nueve cortes son consecutivos y muy solapados. El [JSON](../experiments/development/school_placebo_cutoffs_2026-09-27.json) es reproducible byte por byte; una revisión independiente recalculó masas, denominadores, tasas y diferencias directamente del XLSX. Pasaron 29 pruebas focales, Ruff y 1512 pruebas globales con 1 xfail estricto. El recuento es descriptivo y posterior a la observación, sin valor p ni atribución causal; criterio 3 **no demostrado**.
- El [piloto textual de diseño alimentario](../experiments/development/school_design_text_pilot_2026-09-27/v2/findings.md) archivó nueve respuestas reales de dos familias de modelos, dos fichas por respuesta, hashes, mapa revelado después de las fichas y un analizador reproducible. Ocho textos cumplen el formato, con cuatro pares A-M frente a N/S: Gemini Low `+7/+8,5` y MiniMax M3 `+9,5/−4` puntos. Se conserva un rechazo de ruta anterior a v2: la sustitución posterior violó el plan original, aunque ocurrió antes de ver respuestas sustantivas. Un texto de 917 palabras contables superó el límite de 900 y fue puntuado fuera del procedimiento; esas notas son suplementarias y se excluyen de los pares. A-M instruye el método manualmente, sin ejecutar el toolkit; no hay telemetría de tokens/coste ni prueba confirmatoria del criterio 4.
- El [expediente de pan noruego](../cases/bread_norway/README.md) revisa una cadena publicada con cultivo, almacenamiento, transporte, molienda, panificación, comercio y consumo. Su [auditoría](../cases/bread_norway/source_audit.md) distingue datos empresariales y encuesta de supuestos del ACV. El [manifiesto documental](../cases/bread_norway/frame_manifest.json) produjo 19 ítems, una revisión histórica de `frame` sin firma y un avance; la [sonda histórica](../experiments/development/bread_frame_cli_mcp_2026-09-27.json) cotejó CLI/MCP, fuentes archivadas y replay sin duplicados. La fase queda abierta al releer con el gate actual y la norma propuesta sigue sin aprobación humana. Las tablas no enlazan lotes hasta hogares ni prueban mejora de campo; criterio 3 **no demostrado**.
- El [contrato de resultados de campo](../experiments/development/field_success_structure_2026-09-27.json) exige registros estructurados de daños y costos para aceptar `cumplido/field`; la revisión adversarial descartó un filtro de frases por evasiones y falsos bloqueos. Una medición numérica declarada como cero pasa, mientras prosa libre, estados no medidos y registros incompletos bloquean. Los ledgers antiguos con éxito de campo en prosa siguen legibles pero podrían perder aceptación hasta revisar una nueva versión; no hay tal éxito entre los casos versionados. El gate no autentica fuentes, cobertura ni ausencia de perjuicios.
- El [cotejo de hashes primarios de campo](../experiments/development/field_primary_source_coverage_2026-09-27.json) exige coincidencia exacta entre referencias y archivos abiertos por rol antes del desafío de firma. La prueba sintética vincula 722 referencias a dos archivos agregados; otra prueba acepta 720 fuentes individuales en un manifiesto de 727 entradas. Pasaron 18 pruebas focales y Ruff. El [wheel de esta pieza](../experiments/development/field_source_wheel_2026-09-27.json) se instaló sin red en Python 3.11.15 y 3.12.3, con `uv pip check` verde y el módulo importable. La revisión independiente reprodujo que dos archivos `{}` con hashes rehechos satisfacían el cotejo de hashes. El [cotejo posterior de extractos](../experiments/development/field_source_content_match_2026-09-27.json) cerró ese falso verde declarativo: 32 pruebas focales pasaron y el `{}` rehecho se rechaza antes de firmar. Los extractos pueden seguir siendo inventados; autoridad, custodia y verdad de la medida no se comprueban. El gate decisivo de campo permanece bloqueado.
- La [sonda local del brazo T instalado](../experiments/development/installed_t_runner_probe_2026-09-27.json) hizo llamadas reales al CLI y MCP del wheel dentro del runner y comprobó ledger, observador y replay; un modelo ficticio copió un ledger válido sin invocar Organon y reprodujo un falso estado listo. El runner T exige ahora una traza `strace` de ejecuciones y publicaciones del ledger del caso, y el observador y replay la vuelven a cotejar. La revisión independiente rechazó también intercambio de directorio, `unlink`/`link` y `renameat` con descriptores tras publicaciones genuinas. El positivo quedó listo para inspección. Esta traza local no autentica al proveedor ni ejecuta la comparación N/S/T; criterio 4 **no demostrado**.
- El [filtro de bytes MCP](../experiments/development/mcp_strict_wire_2026-09-27.json) cierra en el servidor local la aceptación de claves JSON duplicadas antes del parser del SDK, la conversión de booleanos a versiones, las cadenas reinterpretadas como objetos, los sobres de solicitud con campos de respuesta y la sustitución de UTF-8 inválido. Drena líneas mayores de 8 MiB sin ejecutar herramientas. Los negativos por wire dejan el ledger intacto y luego pasa una solicitud válida; el wheel instalado offline mantuvo paridad CLI/MCP en Python 3.11 y 3.12. Las funciones privadas del SDK exigen el pin `mcp==2.2.0`; la frontera no autentica cliente ni fuente. Criterios 1 y 2 **no demostrados**.
- El [inspector del wheel](../experiments/development/wheel_pin_alignment_2026-09-27.json) exige ahora el mismo `mcp==2.2.0` que `pyproject.toml`. Un gate inicial encontró un fallo real: el inspector todavía esperaba el rango antiguo y rechazaba el wheel reconstruido. Tras alinear inspector, fixture y control negativo, el wheel local pasó la inspección estática, 60 pruebas focales y el gate global de 1333 pruebas más un xfail estricto. La inspección no instala ni ejecuta ese wheel; `execution_ready: false` se mantiene.
- El [cotejo local de fuentes secundarias](../experiments/development/secondary_source_bytes_2026-09-27.json) abre los blobs de referencia, auditoría, inyección, eventos humanos y pared, factura y tarifa que las filas medidas citan. Recalcula cada cargo de modelo desde tokens, tarifas decimales y `request_id` de todos los intentos; una factura rehasheada con importe falso falla, al igual que un reintento facturado sin línea propia. Referencias, auditorías y eventos no se interpretan; los ceros declarados de herramientas y personas no prueban ausencia de gasto, ni hay autenticación de proveedor, factura, tarifa o custodia. Criterio 4 **no demostrado**.
- El [cotejo local de bytes de preparación ciega](../experiments/development/preparation_byte_replay_2026-09-27.json) abre blobs nombrados por digest para artefacto/traza terminal, paquete/traza cegados, fuentes, salidas de prueba y un perfil declarativo fijo; reproduce la receta de spans y compara ambos resultados byte por byte. El cotejo estructural de actas y la cronología declarada siguen siendo precondición. La búsqueda de IDs literales y las pruebas sintéticas no autentican el programa transformador original, la ausencia de pistas semánticas, el cierre real de juicios ni custodia independiente. Criterio 4 **no demostrado**.
- El [control local de reintentos por caída externa](../experiments/development/local_external_failure_retry_2026-09-27.json) extiende gate, release, stage, admisión y ejecutores al intento numerado. Un reintento solo se reclama tras el terminal `external_failure` publicado del anterior, consume uno de diez cupos del calendario candidato y conserva rutas y manifiestos separados. El brazo siguiente espera un resultado utilizable o truncado del último intento; un bloque sin reintento disponible se cierra explícitamente y sus brazos pendientes quedan faltantes. Una revisión independiente encontró dos falsos verdes iniciales —manifiesto de intento 1 aceptado como 2 y cuatro bloques sin salida— que motivaron correcciones. El [cierre posterior D-056](../experiments/development/local_gate_receipt_boundary_2026-09-27.json) hace que los stages nuevos con gate, incluido el intento 1, guarden procedencia de esquema 2 y retengan el gate hasta el recibo local sincronizado. El stage histórico de esquema 1 carece de esa procedencia y no retiene el gate al ejecutar. Sigue siendo coordinación de desarrollo del mismo UID y host: incidente, trazas, artefactos, criterio de parada y uso de proveedor no están autenticados. Criterio 4 **no demostrado**.
- El [rechazo de claves JSON duplicadas](../experiments/development/duplicate_json_boundary_2026-09-27.json) cerró en D-054 una ambigüedad de CLI y ledger: `put --data` aceptaba dos valores para el mismo umbral y escribía el último; una clave oculta antes de la original en un evento podía conservar el hash calculado tras parsear. La CLI, el ledger y el registro de aprobadores pasaron **1215 pruebas y 1 xfail estricto** en ese corte. La revisión independiente descubrió entonces que el SDK MCP aceptaba duplicados en JSON-RPC crudo; el filtro D-059 descrito arriba cubre hoy esa frontera local. Ninguno de ambos controles autentica origen de datos; criterios 1 y 2 siguen **no demostrados**.
- La [compuerta local de liberación por bloques](../experiments/development/local_block_release_gate_2026-09-27.json) registró en D-053 `claim → published → terminal` bajo una raíz privada compartida por procesos cooperantes del mismo UID y host. En ese corte, el preflight reclamaba solo el intento 1; cada brazo posterior esperaba un terminal `completed` o `truncated`, con un máximo de cuatro bloques abiertos y cuatro corridas activas. La revisión independiente reprodujo y cerró falsos verdes de orden, cupos, publicación residual, terminal parcial y mutación del calendario. Pasaron **1209 pruebas y 1 xfail estricto** en ese corte. D-055 extiende la secuencia a reintentos elegibles; la raíz, los terminales y los digests siguen siendo declaraciones locales sin custodia ni proveedor autenticado. No se ejecutó la matriz confirmatoria; criterio 4 sigue **no demostrado**.
- El [control anterior de rutas MCP](../experiments/development/mcp_case_path_hardening_2026-09-27.json) bloqueó enlaces simbólicos externos de ledger y lock, fijó raíz y caso mediante descriptores y exigió archivos regulares sin enlaces físicos adicionales. En aquel corte pasaron **1180 pruebas** y un fallo esperado estricto reprodujo la escritura tras mover el caso ya fijado fuera de la raíz. El [control Landlock actual](../experiments/development/mcp_landlock_root_write_2026-09-27.json) cierra ese contraejemplo para el proceso MCP con `ORGANON_ROOT` explícito; no resuelve todos los cambios concurrentes de raíz o enlaces físicos por un escritor del mismo UID. Criterio 1 sigue **no demostrado**.
- La [admisión local compartida](../experiments/development/local_run_admission_2026-09-27.json) cerró en D-051 el reinicio del cupo de desarrollo al copiar un stage: sesión y ejecutor único competían por un reclamo durable del intento 1, ligado al SHA-256 del calendario y `run_id` verificados. `init` dejaba el intento libre; la primera llamada válida lo reclamaba antes de reservar, y un dueño distinto quedaba bloqueado sin lanzar. Se ensayaron copias, modalidades, concurrencia de dos procesos CLI, caída y errores de `fsync`; pasaron 57 pruebas focales y 1165 globales en ese corte. D-055 añade una clave distinta por reintento elegible. Solo cooperan los procesos del mismo UID, host y raíz; no hay telemetría de proveedor, límite real de tokens/coste ni custodia externa. `global_run_limits_enforced: false` y criterio 4 `not_assessed` se conservan.
- La [sesión local de herramientas consecutivas](../experiments/development/staged_tool_session_2026-09-27.json) ejecutó dos scripts sintéticos sellados en procesos reales, conservó un intermediario en `work/` y agotó el cupo local antes de una tercera llamada. Reserva cada llamada en un journal durable y bloquea un efecto incierto en vez de repetirlo. La revisión independiente reprodujo un recibo incoherente, una reserva sin terminal, una ancla escrita a medias, dos inicializaciones concurrentes y llamadas antes de `fsync` o después del plazo; las correcciones quedaron verdes en 61 pruebas focales y **1148 globales**. En ese corte, una segunda copia del mismo release en otra ruta conservaba otro cupo; el recibo declaraba `global_run_limits_enforced: false`. No había registro común, proveedor, tokens, coste, runtime verificado ni custodia externa; criterio 4 `not_assessed`.
- El [control exacto de métricas y reintentos de fase](../experiments/development/engine_exact_gate_retry_2026-09-27.json) cierra falsos verdes con enteros contiguos sobre `2**53` y productos redondeados, y evita que un reenvío idéntico de revisión o avance duplique eventos. Limita exponentes y tamaños antes de construir fracciones; conserva el rango publicado `3-6` de mango y compara rangos declarados contra escalares de la misma unidad, con tolerancia exacta. La revisión independiente reprodujo colisiones CAS, rangos disjuntos, actor distinto, valores excesivos y el ledger real sin nuevos issues. Pasaron 110 pruebas focales; un wheel nuevo se instaló offline y superó `uv pip check` y el smoke de nueve fases, 14 comandos CLI y 14 herramientas MCP en Python 3.11 y 3.12. Son controles de declaraciones y de proceso, no autenticación de fuente, identidad ni impacto; criterios 1 y 2 siguen `no demostrado`.
- El [cotejo de piloto Agy sin comandos](../experiments/development/agy_no_command_trace_gate_2026-09-27.json) bloquea `artifacts_ready_for_inspection` y replay cuando la traza local muestra `RunCommand`, otro nombre de herramienta, un tipo de paso desconocido o ninguna escritura visible. El observador vuelve a derivar el resultado desde los bytes JSONL y liga `tool_policy` al prompt reconstruido desde las copias verificadas; así falla el downgrade del resumen a `default`. La revisión independiente encontró y ayudó a cerrar dos bypasses y una regresión de compatibilidad. Pasaron 79 pruebas focales y **1050** globales. La política sigue siendo una petición al modelo con verificación de eventos reportados, sin prohibición efectiva de comandos ni telemetría autenticada; criterio 4 `not_assessed`.
- El [control de enlaces decisivos](../experiments/development/decisive_direct_links_2026-09-27.json) impide acreditar un requisito por una implementación heredada desde el criterio, por un requisito heredado a través de un criterio citado por la implementación o por una prueba citada solo en la línea base. Conserva implementaciones compuestas cuando la prueba enlaza su implementación y el camino a requisito pasa únicamente por otras implementaciones. Se ensayaron `cumplido` e `incumplido` con fixtures; la revisión independiente pasó 11 regresiones focales y no halló otro falso verde en ese contrato acotado. El wheel actualizado se instaló sin red y pasó la sonda CLI en Python 3.11.15 y 3.12.3. No autentica ejecución ni efecto causal. Los criterios 2 y 3 siguen `not_assessed`.
- El [control de uso y participación declarados](../experiments/development/matrix_usage_presence_2026-09-27.json) cierra tres falsos verdes de la matriz: 324 recibos `completed` podían tener todas sus llamadas con cero tokens; 162 tríos podían registrar solo al líder activo; esos tríos también podían eludir la regla declarando `truncated` bajo todos los topes. Ahora cada llamada terminal exige entrada positiva, cada agente de un trío `completed` debe aportar una llamada y un truncamiento sin límite alcanzado genera infracción sin borrar el recibo. Pasaron 67 pruebas focales y **1032 pruebas** globales; los controles incluyen CLI de conciliación, caída externa y truncamiento en cada tope. Son cifras y roles autodeclarados, no recibos del proveedor ni comparación real; `criterion_4` sigue `not_assessed`.
- La [sonda de caída del servidor MCP](../experiments/development/mcp_server_crash_2026-09-27.json) usa un wheel instalado y un cliente stdio real para perder la conexión durante `run` antes y después de publicar el segundo evento. Un wrapper observó PID y salida `-SIGKILL`; el cliente recibió cierre de conexión, reconectó, completó tres eventos sin duplicados y conservó replay idéntico y estado igual por CLI/MCP. La revisión adversarial encontró que el primer borrador confundía salida ordinaria con `SIGKILL`; el control con salida 17 ahora falla, al igual que una excepción ajena al transporte. Es recuperación ante caída de ese proceso en dos ventanas sintéticas, no prueba de apagón ni de ejecución completa del criterio 1.
- La [ilustración de potencia](../experiments/development/field_power_mismatch_2026-09-27.json) separa la probabilidad de detectar `G = 0,10` frente a cero de la probabilidad de que el límite inferior bilateral del IC 95 % alcance el umbral `0,10` de §7. Con error estándar hipotético `0,0357`, son `0,7998708194` y `0,025` bajo un modelo normal fijo; pasaron 16 pruebas focales y **1015 pruebas** de la suite, incluidas entradas inválidas y dos pérdidas de precisión encontradas por revisión independiente. No hay datos previos multigrupo del sitio, simulación de la asignación/DiD/remuestreo previsto ni aprobación estadística: el resultado no es potencia de campo y `criterion_3` permanece `not_assessed`.
- El [manifiesto semanal opcional](preparacion_campo.md#cotejo-local-del-diseño-candidato-con-observaciones-declaradas) amplía el cotejo de diseño alimentario: la CLI exige una declaración distinta por grupo y semana UTC, incluida la semana parcial, y rechaza un hueco intermedio sin reporte de éxito. El [registro de desarrollo](../experiments/development/field_weekly_presence_2026-09-27.json) fija una corrida sintética de 12 grupos y 168 filas declaradas, un negativo de semana omitida, 26 pruebas focales y **999 pruebas** en ese corte. Siguen falsos `weekly_measurement_coverage_verified` y `execution_ready`: no se leyeron registros fuente, no se midió servicio semanal real ni se resolvió la potencia; `criterion_3` permanece `not_assessed`.
- El [expediente retrospectivo de Citi Bike marzo de 2024](../cases/citibike_march2024/README.md) registra 22 ítems y 24 eventos con cifras derivadas enlazadas al protocolo y a la fuente fijada por hash. Una revisión de agente distinto aceptó solo `frame`; `critique` sigue bloqueada por `n_scope` sin aprobación humana. El [registro](../experiments/development/citibike_march_ledger_2026-09-27.json) conserva las compuertas, y el ledger de junio de 2026 mantiene su SHA-256. Pasaron 3 pruebas focales y la suite completa de 987 pruebas. Los conteos son filas estación-instantánea, el protocolo es posterior al análisis y `criterion_5` sigue `not_assessed`.
- El [cotejo de diseño alimentario](../experiments/development/field_trial_design_2026-09-27.json) compara un plan candidato separado con observaciones declaradas de esquema 3 y servicio: 12 grupos como mínimo, seis por brazo, ambos brazos por estrato, ventanas de cuatro/ocho semanas y grupos, brazos, estratos y fechas coincidentes. La fixture anterior de dos grupos queda bloqueada como diseño del ensayo aunque siga siendo un grafo físicamente coherente. Una revisión adversarial encontró que el primer borrador permitía registrar el plan después de empezar la línea base; ahora exige una liberación basal declarada posterior al registro si se observó antes y rechaza fuentes de asignación previas al plan. Pasaron 14 pruebas focales y 985 de la suite. El registro, liberación, asignación y observaciones no tienen custodia autenticada; tampoco se comprueba cobertura semanal, potencia o efecto, y `criterion_3` sigue `not_assessed`.
- El [control de precisión de umbrales](../experiments/development/exact_decisive_threshold_2026-09-27.json) cerró otro falso verde de `validate`: convertir a `float` un límite inferior de 9 007 199 254 740 992 y un umbral previo de 9 007 199 254 740 993 los igualaba y permitía `cumplido`. El gate compara ahora valores finitos como `Decimal`; la regresión comprueba éxito y rechazo justo por debajo y en el umbral. Pasaron 971 pruebas y el wheel actual se instaló offline en CPython 3.11.15 y 3.12.3, con `uv pip check`, comprobación de la desigualdad exacta desde `site-packages` y smoke CLI/MCP en ambos. Las cifras, etiquetas de campo y aprobaciones de la fixture son inventadas; el control no autentica mediciones ni atribución causal.
- El [control de linaje de intervención](../experiments/development/decisive_intervention_lineage_2026-09-27.json) cierra un falso verde de `validate`: un `cumplido` de campo inventado pasaba sin ruta del resultado a ninguna prueba o implementación. Ahora `cumplido` e `incumplido` exigen una prueba vigente con `passed: true` de una implementación para cada requisito del mismo criterio, enlazada desde el resultado; cambiar esa rama revoca la aceptación hasta renovar resultado y revisión. `no_demostrado` conserva la salida para evidencia insuficiente y el ledger histórico sintético sigue legible. El wheel nuevo se instaló sin red en Python 3.11.15 y 3.12.3; el CLI instalado bloqueó el resultado sin prueba y aceptó la fixture con la prueba correcta. Es coherencia de declaraciones, no ejecución autenticada ni causalidad de campo.
- El [control de telemetría local](../experiments/development/local_usage_subset_2026-09-27.json) rechaza caché mayor que entrada y razonamiento mayor que salida en el resultado Codex/Agy y en cada paso Agy `DONE`. El falso verde anterior marcaba `complete: true` con 10 entradas/11 de caché y 2 salidas/3 de razonamiento. Las trazas crudas se conservan y `terminal_success` continúa separado de la integridad del uso. Pasaron 69 pruebas del runner/observador; la suite total tras ambos controles pasó 970. Los contadores siguen siendo declaraciones locales, no recibos de proveedor.
- El [verificador de stage publicado](../experiments/development/staged_readback_2026-09-27.json) relee una preparación N/S/T contra el calendario candidato suministrado, coteja árbol, archivos, permisos y resumen, e informa solo `stage_verified_at_read: true` con `execution_ready: false`. La primera versión aprobó un ZIP fijado con tráiler inválido cuando una revisión adversarial sustituyó temporalmente un ancestro durante la inspección por ruta. Ahora inspecciona ese ZIP desde el descriptor abierto y política/T desde bytes capturados del mismo descriptor que se hashea. La reproducción con calendario y hashes coherentes rechaza el ZIP tanto con sustitución como sin ella. Pasaron 41 pruebas de stage/publicador y 954 de la suite completa en ese corte; el calendario sigue sin autenticar y una lectura puntual no congela cambios posteriores ni autoriza ejecutar.
- La [sonda de commit interrumpido](../experiments/development/ledger_commit_crash_2026-09-27.json) mató con `SIGKILL` una CLI del wheel instalado antes y después de reemplazar el ledger en su segunda escritura. El estado recuperado conservó exactamente la revisión 1 o 2, y un cliente MCP real reanudó el mismo manifiesto hasta la revisión 3 sin duplicados; el replay conservó bytes idénticos en Python 3.11 y 3.12. El control sin hook falló y la revisión independiente corrigió un falso verde bajo `PYTHONOPTIMIZE=1`. Prueba caída del proceso, no durabilidad ante apagón o caída del host.
- La [compuerta de rechazo medido](../experiments/development/assessment_rejection_2026-09-27.json) bloquea ahora `incumplido` de campo si se apoya solo en simulación, carece de un efecto numérico ligado al criterio previo o su intervalo cruza el umbral de rechazo. Exige `reject_test` estructurado y conservador para el mismo umbral, y detecta cuando éxito y rechazo quedan simultáneamente satisfechos. La revisión independiente reprodujo esos falsos verdes antes de la corrección. Son pruebas de declaraciones sintéticas: no autentican campo ni establecen un impacto real.
- La [preparación privada de una entrega visible](../experiments/development/staged_visible_run_2026-09-27.json) comprueba una corrida seleccionada, copia solo los roles N/S/T, extrae el caso en `case/`, deja `work/` vacío y publica `stage.json` al final. Las pruebas sintéticas inspeccionan los bytes de caso y entrada, permisos, roles exactos y ausencia de las referencias y rúbrica ocultas. Una T adicional copió el bundle real CPython 3.11 con SHA-256 intacto y declaró que no había ejecución ni política aplicada. La revisión independiente reprodujo sustitución del ZIP de caso, alteración del árbol extraído, reemplazo simbólico de `work` y cambio del calendario en memoria que antes desalineaba los límites publicados del SHA verificado. Esos casos quedaron bloqueados; también se cerró la publicación de un manifiesto final tras un error. Esta preparación no sustituye aislamiento, aplicación de topes, recibos de proveedor ni custodia externa.
- El [bundle T para CPython 3.11](../experiments/development/released_toolkit_bundle_py311_2026-09-26.json) amplía el destino declarado del empaquetador a 3.11 o 3.12 Linux x86_64 sin alterar el paquete 3.12 anterior. Sus 28 wheels dependientes coinciden en nombre, tamaño y SHA-256 con `uv.lock`; tres llevan ABI `cp311` en vez de `cp312`. Dos empaquetados 3.11 dieron bytes idénticos. Una entrega T sintética conservó esos bytes y declaró `execution_ready: false`; desde su copia se instalaron offline 29 paquetes en CPython 3.11.15, pasaron `uv pip check` y el smoke de nueve fases, 14 comandos CLI y 14 herramientas MCP. CPython 3.12.3 rechazó esa copia por `cffi` de ABI `cp311`. Es una prueba local sin custodia, aislamiento, topes o proveedor; el criterio 4 sigue no demostrado.
- El [bundle T de desarrollo](../experiments/development/released_toolkit_bundle_py312_2026-09-26.json) ya reúne un wheel SpecOrganon, 28 wheels dependientes y los bytes de `uv.lock` en un solo ZIP de 9 688 897 bytes para CPython 3.12 Linux x86_64. Un preflight sintético lo copió intacto como `toolkit` solo para T; la copia pasó inspección de contenedor y wheel raíz, se extrajo a un directorio privado nuevo y permitió instalar 29 paquetes sin índice ni caché en un entorno CPython 3.12.3 nuevo. `uv pip check` y el smoke de nueve fases, 14 comandos CLI y 14 herramientas MCP pasaron; CPython 3.11.15 rechazó ese mismo paquete por `cffi` de ABI `cp312`. El ZIP local permanece bajo `dist/` ignorado por Git y no es una entrega custodiada. El inspector distingue los interiores de wheels dependientes no inspeccionados (`static_format_checked: false`) y nunca afirma `execution_ready`. Tres falsos éxitos del primer borrador, relativos a ese indicador y a sustitución de destinos de escritura, se repararon y volvieron a probar. Pasaron **885 tests**, Ruff y la reconstrucción byte idéntica. Faltan aislamiento, topes reales, proveedores, recibos y aprobación/custodia externa; el criterio 4 sigue no demostrado.
- Un [sondeo de wheelhouse offline](../experiments/development/offline_wheelhouse_py312_2026-09-26.json) descargó 28 dependencias fijadas y verificó sus hashes y tamaños contra `uv.lock`; con el wheel local fueron 29 archivos y 9,54 MB. Un entorno nuevo de CPython 3.12.3 instaló SpecOrganon con índice, red y caché deshabilitados, pasó `uv pip check` y el smoke sintético de nueve fases, 29 ítems, 14 comandos CLI y 14 herramientas MCP. El mismo wheelhouse falló para CPython 3.11.15 por ABI de `cffi`. En ese corte, el wheelhouse fue temporal y no se entregaba como activo T; no hay ejecución confirmatoria ni aislamiento efectivo.
- La [inspección estática del wheel T](preparacion_matriz.md#formatos-visibles-de-desarrollo) comprueba ZIP, CRC, `RECORD`, metadatos, módulos y puntos de entrada sin importar ni ejecutar el paquete. El [registro nuevo](../experiments/development/toolkit_wheel_static_2026-09-26.json) conserva el SHA-256 del wheel real, 34 pruebas del inspector, 10 de la integración y 845 tests totales en ese corte. Una revisión reprodujo y ayudó a cerrar la sustitución de ancestros y una colisión archivo/directorio; las reproducciones ahora fallan. El wheel no incluye sus dependencias y en ese corte faltaba una instalación limpia desde una entrega T, aplicación de topes y aislamiento, y ejecución de proveedor.
- El [control de formatos visibles](preparacion_matriz.md#formatos-visibles-de-desarrollo) añade un ZIP estricto para el caso, JSON de política declarada y un inspector de entrega N/S/T de solo lectura. El [registro de desarrollo](../experiments/development/released_payload_format_2026-09-26.json) conserva en su corte inicial 87 pruebas focales y 810 tests totales, un empaquetado D-E determinista y revisiones adversariales de carreras de extracción y rutas simbólicas. El inspector nunca declara una corrida lista: no instala T, no aplica aislamiento ni topes y no autentica calendario o proveedor.
- El [caso público D-E](caso_energia_desarrollo.md) añade una semana reproducible de [UCI](https://archive.ics.uci.edu/dataset/374/appliances%2Benergy%2Bprediction) con 1008 intervalos, hashes fijados y 118 280 Wh de `Appliances`. El [piloto N/SDD/T](../experiments/development/energy_pilot/README.md) archivó cinco intentos de un mismo modelo; los cinco scripts se ejecutaron con la muestra y T3 dejó 47 llamadas locales al CLI, 31 eventos y bloqueo real de `critique` bajo política `signed`. La [auditoría](../experiments/development/energy_pilot/audit.md) documenta estimaciones de ahorro no sustentadas, dos correcciones T posteriores, ausencia de telemetría comparable y revisión independiente no acreditada. No se puntuó `Q`, no se actuó en una vivienda y los criterios 4 y 5 siguen sin demostrar.
- El [runner D-E de desarrollo](../scripts/run_development_arm.py) ejecuta N/S/T con CLI locales en directorios privados nuevos, coteja el paquete y los hashes de prompts, conserva telemetría local y trazas crudas privadas, y exige inspeccionar `analysis.py` y aportar su SHA-256 antes del replay. Sus 26 pruebas focales cubren salidas 0 con fallos internos, `denied_actions`, timeouts, copia alterada, mutación durante replay y conciliación del uso por pasos de Agy. El parser suma los `step_update` indexados de Agy solo cuando se cierran con `DONE` y coinciden con el uso terminal; una discrepancia o paso incompleto deja la telemetría sin completar. El [registro de cuatro intentos reales](../experiments/development/local_cli_2026-09-26/README.md) conserva dos fallos instrumentales y dos N/S sin shell de Gemini 3.7 Flash Medium: ambos scripts se revisaron y reprodujeron 1008 intervalos, 118 280 Wh y los siete totales diarios. Los informes atribuyen standby sin submedición; S además declara riesgo eléctrico nulo y una media exterior incorrecta. Una prueba con permiso de Python en Agy permitió leer un archivo inocuo fuera del proyecto pese a `--sandbox`; se retiró el permiso. T no se ejecutó con este runner, los tokens no son recibos autenticados, un paso puede superar el límite antes de informar uso y no se puntuó `Q`. El criterio 4 sigue sin demostrar.
- El [smoke ampliado del wheel](../experiments/development/wheel_recovery_2026-09-26.json) pasó en dos instalaciones temporales nuevas, Python 3.11.15 y 3.12.3. En cada una, un `organon run` instalado recibió `SIGKILL` después de publicar 3 y 4 eventos respectivamente; `organon-mcp` reanudó el mismo manifiesto, conservó los checkpoints, completó los ítems pendientes y dejó el ledger intacto al repetir. Dos procesos CLI con actores declarados distintos, referencias y versiones esperadas conservaron ambos ítems. Su barrera de salida no demuestra lectura simultánea ni colisión; tampoco son dos agentes de modelo. La fuente del [caso mango](../cases/mango/fao_table15_loads.json) separa tres cargas publicadas y sus datos faltantes: una pérdida parcialmente estimada, otra redondeada y otra cuyo porcentaje impreso no se reproduce exactamente con los pesos impresos. No son una serie hasta consumo.
- La [comprobación de paridad del wheel](../experiments/development/wheel_transport_parity_2026-09-26.json) comparó 13 operaciones CLI/MCP sobre casos gemelos y el desafío de firma sobre un mismo caso; comprobó resultados y efectos, tiempos UTC de eventos y replay sin mutación. Ambos transportes aceptaron por separado una aprobación Ed25519 sintética válida; la retirada del registro de confianza invalidó ambas. Son comparaciones de las rutas ejercidas, no equivalencia formal para todos los estados o errores.
- La [corrida directa de dos subagentes nativos](prueba_multiagente.md#cli-instalada-invocada-por-dos-subagentes-nativos) usó la CLI de un wheel instalado. Su primera ronda conservó ocho ítems, pero A terminó antes de que B empezara. Una segunda ronda, liberada desde dos FIFO con pausas deliberadas, registró 20 inserciones alternadas y 387 033 229 ns de solapamiento de intervalos de procesos. El [verificador](../scripts/check_native_direct.py) coteja 28 llamadas archivadas con los 29 eventos del ledger y rechaza manipulaciones de tiempos, ruta y hash declarado del wheel. Los archivos no autentican la identidad de los subagentes ni prueban ventaja de coordinación.
- La [metodología](metodologia.md) define filosofía, investigación empírica, comparación y SDD, validación, entradas, salidas, revisión, parada y retorno para nueve fases. `src/specorganon` implementa ledger versionado, invalidación de dependencias, contradicciones, compuertas, runner reanudable, CLI y MCP 2.2 stdio. Los casos reales usan política `signed` por defecto, UUID y un registro externo de confianza por caso (ruta canónica, metadatos y claves públicas). `approval-challenge` liga la cabeza previa del ledger y la revisión exacta; `approve --signature` exige Ed25519. La firma acredita control de una clave configurada: identidad, custodia y competencia humana siguen siendo externas. Los casos documentales reales no contienen aprobaciones normativas.
- Los [antecedentes](antecedentes.md), [tres prototipos](../prototypes/) y [comparación de 33 escenarios mecánicos](alternativas.md) sustentan provisionalmente un grafo; conservan el fallo del flujo secuencial y el coste de reparación mayor del grafo. No hay ensayo controlado entre modelos o métodos completos.
- En un corte anterior, `.venv/bin/python -m pytest -q` pasó **985 tests**. La cobertura de ese corte incluyó 41 pruebas del paquete visible, 37 de la política declarada, 15 del gate integrado, 35 del inspector del wheel T y 34 del bundle T, 46 de la entrega verificada y 33 de la observación D-E, además de las 36 focales del runner local, el analizador escolar y los controles de linaje alimentario. La suite incluye cliente MCP real, firma Ed25519 y controles de replay, invalidación/revisión, runner entre procesos, escritura atómica, ancla externa opcional, un `SIGKILL` seguido de reanudación y validaciones adversariales del calendario, archivos, firma del diseño, recibos, conciliación, ensamblaje de `Q`, análisis secundario e incertidumbre pareada sobre declaraciones, juicios ciegos y flujos alimentarios. Una revisión anterior añadió rechazo de JSON no finito, subdesbordamiento a cero y pérdida visible de valor decimal, alineación de requisito e indicador por problema y cronología declarada del acta frente al primer bloqueo de `Q`. Otras revisiones añadieron resolución de pares cuantitativos, controles prospectivos declarados de campo, precondiciones de versión y referencias de manifiestos. El [control de fuentes alimentarias](../experiments/development/field_source_controls_2026-09-26.json) rechaza fechas anteriores a la salida y fuentes de inocuidad/nutrición declaradas para otra carga. El banco de desarrollo pasó **21/21 inyecciones**; no es todavía la reserva sellada del protocolo. Los tests nuevos de la matriz y de campo usan manifiestos, archivos, claves efímeras, recibos, puntuaciones y observaciones inventadas.
- En aquel corte, el wheel con SHA-256 `83add783d93618180199ddc42925a1ea318853414e2e79b8305b191b10561a49` se instaló sin red en un entorno nuevo Python 3.11.15; `uv pip check` pasó. `scripts/clean_smoke.py` aceptó nueve fases, 29 ítems y 49 eventos, invocó las 14 operaciones previas CLI/MCP y descubrió las 16 herramientas publicadas. En el mismo entorno, 26 pruebas focales pasaron usando `specorganon` desde `site-packages`, incluidas firma de evaluador por CLI/MCP y gate de campo aún bloqueado. El mismo wheel pasó después `uv pip check`, el smoke de nueve fases y las 26 pruebas focales instaladas también en Python 3.12.3. El [control de JSON estricto](../experiments/development/strict_json_transport_2026-09-26.json) conserva los falsos éxitos anteriores y las pruebas negativas y positivas actuales. El [registro de escrituras protegidas](../experiments/development/guarded_put_2026-09-26.json) conserva ejecuciones anteriores del wheel; el [inventario previo](../experiments/development/interface_wheel_inventory_2026-09-26.json) permanece como evidencia histórica. La fixture exige `ORGANON_ALLOW_FIXTURES=1` en una ruta no registrada; ninguna etiqueta `human:fixture` o `human:synthetic-signer` representa aprobación humana real.
- La [prueba multiagente](prueba_multiagente.md) usó un agente nativo para escribir 29 ítems con el runner y otro para revisar y avanzar las nueve fases. Una primera asignación a dos escritores conservó ítems disjuntos sin pérdida, pero sin solapamiento observable. En una prueba sintética de desarrollo adicional, la primera ronda terminó con un conflicto de revisión y ningún ítem de B; tras añadir reintentos acotados, la segunda registró **487 098 218 ns** de solapamiento entre intervalos activos de dos procesos y **80 cambios de actor** en 80 inserciones. Una prueba posterior de dos procesos forzó una colisión y conservó ambos ítems con un reintento interno; son procesos, no agentes de modelo. Las inserciones siguieron serializadas; esta única prueba no mide ventaja de tiempo, coste o calidad ni autentica a los agentes.
- El [expediente documental de mango](caso_alimentos_investigacion.md) conserva datos publicados de 2016, rutas separadas y una inconsistencia aritmética de FAO. Tres cargas distintas de la tabla 15 quedaron en el seed y anexadas al ledger con sus porcentajes impresos y recalculados por separado; el [registro de anexo](../experiments/development/mango_table15_ledger_2026-09-26.json) comprueba que no se reescribieron los 27 eventos anteriores. El ledger suma 26 ítems y 30 eventos, con revisión histórica de `frame` sin firma: el replay actual la marca `legacy_unverified` y no acepta la fase. `critique` requiere además decisión humana. Ninguna carga llega a consumo.
- El [análisis reproducible de residuos de comedor escolar](../cases/school_waste/README.md) usa 155 jornadas reales de un [depósito Zenodo](https://zenodo.org/records/20825233) con fuente y plan previos fijados por hash. La media ponderada de PW+KSW pasó de 45,095972 a 29,068510 g/comensal entre los períodos expuestos, una diferencia descriptiva de −16,027462 g/comensal. La [sensibilidad temporal exploratoria](sensibilidad_temporal_escuela.md) calcula las 98 ventanas basales completas de 20 jornadas, expone las 18 excluidas por una jornada sin KSW, desglosa las cuatro semanas finales y conserva el escenario sin dos filas discordantes. Las 98 ventanas se solapan y no son réplicas. Dos [revisiones de modelos sobre el mismo resumen](../experiments/development/school_temporal_model_review_2026-09-27.json) señalaron selección posterior, faltantes y ausencia de control; no examinaron los datos ni produjeron un ensayo N/SDD/T. Sin comparador contemporáneo, el contraste no atribuye una causa; la fuente cubre consumo y servicio, no una cadena completa ni el criterio 3.
- El [expediente documental de Citi Bike](caso_citibike_ejecucion.md) reutiliza el mismo núcleo con 30 ítems. La revisión de `s_proxy` hizo obsoletos 12 descendientes, incluyendo decisión y requisito candidatos. Un segundo agente revisó y avanzó `frame`; `critique` espera aprobación humana. Una [regresión sin red](../experiments/development/citibike_transfer_replay_2026-09-26.json) volvió a sembrar el caso en un directorio temporal y reprodujo el evento 31 por la CLI instalada: comprobó esos 12 obsoletos, la traza hasta el requisito, la revisión de `frame`, el bloqueo de `critique` y el rechazo de una aprobación sin firma, sin cambiar el ledger fuente. El paquete de junio de 2026 quedó expuesto y se trata como desarrollo, no reserva confirmatoria.
- Un [sondeo puntual del GBFS público actual](../experiments/development/citibike_gbfs_probe_2026-09-26.json) enlazó 2.520 IDs de estación entre información y estado, pero halló que los tres indicadores necesarios para clasificar alquiler/devolución no eran booleanos JSON como exige GBFS 2.3. Se descartó el conteo de disponibilidad. No se guardaron respuestas brutas ni se obtuvo una serie; además, la política pública limita la extracción automatizada. Es un control adverso de calidad de fuente, no medición de impacto.
- Una [muestra histórica publicada por la oficina del contralor de Nueva York](../experiments/development/citibike_sample_status_2026-09-27.json), fijada por commit y SHA-256, aportó 1.812.548 filas estación-instantánea de marzo de 2024. El [analizador reproducible](../cases/citibike/analyze_sample_status.py) excluyó 3.512 filas de conteos incompatibles con la capacidad y separó alquiler habilitado con bicicleta (1.725.248 de 1.809.036) de devolución habilitada con anclaje (1.682.386 de 1.809.036). Un revisor independiente reprodujo los conteos y halló un desbordamiento `int64` en el primer borrador; `add_checked` lo rechaza ahora. Las 820 capturas son irregulares y no permiten estimar estación-minutos continuos, viajes frustrados ni impacto. El archivo bruto permanece fuera del repo; la muestra no se mezcla con junio de 2026 y el criterio 5 sigue no demostrado.
- La auditoría adversarial encontró ocho fallos de integridad/runner; se corrigieron con regresiones: rechazo tardío, resolución antigua, éxito de campo sin estructura, indicador sin evidencia, resolución modificada, métrica divergente, autoevaluación final y reparación bloqueada. Los tests no demuestran que no existan otros fallos.
- La revisión de seguridad de aprobaciones cerró replay entre casos/rutas, metadatos y prefijos de ledger, y la degradación de una ruta registrada a fixture. El ancla externa opcional implementada bloquea lectura CLI/MCP y nuevas escrituras cuando un ledger local, aunque conserve una cadena coherente, difiere en UUID, ruta, metadatos, secuencia o cabeza del registro. Una prueba integrada rechaza truncamiento, extensión y fork de igual longitud; el candidato de cabeza es de solo lectura. Tras cada escritura legítima hay que verificar y actualizar el ancla por custodia independiente antes de continuar. La prueba de rollback conjunto muestra el límite: si ledger y ancla se restauran juntos, la verificación acepta el pasado. La identidad del revisor sigue siendo autodeclarada; no existe aún custodia de producción ni validación humana de transiciones.
- La [preparación de la matriz](preparacion_matriz.md) incluye un planificador de bloques N/S/T y un analizador de diferencias pareadas de calidad `Q`. El primero exige cuatro modelos en dos familias, tres casos R-F/R-M/R-S identificados por hashes visibles y de referencia, tres réplicas y un orden equilibrado; produce un **candidato sin sellar** de hasta 432 corridas. El segundo calcula efectos e intervalos solo a partir de puntuaciones suministradas. El [analizador secundario](preparacion_matriz.md#análisis-secundario-declarado) comprueba enlaces internos con recibos y el ensamblaje de juicios, calcula `E/T/R/W/P` con los pesos fijados y sus intervalos marginales pareados, y conserva `C/H/K` descriptivos; deja cualquier métrica con datos faltantes sin agregado confirmatorio. Ambos análisis mantienen el criterio 4 expresamente sin evaluar. Estas herramientas y sus pruebas usan datos inventados; no hay paquetes reservados, ejecuciones confirmatorias de proveedores ni evaluadores reales. La [investigación documental del panel](panel_modelos_preliminar.md) encontró que las etiquetas bajo/alto de MiniMax M3 no ajustan la profundidad, por lo que todavía no hay un panel válido registrado.
- El [preparador de archivos](preparacion_matriz.md#comprobación-de-bytes-y-paquete-de-una-corrida) verifica los bytes de los 15 activos declarados y, para un solo `run_id`, crea un paquete con solo los materiales del brazo asignado. La revisión adversarial encontró y corrigió un fallo real al abrir el directorio y probó cambios de bytes y sustitución durante la copia. Un directorio padre bajo control de otro usuario se rechaza; un proceso hostil con el mismo UID o una respuesta escondida dentro de material visible quedan fuera de lo que un hash local puede descartar. Aún no hay custodia externa ni reserva real.
- El [verificador de entrega y observador local](preparacion_matriz.md#comprobación-de-bytes-y-paquete-de-una-corrida) comprueban por separado la entrega frente a un calendario candidato independiente y los bytes/uso agregado de un piloto D-E ya producido. Los controles focales suman 46 y 33 pruebas; el observador incluye dos directorios reales del runner con CLI falsas, y ambas rutas recibieron revisión independiente sin hallazgos pendientes. Ninguna salida autentica calendario, proveedor o coste, impone topes ni genera un recibo confirmatorio. El caso visible, la política y el wheel T tienen formatos inspeccionables; las dependencias de T, su instalación desde la entrega y la aplicación real de política y límites siguen sin ejecutor genérico.
- El [comprobador de firma](preparacion_matriz.md#firma-offline-del-diseño-candidato) liga el calendario exacto y bytes actuales a `GOAL.md` intacto y al protocolo mediante un desafío Ed25519 de propósito experimental. Rechaza un orden de brazos equilibrado pero alterado respecto de la semilla, mensajes de otro propósito y firmas inválidas. El [auditor de recibos](preparacion_matriz.md#auditoría-de-recibos-declarados) comprueba identidades, reintentos, límites por invocación, orden terminal dentro de bloque y concurrencia en JSON de desarrollo; conserva faltantes y excesos. Ambos indican expresamente `unsealed`. No hay firma real de custodio, eventos de liberación bajo custodia, proveedor ejecutado ni puntuación independiente.
- La [conciliación de matriz](preparacion_matriz.md#conciliación-de-recibos-y-puntuaciones-declaradas) detecta puntuaciones sin recibo terminal y exige que el digest del artefacto puntuado coincida con el terminal declarado. La [auditoría de juicios ciegos](preparacion_matriz.md#auditoría-estructural-de-juicios-ciegos) exige dos jueces declarados, cinco componentes enteros, dos etapas y arbitraje con incidentes individuales cuando corresponde; conserva las notas crudas. El [ensamblaje de desarrollo](preparacion_matriz.md#ensamblaje-declarado-de-q-tras-el-cierre-de-juicios) aplica la regla de `Q`, vincula IDs opacos con corridas terminales declaradas y deja faltantes visibles. La [preparación de campo](preparacion_campo.md) coteja un grafo declarado de lotes, masas, consumo, fechas y cargas por actor con aritmética exacta; exige fuentes de inocuidad y nutrición fechadas desde la salida e identificadas con la carga consumida. No calcula `V` ni `G` ni certifica cobertura de toda la cadena o identidad física de muestras. Estas herramientas y sus pruebas son sintéticas y no autentican bytes, personas, proveedor, asignación o impacto.

El [control inicial de etapas alimentarias](../experiments/development/field_stage_witness_2026-09-26.json) añadió esquema 2 al preflight con un testigo por grupo/período. La [regresión actual de consumo y fuentes terminales](../experiments/development/field_consumption_lineage_2026-09-26.json) exige un camino completo para **cada consumo humano declarado** y `load_id` coincidente en las fuentes de destino y resultado de toda salida terminal de esquema 2. Una rama consumida corta ya no queda cubierta por la ruta completa de otra rama. El esquema 1 conserva su contrato limitado sin comprobar etapas ni vincular esas dos fuentes terminales por carga. Los caminos siguen describiendo operaciones: una mezcla dentro de un lote no permite identificar qué entrada formó una salida, ni se autentican etapas, muestras o impacto.

El [contraejemplo de mezcla](../experiments/development/field_mixing_limit_2026-09-26.json) permanece como control de esquema 2: una entrada tardía de 70 kg y un residuo de 70 kg mantienen el balance 140/140, aunque toda la entrada de ruta larga pueda salir a compost. El [esquema 3 opcional](preparacion_campo.md) exige asignaciones nominales completas por lote y una cota conservadora positiva de masa con las etapas requeridas para cada consumo. Sus [controles sintéticos](../experiments/development/field_schema3_conservative_lineage_2026-09-26.json) rechazan esa mezcla y un falso enlace entre dos mezclas sucesivas; aceptan un aporte declarado y garantizado de 20 kg. Una revisión independiente encontró tres falsos rechazos, corregidos mediante límites incidentes, cotas por requisitos mínimos de etapa y complementos de filas. La [búsqueda acotada de fuentes públicas](caso_alimentos_fuentes_candidatas.md) y el análisis escolar expuesto no aportaron una misma cadena con ingesta observada y diseño causal suficiente. No hay medición física autenticada ni efecto de campo atribuible; el criterio 3 sigue sin evaluar.

La [regresión de linaje](../experiments/development/evidence_lineage_2026-09-26.json) registra dos falsos verdes del motor anterior y su corrección: evidencia generada sin protocolo y requisito/criterio que mezclaban norma y evidencia de problemas ajenos. También bloquea la reasignación de evidencia protocolizada mediante un protocolo hermano y el respaldo de indicadores por evidencia declaradamente ajena en métrica o unidad; conserva el uso de fuentes publicadas independientes bajo un protocolo explícito. El [nuevo control requisito–indicador](../experiments/development/criterion_indicator_alignment_2026-09-26.json) cierra la posibilidad de que un criterio de P1 tome un indicador de P2 solo por compartir el nombre de la métrica. En aquel corte, la suite pasó 902 tests y Ruff; el wheel instalado pasó en Python 3.11.15 y 3.12.3 en una verificación anterior. Estos controles son de estructura y metadatos declarados; evidencia sin métrica o unidad conserva soporte provisional y no se verifica veracidad de fuentes ni autoridad humana.

La [corrección de unidades de éxito](decisiones.md#d-026--alinear-unidades-antes-de-aceptar-un-éxito-medido) bloquea `cumplido` cuando indicador, línea base y efecto no declaran la misma unidad, o cuando una unidad explícita de criterio/umbral contradice esa medición. Una revisión adversarial reprodujo los falsos verdes y comprobó los rechazos mediante el gate público. Son declaraciones sintéticas: el toolkit no verifica conversiones físicas ni un efecto de campo.

El [desglose de Q](../experiments/development/q_case_reporting_2026-09-26.json) deja visible una pérdida sintética de 20 puntos en R-F que el agregado positivo ocultaba. Los efectos globales e intervalos previos no cambiaron, y los faltantes siguen anulando el estimador principal. No hay resultados confirmatorios ni nuevos datos de campo.

La [regresión de rechazo de ítem](../experiments/development/item_review_rejection_2026-09-26.json) cerró otro falso verde: rechazar `req1` vigente tras completar las nueve fases dejaba aceptadas `specify`, `build` y `validate`. Ahora el rechazo bloquea el ítem y sus dependientes; una aceptación posterior requiere revisión y avance nuevos. Una primera implementación desaceptó los ledgers existentes al cambiar hashes incluso sin revisiones; la corrección conserva el snapshot histórico de mango, Citi Bike y `synthetic_multiagent` sin modificar sus archivos. El wheel reconstruido pasó en dos entornos limpios con 14 operaciones CLI/MCP comparadas en los escenarios del smoke.

El [cotejo de actas de preparación](preparacion_matriz.md#cotejo-local-de-actas-de-preparación-preexistentes) comprueba archivos preexistentes mediante SHA-256 de bytes crudos y vincula ID opaco, intento terminal, cuatro digests y receta declarada. Su [registro inicial](../experiments/development/preparation_records_2026-09-26.json) documenta controles S/T, FIFO, fuentes/pruebas y archivos extra. La [ampliación cronológica](../experiments/development/preparation_rating_chronology_2026-09-26.json) añade el documento de juicios y rechaza actas fechadas después del primer bloqueo declarado; 19 pruebas focales quedaron verdes. No hubo actas reales, custodia externa ni ejecución de receta. Un mapa, juicios y actas falsificados juntos todavía pueden pasar el chequeo local; `criterion_4` queda `not_assessed`.

## Pendiente para GOAL.md

La [matriz prospectiva](protocolo_experimental.md) aún requiere validación confirmatoria de la coordinación entre agentes de modelo, identidad/autoridad humana y procedencia de fuentes verificadas externamente; banco sellado de 21 inyecciones; observación hasta consumo, valor aprobado y ensayo de campo alimentario; ejecución controlada N/SDD/toolkit por modelos, esfuerzos y configuraciones con réplicas/ablaciones, telemetría y evaluación ciega; [fuentes secundarias auténticas y mediciones completas](preparacion_matriz.md#análisis-secundario-declarado) de errores, trazabilidad, recuperación, tiempo y coste; y un nuevo caso reservado de movilidad y otras transferencias completas. Calendario, paquetes, desafío de firma, recibos, juicios, cálculos secundarios y flujos sintéticos no constituyen registro previo custodiado, ejecuciones confirmatorias de proveedores ni observación de campo. El solapamiento de una prueba sintética de desarrollo, las firmas con clave generada para el smoke y las dos revisiones de `frame` no sustituyen esas evidencias.

Una [cuestión estadística abierta](enmiendas_protocolo.md#2026-09-27--cuestión-estadística-abierta-del-ensayo-alimentario) distingue la potencia para detectar `G = 0,10` frente a cero de la probabilidad de que el límite inferior del IC de `G` alcance `0,10`, que es la regla de éxito vigente. El [contraejemplo normal](../experiments/development/field_power_mismatch_2026-09-27.json) cuantifica esa diferencia con error estándar supuesto, sin estimar potencia de campo. Antes de asignar grupos se necesitan datos previos del sitio y aprobación del cálculo de potencia y su hipótesis; no se ha alterado el umbral.

El protocolo propone hasta 540 ejecuciones, 48 millones de tokens y presupuestos humanos y monetarios; **no están autorizados**. Antes de lanzar la matriz confirmatoria o un ensayo de campo se necesitan sitio, actores competentes, aprobación de valores y umbrales, acceso/telemetría de modelos, evaluación independiente, reserva sellada y aprobación de recursos. Si alguna capacidad no se consigue, el criterio afectado permanece `no demostrado`.

## Reanudar

1. Leer [GOAL.md](../GOAL.md), [validacion_actual.md](validacion_actual.md), [plan.md](plan.md), [protocolo_experimental.md](protocolo_experimental.md), la [bitácora de enmiendas](enmiendas_protocolo.md) y la [preparación de matriz](preparacion_matriz.md).
2. Verificar rama, `git status`, `uv run --locked --extra dev python -m pytest -q tests`, `uv build --wheel` y el smoke en un entorno nuevo antes de concluir sobre funcionamiento técnico. En casos reales, comprobar `ORGANON_APPROVERS_FILE` de esquema 2 contra UUID, ruta y `project_sha256`; en producción, omitir `ORGANON_ALLOW_FIXTURES`.
3. Mantener separados datos publicados, ficción de tests y observaciones de campo. No usar Citi Bike junio de 2026 como reserva ciega ni cambiar umbrales por resultados favorables.
