# SpecOrganon · MVP local

Metodología operativa de filosofía, ciencia, ingeniería y validación.
Incluye wheel, skill de agente y guías. Los ejemplos, experimentos y
veredictos completos permanecen en el repositorio de desarrollo.

## Instalar

Linux, Python 3.11 o 3.12 y un agente con acceso a herramientas locales.
Las dependencias son cryptography y mcp; pueden instalarse desde la caché
existente o el índice de paquetes. Este paquete no contiene un modelo.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install specorganon-0.1.0-py3-none-any.whl
organon init ./mi-proyecto --title "Mi problema" --domain desarrollo --approval-policy local --actor human:owner
organon next-task ./mi-proyecto
organon report ./mi-proyecto --format markdown
```

Entrega al agente la skill en `.agents/skills/specorganon/SKILL.md`, el
problema y los límites autorizados. En este paquete usa `organon` desde el
entorno instalado; `uv run organon` corresponde al checkout del repositorio.
El agente investiga, compara, implementa y ejecuta pruebas; otro agente
revisa. El toolkit conserva dependencias, compuertas y checkpoints.

Para un cliente MCP stdio, el ejecutable instalado es `organon-mcp`.
ORGANON_ROOT puede delimitar un directorio existente bajo control del
operador; ese modo requiere el soporte Linux Landlock del servidor.

El modo local registra el mandato existente y revisiones técnicas declaradas.
No autentica identidades ni demuestra impacto de campo. `signed` continúa
como valor inicial si se omite la política. Para una ejecución nueva crea un
caso nuevo y aporta evidencias propias. Las guías detalladas incluyen enlaces
históricos al repositorio que no forman parte de esta distribución mínima.
