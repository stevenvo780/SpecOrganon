# FractionMix

FractionMix sums rational numbers using exact integer arithmetic and returns a reduced fraction with a positive denominator. Zero is always 0/1. Empty lists produce zero; zeros, duplicate terms and cancellations all count toward `term_count`.

## Installation and invocation

Requires Python 3.12 and only its standard library. Place `fractionmix.py` in `/input/delivery/`; no package installation is needed. Run:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Supply input exclusively through stdin. Every command-line argument, including `--help`, causes an error before stdin is read. The program does not read auxiliary files, environment data or network data, and does not modify delivery files.

## Public examples

```sh
printf '%s\n' '{"terms":[{"numerator":1,"denominator":2},{"numerator":1,"denominator":3}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Output:

```json
{"numerator":5,"denominator":6,"term_count":2}
```

```sh
printf '%s\n' '{"terms":[{"numerator":2,"denominator":4},{"numerator":-1,"denominator":2}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Output:

```json
{"numerator":0,"denominator":1,"term_count":2}
```

## Formats, errors and limits

Input must be one strict JSON object with exactly the key `terms`. Its value must be a list containing 0 through 1000 objects, each with exactly `numerator` and `denominator`. Numerators must be JSON integers from -1000000000 through 1000000000; denominators must be JSON integers from 1 through 1000000000. Booleans, floats and strings are rejected without coercion. Every term is validated, including zero terms and terms that cancel.

The input limit is 65536 bytes inclusive, counting final whitespace. UTF-8 must be strict, without an initial BOM or any NUL byte. Exterior JSON whitespace is allowed. Empty input, duplicate keys anywhere (including keys equal after escape decoding), extra properties, additional JSON values and NaN/Infinity/-Infinity are rejected. Key order is irrelevant.

Success exits with code 0 and empty stderr. Stdout contains exactly one JSON object with integer `numerator`, `denominator` and `term_count`, beginning with `{` and ending with `}\n`. Output integers may exceed the input bounds and 4300 decimal digits; decimal conversion is explicitly enabled without that default restriction. Contract-derived bounds are at most 9001 denominator digits and 9013 numerator digits.

Every contractual error exits with code 2, leaves stdout empty, and writes exactly `{"error":"invalid_input"}\n` to stderr. No partial result is emitted. Execution failures such as timeout, out-of-memory or crashes remain execution failures.

The external invocation budget is 3 seconds, 2 CPUs, 1 GiB memory, 128 processes and a 2 MiB stream maximum, with read-only delivery, no network and no credentials. These are runner constraints, not limits imposed by this script.

## Reproducible check command

The following command uses the fixed absolute interpreter for both the checks and every program invocation. It checks public successes, empty input lists, integer boundaries and representative errors. No separate test files are included at this stage. These checks have not been executed here; no measurements or reserved-case results were supplied.

```sh
/opt/specorganon/venv/bin/python -E -s -B - <<'PY'
import subprocess

command = ['/opt/specorganon/venv/bin/python', '-E', '-s', '-B', '/input/delivery/fractionmix.py']
cases = [
    (b'{"terms":[{"numerator":1,"denominator":2},{"numerator":1,"denominator":3}]}', b'{"numerator":5,"denominator":6,"term_count":2}\n'),
    (b'{"terms":[{"numerator":2,"denominator":4},{"numerator":-1,"denominator":2}]}', b'{"numerator":0,"denominator":1,"term_count":2}\n'),
    (b'{"terms":[]}', b'{"numerator":0,"denominator":1,"term_count":0}\n'),
    (b'{"terms":[{"numerator":-1000000000,"denominator":1000000000}]}', b'{"numerator":-1,"denominator":1,"term_count":1}\n'),
]
for data, expected in cases:
    result = subprocess.run(command, input=data, capture_output=True, timeout=3)
    assert (result.returncode, result.stdout, result.stderr) == (0, expected, b'')
invalid = [
    b'',
    b'{"terms":[],"terms":[]}',
    b'{"terms":[{"numerator":true,"denominator":1}]}',
    b'{"terms":[{"numerator":0,"denominator":0}]}',
    b'{"terms":[{"numerator":NaN,"denominator":1}]}',
    b'{"terms":[]} {}',
    b'\xef\xbb\xbf{"terms":[]}',
    b'{"terms":[]}\x00',
    b'{"terms":[]}' + b' ' * (65537 - len(b'{"terms":[]}')),
]
for data in invalid:
    result = subprocess.run(command, input=data, capture_output=True, timeout=3)
    assert (result.returncode, result.stdout, result.stderr) == (2, b'', b'{"error":"invalid_input"}\n')
result = subprocess.run(command + ['--help'], input=b'', capture_output=True, timeout=3)
assert (result.returncode, result.stdout, result.stderr) == (2, b'', b'{"error":"invalid_input"}\n')
print('Checks passed')
PY
```

These checks cover finite synthetic cases and do not establish universal coverage, usefulness for people or superiority of any development method. Reserved evaluation is outside this delivery.
