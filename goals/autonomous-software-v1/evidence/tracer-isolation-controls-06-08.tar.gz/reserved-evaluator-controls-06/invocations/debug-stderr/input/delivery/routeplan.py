import sys
sys.stdout.write('{"cost":null,"path":[],"reachable":false}\n')
sys.stderr.write('debug\n')
