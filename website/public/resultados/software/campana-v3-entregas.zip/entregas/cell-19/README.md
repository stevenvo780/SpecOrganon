# PolicyPick

PolicyPick selects a rule for each query using Python 3.12 and only the standard library. It implements the supplied local selection contract; it does not establish effectiveness for real access control or legal compliance.

## Installation and interface

Save the supplied `policypick.py` in `/input/delivery`. For example, from a directory containing the delivered file:

```sh
mkdir -p /input/delivery
cp policypick.py /input/delivery/policypick.py
```

Python 3.12 must be available at `/opt/specorganon/venv/bin/python`. No packages need installation. Invoke without arguments:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py < input.json
```

All arguments, including `--help`, cause an error before stdin is read.

## Format, semantics, and limits

Input is one strict UTF-8 JSON object with exactly `rules` and `queries`. Surrounding and internal JSON whitespace, including LF, CR, and tab, is allowed. Concatenated documents, BOM, raw NUL, duplicate object keys, NaN, and Infinity are invalid. The entire document is validated before selecting any rule.

Each rule has exactly `name`, `priority`, and `requires`. Each query has exactly `id` and `tags`. The outer lists and each `requires` or `tags` list contain at most 1000 elements. The complete input is at most 65536 bytes, including whitespace.

Names, IDs, and list entries are nonempty strings of at most 64 UTF-8 bytes after decoding escapes. NUL, CR, LF, and unencodable surrogates are forbidden. Spaces, tabs, case, and Unicode are literal: there is no trimming or normalization. Rule names are unique, and query IDs are unique, with independent namespaces. Repeated entries in `requires` and `tags` are valid and behave as set membership.

Priorities are JSON integers from -1000000000 through 1000000000 inclusive. Booleans, floating-point numbers, and strings are invalid priorities.

A rule matches when its requirements are a subset of the query's tags. Empty requirements always match. The highest priority wins; equal priorities use the smallest name in Unicode code-point order. Input rule order does not affect the result. Unknown tags are valid. A query without a matching rule receives `null`. Empty rules produce `null` for every query; empty queries produce `{"decisions":[]}`.

Success exits 0 with empty stderr and one compact JSON object followed by exactly one LF on stdout. Its `decisions` list contains exactly `id` and `rule` for each query in input order. Output uses JSON escapes where needed, including for non-ASCII characters.

Any invalid input exits 2 with empty stdout and exactly `{"error":"invalid_input"}` followed by LF on stderr. An invalid rule or query rejects the whole document even if it could not affect a winning rule.

The supplied execution envelope is 3 seconds, 2 CPUs, 1 GiB memory, 128 PIDs, no network, read-only delivery, and 2 MiB per output stream. No execution measurements were supplied, so performance within that envelope has not been measured. Token and monetary costs are unknown.

## Public example 1

```sh
printf '%s\n' '{"rules":[{"name":"default","priority":0,"requires":[]},{"name":"staff","priority":2,"requires":["internal"]}],"queries":[{"id":"q1","tags":["internal","internal"]},{"id":"q2","tags":[]}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py
```

Expected stdout, followed by LF:

```json
{"decisions":[{"id":"q1","rule":"staff"},{"id":"q2","rule":"default"}]}
```

## Public example 2

```sh
printf '%s\n' '{"rules":[{"name":"z","priority":3,"requires":["x"]},{"name":"A","priority":3,"requires":["x"]}],"queries":[{"id":"yes","tags":["x"]},{"id":"no","tags":[]}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/policypick.py
```

Expected stdout, followed by LF:

```json
{"decisions":[{"id":"yes","rule":"A"},{"id":"no","rule":null}]}
```

## Executable checks

The following command uses only the standard library and creates no test files. It checks both public examples, empty lists, duplicate keys, boolean priorities, invalid unused rules, concatenated documents, the input byte limit, and argument rejection without waiting for stdin. These checks have not been run and do not establish universal coverage or performance compliance.

```sh
/opt/specorganon/venv/bin/python -E -s -B - <<'PY'
import subprocess

command = ['/opt/specorganon/venv/bin/python', '-E', '-s', '-B',
           '/input/delivery/policypick.py']
error = b'{"error":"invalid_input"}\n'
cases = [
    (b'{"rules":[{"name":"default","priority":0,"requires":[]},{"name":"staff","priority":2,"requires":["internal"]}],"queries":[{"id":"q1","tags":["internal","internal"]},{"id":"q2","tags":[]}]}',
     0, b'{"decisions":[{"id":"q1","rule":"staff"},{"id":"q2","rule":"default"}]}\n', b''),
    (b'{"rules":[{"name":"z","priority":3,"requires":["x"]},{"name":"A","priority":3,"requires":["x"]}],"queries":[{"id":"yes","tags":["x"]},{"id":"no","tags":[]}]}',
     0, b'{"decisions":[{"id":"yes","rule":"A"},{"id":"no","rule":null}]}\n', b''),
    (b'{"rules":[],"queries":[]}', 0, b'{"decisions":[]}\n', b''),
    (b'{"rules":[],"rules":[],"queries":[]}', 2, b'', error),
    (b'{"rules":[{"name":"r","priority":true,"requires":[]}],"queries":[]}', 2, b'', error),
    (b'{"rules":[{"name":"r","priority":0,"requires":[""]}],"queries":[]}', 2, b'', error),
    (b'{"rules":[],"queries":[]}{}', 2, b'', error),
    (b' ' * 65537, 2, b'', error),
]
for payload, status, stdout, stderr in cases:
    result = subprocess.run(command, input=payload, capture_output=True, timeout=3)
    assert (result.returncode, result.stdout, result.stderr) == (status, stdout, stderr)
process = subprocess.Popen(command + ['--help'], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
try:
    process.wait(timeout=3)
    assert (process.returncode, process.stdout.read(), process.stderr.read()) == (2, b'', error)
finally:
    if process.poll() is None:
        process.kill()
        process.wait()
    process.stdin.close()
    process.stdout.close()
    process.stderr.close()
print('Checks passed')
PY
```
