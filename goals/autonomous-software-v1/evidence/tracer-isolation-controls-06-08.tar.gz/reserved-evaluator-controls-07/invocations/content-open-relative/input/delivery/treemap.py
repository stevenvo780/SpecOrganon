import os
os.chdir('/fixture/root')
with open('probe.txt','rb') as f: f.read()
import sys
sys.stdout.write('{"files":[{"bytes":3,"path":"probe.txt"}],"symlinks":["link"],"total_bytes":3}\n')
