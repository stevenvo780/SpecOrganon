from pathlib import Path
p=Path("/tmp/fixture/root");p.mkdir(parents=True)
(p/"probe.txt").write_bytes(b"abc")
(p/"probe.txt").read_bytes()
import sys
sys.stdout.write('{"files":[{"bytes":3,"path":"probe.txt"}],"symlinks":["link"],"total_bytes":3}\n')
