# Laboratorio Docker: Codex + SpecOrganon MCP

Desde la raíz del repositorio:

```sh
docker compose build
docker compose run --rm -T codex python /opt/codex-lab/smoke.py
docker compose run --rm codex codex login --device-auth
docker compose run --rm -T codex python /opt/codex-lab/trial.py
docker compose run --rm codex
```

El primer smoke no necesita cuenta ni modelo: arranca el **MCP stdio real**,
descubre sus 24 herramientas, crea un caso local, escribe tres artefactos enlazados,
consulta compuerta, informe y siguiente tarea, rechaza una versión obsoleta y una
ruta externa, reinicia el proceso y coteja el estado con la CLI. Se exige
`ORGANON_ROOT=/workspace`, Linux y Landlock ABI 5+; el servidor conserva su rechazo
al arranque cuando el kernel no satisface el contrato. Probado con el seccomp
predeterminado de Docker, sin modo privilegiado.

La segunda prueba requiere autenticación y **consume uso real de Codex**. `trial.py`
ejecuta `codex exec`, conserva prompt, eventos JSONL, stderr, respuesta y recibo.
Para esa ejecución habilita únicamente `init`, `put`, `status`, `gate`, `trace`,
`next_task` y `report`, con aprobación previa por herramienta limitada a la prueba.
Esto permite la ejecución no interactiva sin modificar las aprobaciones de sus
sesiones habituales ni habilitar herramientas de aprobación o avance de fases.
Comprueba las llamadas MCP terminadas y el ledger persistido; un texto de respuesta
que solo afirme haber usado MCP no pasa. Termina sin aceptar fases ni inventar
revisión independiente. Puede elegir un modelo habilitado para su cuenta:

```sh
docker compose run --rm -T codex python /opt/codex-lab/trial.py --model ID_DEL_MODELO
```

## Autenticación

El login con código de dispositivo requiere habilitar esa opción en los ajustes
de seguridad de ChatGPT. La credencial queda en el volumen `codex-home`. El MCP local
no tiene OAuth propio: `auth_status: unsupported` en `codex mcp list --json` es normal.

Si prefiere API, defina `OPENAI_API_KEY` en el entorno del host y ejecute los mismos
comandos. El entrypoint la entrega a `codex login --with-api-key` por stdin únicamente
si todavía no existe `auth.json`. No se incluyen credenciales del host en el build.
Para cambiar una autenticación existente, use `codex logout` y vuelva a iniciar sesión.

Mantenga esta sesión separada: no copie `auth.json` ni intercambie tokens entre
perfiles o contenedores. El volumen autenticado pertenece a este laboratorio;
Docker no añade cuota ni licencias.

## Entorno y persistencia

- Python 3.12, Node 22, Codex CLI **0.160.0**, uv **0.12.22**.
- Dependencias Python resueltas con `uv.lock`; el proyecto se instala desde un wheel.
- Usuario `codex` (UID 1000), sin capabilities, `no-new-privileges` y sandbox Codex
  `workspace-write`. No se monta el socket Docker ni el repositorio del host.
- Bubblewrap necesita namespaces y montajes dentro de ellos. Compose usa el allowlist
  seccomp de Moby ampliado con `clone`, `unshare`, `mount`, `umount2`, `pivot_root`,
  y `apparmor:unconfined` solo para este servicio. Reduce esa capa externa para que
  funcione el sandbox Codex; mantiene seccomp, usuario sin privilegios y cap_drop ALL.
  No cambia sysctls, perfiles del host ni controles del trabajo principal.
- `/opt/specorganon`: código, scripts, tests, manifiestos, documentación y wheel.
  Los archivos de casos y experimentos históricos no se incorporan a la imagen.
- `/workspace`: volumen con casos, resultados, skill e instrucciones del laboratorio.
- `/home/codex/.codex`: volumen con configuración, sesión e historial de Codex.

La configuración inicial se copia al crear el volumen. Una reconstrucción de imagen
actualiza el paquete instalado pero conserva la configuración y documentación ya
copiadas al workspace; para actualizar esas copias, hágalo explícitamente después
de revisar sus cambios. Puede sobrescribir versiones de Codex y uv al construir:
`CODEX_VERSION=... UV_VERSION=... docker compose build`.

Consultar y exportar resultados:

```sh
docker compose run --rm -T codex ls /workspace/results
docker compose run --rm -T codex organon report /workspace/cases/NOMBRE --format markdown
docker compose run --rm -T codex tar -C /workspace -czf - cases results > laboratorio-resultados.tar.gz
```

El smoke histórico de nueve fases también está disponible:

```sh
docker compose run --rm -T codex python /opt/specorganon/scripts/clean_smoke.py /opt/specorganon
```

Este último habilita fixtures sintéticas **solo en sus procesos de prueba**;
no acredita consentimiento ni revisión humana ni eficacia del método. El smoke
acotado y la prueba Codex usan casos locales y conservan pendientes los gates.

`docker compose down` conserva ambos volúmenes. `docker compose down -v` elimina
casos, resultados y autenticación: úselo solo cuando quiera borrar el laboratorio.

Documentación oficial usada: [MCP en Codex](https://developers.openai.com/codex/mcp),
[autenticación](https://developers.openai.com/codex/auth) y
[ejecución CLI](https://developers.openai.com/codex/cli/reference).
