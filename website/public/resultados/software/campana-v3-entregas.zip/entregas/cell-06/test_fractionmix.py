"""Own contract tests; separate from the reserved evaluation corpus.

Run with /opt/specorganon/venv/bin/python -E -s -B
/input/delivery/test_fractionmix.py in the externally isolated delivery.
No program imports, mutable auxiliary inputs, or network access.
"""
import json
import math
import random
import resource
import subprocess
import sys
import unittest

PYTHON = '/opt/specorganon/venv/bin/python'
PROGRAM = '/input/delivery/fractionmix.py'
ARGV = [PYTHON, '-E', '-s', '-B', PROGRAM]
ERROR = b'{"error":"invalid_input"}\n'
sys.set_int_max_str_digits(0)


def limits():
    # Preserve any stricter inherited hard limits.
    for key, value in ((resource.RLIMIT_CPU, 2),
                       (resource.RLIMIT_AS, 1024 ** 3),
                       (resource.RLIMIT_NPROC, 128)):
        _, hard = resource.getrlimit(key)
        cap = value if hard == resource.RLIM_INFINITY else min(value, hard)
        resource.setrlimit(key, (cap, cap))


def payload(terms):
    return json.dumps({'terms': [
        {'numerator': n, 'denominator': d} for n, d in terms
    ]}, separators=(',', ':')).encode('utf-8')


def oracle(terms):
    # Deliberately use a common product rather than incremental addition.
    denominator = math.prod(d for _, d in terms)
    numerator = sum(n * (denominator // d) for n, d in terms)
    divisor = math.gcd(numerator, denominator)
    return {'numerator': numerator // divisor,
            'denominator': denominator // divisor,
            'term_count': len(terms)}


def unique(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('duplicate output key')
        obj[key] = value
    return obj


def reject_constant(value):
    raise ValueError('non-JSON output constant')


def prime(value):
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    return all(value % d for d in range(3, math.isqrt(value) + 1, 2))


class ContractTests(unittest.TestCase):
    def invoke(self, raw, args=()):
        result = subprocess.run(ARGV + list(args), input=raw,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=3, env={}, preexec_fn=limits)
        self.assertLessEqual(len(result.stdout), 2 * 1024 ** 2)
        self.assertLessEqual(len(result.stderr), 2 * 1024 ** 2)
        return result

    def valid(self, terms, raw=None, expected=None):
        result = self.invoke(payload(terms) if raw is None else raw)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, b'')
        self.assertTrue(result.stdout.startswith(b'{'))
        self.assertTrue(result.stdout.endswith(b'}\n'))
        text = result.stdout[:-1].decode('utf-8', errors='strict')
        actual = json.loads(text, object_pairs_hook=unique,
                            parse_constant=reject_constant)
        self.assertIs(type(actual), dict)
        self.assertEqual(set(actual), {'numerator', 'denominator', 'term_count'})
        self.assertTrue(all(type(v) is int for v in actual.values()))
        self.assertGreater(actual['denominator'], 0)
        self.assertEqual(math.gcd(actual['numerator'], actual['denominator']), 1)
        self.assertEqual(actual, oracle(terms) if expected is None else expected)

    def invalid(self, raw, args=()):
        result = self.invoke(raw, args)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b'')
        self.assertEqual(result.stderr, ERROR)

    def test_public_examples_and_oracle_anchors(self):
        examples = [([(1, 2), (1, 3)], (5, 6, 2)),
                    ([(2, 4), (-1, 2)], (0, 1, 2)),
                    ([], (0, 1, 0)),
                    ([(-3, 4)], (-3, 4, 1))]
        for terms, values in examples:
            expected = dict(zip(('numerator', 'denominator', 'term_count'), values))
            with self.subTest(terms=terms):
                self.assertEqual(oracle(terms), expected)
                self.valid(terms, expected=expected)

    def test_arithmetic_and_order(self):
        cases = [[(0, 7)], [(1, 3), (1, 3)],
                 [(1, 2), (-1, 2), (0, 9)],
                 [(1000000000, 1)] * 1000,
                 [(-1000000000, 1000000000), (1000000000, 1)],
                 [(999999999, 1000000000), (-999999998, 999999999)]]
        rng = random.Random(20261005)
        cases += [[(rng.randint(-1000000000, 1000000000),
                    rng.randint(1, 1000000000)) for _ in range(30)]
                  for _ in range(8)]
        for index, terms in enumerate(cases):
            with self.subTest(case=index):
                self.valid(terms)
                self.valid(list(reversed(terms)))

    def test_input_size_and_decoded_keys(self):
        raw = b'{"terms":[]}'
        self.valid([], raw=raw + b' ' * (65536 - len(raw)))
        self.invalid(raw + b' ' * (65537 - len(raw)))
        self.valid([(1, 2)], raw=b' \t\r\n{"ter\\u006ds":[{"denominator":2,"numerator":1}]}\n')
        self.valid([(0, 1)], raw=b'{"terms":[{"numerator":-0,"denominator":1}]}')
        self.invalid(payload([(0, 1)] * 1001))

    def test_large_decimal_result(self):
        denominators = []
        candidate = 999999999
        while len(denominators) < 1000:
            if prime(candidate):
                denominators.append(candidate)
            candidate -= 2
        terms = [(1, d) for d in denominators]
        raw = payload(terms)
        self.assertLessEqual(len(raw), 65536)
        expected = oracle(terms)
        self.assertGreater(len(str(expected['denominator'])), 4300)
        self.assertGreater(len(str(expected['numerator'])), 4300)
        self.valid(terms, raw=raw, expected=expected)

    def test_invalid_json_encoding_and_structure(self):
        cases = [b'', b' \t\r\n', b'\xff', b'\xc0\xaf',
                 b'\xef\xbb\xbf{"terms":[]}', b'{"terms":[]}\x00',
                 b'{"terms":[]}{}', b'{"terms":[]} trailing',
                 b'{"terms":[],}', b'{/*comment*/"terms":[]}',
                 b'{"terms":[]}\xc2\xa0', b'[]', b'null', b'1',
                 b'{}', b'{"terms":[],"extra":0}',
                 b'{"terms":null}', b'{"terms":{}}', b'{"terms":""}',
                 b'{"terms":[null]}', b'{"terms":[[]]}',
                 b'{"terms":[{}]}',
                 b'{"terms":[],"terms":[]}',
                 b'{"terms":[],"ter\\u006ds":[]}',
                 b'{"terms":[{"numerator":1,"denominator":2,"numerator":1}]}',
                 b'{"terms":[{"numerator":1,"denominator":2,"denominat\\u006fr":2}]}',
                 b'{"terms":[],"extra":{"x":1,"x":2}}',
                 b'{"terms":[' + b'[' * 1500 + b'0' + b']' * 1500 + b']}',
                 b'{"terms":[{"numerator":' + b'9' * 5000 + b',"denominator":1}]}']
        for index, raw in enumerate(cases):
            with self.subTest(case=index):
                self.invalid(raw)

    def test_invalid_term_values(self):
        good = {'numerator': 1, 'denominator': 2}
        for key, values in (
            ('numerator', [-1000000001, 1000000001, True, False, None, '1', [], {}]),
            ('denominator', [-1, 0, 1000000001, True, False, None, '2', [], {}])):
            for value in values:
                term = dict(good, **{key: value})
                with self.subTest(key=key, value=value):
                    self.invalid(json.dumps({'terms': [term]}).encode())
        for key in good:
            for token in ('1.0', '1e0', 'NaN', 'Infinity', '-Infinity', '01', '+1'):
                parts = dict(numerator='1', denominator='2')
                parts[key] = token
                raw = ('{"terms":[{"numerator":' + parts['numerator'] +
                       ',"denominator":' + parts['denominator'] + '}]}').encode()
                with self.subTest(key=key, token=token):
                    self.invalid(raw)
        for term in ({'numerator': 0, 'denominator': 0},
                     {'numerator': 0, 'denominator': -2},
                     {'numerator': 0, 'denominator': 1, 'extra': 0},
                     {'numerator': 1}, {'denominator': 1}):
            self.invalid(json.dumps({'terms': [good, term,
                         {'numerator': -1, 'denominator': 2}]}).encode())

    def test_arguments_precede_stdin(self):
        for args in (['--help'], ['unexpected'], ['--']):
            with self.subTest(args=args):
                process = subprocess.Popen(ARGV + args, stdin=subprocess.PIPE,
                                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                           env={}, preexec_fn=limits)
                try:
                    # Keep stdin open and empty: reading it would block.
                    code = process.wait(timeout=3)
                    self.assertEqual(code, 2)
                    self.assertEqual(process.stdout.read(), b'')
                    self.assertEqual(process.stderr.read(), ERROR)
                finally:
                    if process.poll() is None:
                        process.kill()
                    process.wait()
                    process.stdin.close()
                    process.stdout.close()
                    process.stderr.close()


if __name__ == '__main__':
    unittest.main()
