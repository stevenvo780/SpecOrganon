import sys
sys.stdout.write('{"cost":true,"path":["A","B"],"reachable":true}\n')
