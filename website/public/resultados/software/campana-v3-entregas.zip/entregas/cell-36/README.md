# ListPatch

`listpatch.py` es una utilidad estándar en Python 3.12 que aplica transformaciones secuenciales a una lista de enteros en formato JSON a través de `stdin`.

## Instalación

Requiere Python 3.12 (solo biblioteca estándar):
```bash
# Invocación de referencia:
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/listpatch.py
```

## Interfaz y Formato

- **Argumentos de línea de comandos**: `sys.argv` debe estar vacío de parámetros adicionales. Cualquier argumento (incluso `--help`) produce error inmediato con salida 2 antes de procesar `stdin`.
- **Entrada (`stdin`)**: Un único documento JSON codificado en UTF-8 estricto sin BOM ni bytes NUL crudos. Se permiten espacios en blanco internos y externos estándar. Máximo 65536 bytes.
- **Estructura de entrada**: Exactamente `{"items":[...],"operations":[...]}`.
- **Salida (`stdout`)**: En caso de éxito (código de salida 0), emite exactamente `{"items":[...],"applied":N}\n` sin espacios en blanco externos y con stderr vacío.
- **Error (`stderr`)**: En caso de cualquier error (código de salida 2), stdout queda vacío y stderr emite exactamente `{"error":"invalid_input"}\n`.

## Límites del Contrato

- `stdin`: Máximo 65536 bytes.
- `items`: Lista de 0 a 1000 enteros JSON. Valores permitidos: enteros entre -1000000000 y 1000000000 (sin booleanos, floats ni strings).
- `operations`: Lista de 0 a 1000 objetos de operación.
- `index`: Entero JSON entre 0 y 1000 (sin booleanos, floats ni strings).
- Tamaño máximo de lista: Nunca puede superar 1000 elementos, ni de forma temporal durante la ejecución.

## Semántica Secuencial y Atomicidad

Las operaciones se validan sintáctica y estructuralmente antes de su aplicación. Se ejecutan secuencialmente en el orden provisto: cada índice opera sobre el estado resultante de las operaciones previas. No hay idempotencia. Si alguna operación falla (por ejemplo, índice fuera de rango o intento de exceder 1000 elementos), el proceso falla inmediatamente de forma atómica sin emitir estado parcial.

Operaciones permitidas:
- `{"op":"insert","index":i,"value":v}`: 0 <= i <= longitud actual.
- `{"op":"replace","index":i,"value":v}`: 0 <= i < longitud actual.
- `{"op":"delete","index":i}`: 0 <= i < longitud actual.

## Ejemplos Públicos

### Ejemplo 1
```bash
printf '%s' '{"items":[10,20],"operations":[{"op":"insert","index":1,"value":15},{"op":"replace","index":0,"value":9},{"op":"delete","index":2}]}' | python3 listpatch.py
# Salida esperada:
# {"items":[9,15],"applied":3}
```

### Ejemplo 2
```bash
printf '%s' '{"items":[],"operations":[{"op":"insert","index":0,"value":-2},{"op":"delete","index":0}]}' | python3 listpatch.py
# Salida esperada:
# {"items":[],"applied":2}
```

## Pruebas y Cobertura

Para verificar la implementación contra los límites y casos de error:
```bash
python3 -c '
import subprocess, json

def run(inp, args=[]):
    p = subprocess.run(["python3", "listpatch.py"] + args, input=inp.encode("utf-8"), capture_output=True)
    return p.returncode, p.stdout.decode("utf-8"), p.stderr.decode("utf-8")

# Prueba 1: Ejemplo 1
code, out, err = run("{\"items\":[10,20],\"operations\":[{\"op\":\"insert\",\"index\":1,\"value\":15},{\"op\":\"replace\",\"index\":0,\"value\":9},{\"op\":\"delete\",\"index\":2}]}")
assert code == 0 and out == "{\"items\":[9,15],\"applied\":3}\n" and err == ""

# Prueba 2: Argumentos no permitidos
code, out, err = run("{}", ["--help"])
assert code == 2 and err == "{\"error\":\"invalid_input\"}\n" and out == ""

# Prueba 3: Clave duplicada
code, out, err = run("{\"items\":[],\"items\":[],\"operations\":[]}")
assert code == 2 and err == "{\"error\":\"invalid_input\"}\n"
print("Todas las pruebas pasaron exitosamente.")
'
```
