import os
fd=os.open("/fixture/root/link",os.O_PATH|os.O_NOFOLLOW)
assert os.readlink("/proc/self/fd/"+str(fd))=="/fixture/root/link"
os.close(fd)
import sys
sys.stdout.write('{"files":[{"bytes":3,"path":"probe.txt"}],"symlinks":["link"],"total_bytes":3}\n')
