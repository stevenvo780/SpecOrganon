# Candidato de desarrollo 0.2.0rc3.dev2

La campaña v3 queda cerrada; este paquete contiene código posterior. No demuestra superioridad.

Instalación: `uv sync --frozen --extra dev`. Docker: `docker build -f docker/release/Dockerfile -t specorganon-dev2 .`.

Pruebas del cambio: `uv run python -m pytest tests/test_typed_author_content.py tests/test_author_contract.py tests/test_software_controller.py tests/test_software_controller_resources.py tests/test_artifact_guidance.py tests/test_controller_native_role.py tests/test_software_comparison_v3_cells.py tests/test_runner.py tests/test_runner_manifest_schema.py`.

El SDK Controller conserva manifest-v1; seleccionar explícitamente `author_format="items-v1"` en un caso nuevo. Las celdas nuevas T/A usan el contrato tipado.

No reanudar archivos frozen de v3 con este candidato. Las credenciales no están incluidas; cada usuario debe iniciar su propia sesión en un volumen propio. El Docker de instalación y el runtime del autor nativo son imágenes distintas.
