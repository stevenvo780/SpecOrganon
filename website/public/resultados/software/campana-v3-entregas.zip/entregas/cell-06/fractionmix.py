"""FractionMix: strict stdin validation and exact rational addition."""

import json
import sys
from math import gcd


MAX_BYTES = 65536
MAX_TERMS = 1000
MAX_VALUE = 1000000000
ERROR = b'{"error":"invalid_input"}\n'


def invalid():
    raise ValueError('invalid input')


def integer_token(token):
    # Every integer allowed anywhere in the input has at most ten digits.
    digits = token[1:] if token.startswith('-') else token
    if len(digits) > 10:
        invalid()
    value = int(token)
    if abs(value) > MAX_VALUE:
        invalid()
    return value


def forbidden_number(token):
    invalid()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            invalid()
        result[key] = value
    return result


def validate(raw):
    if len(raw) > MAX_BYTES or b'\x00' in raw:
        invalid()
    text = raw.decode('utf-8', errors='strict')
    if text.startswith('\ufeff'):
        invalid()
    document = json.loads(
        text,
        object_pairs_hook=unique_object,
        parse_int=integer_token,
        parse_float=forbidden_number,
        parse_constant=forbidden_number,
    )
    if type(document) is not dict or set(document) != {'terms'}:
        invalid()
    terms = document['terms']
    if type(terms) is not list or len(terms) > MAX_TERMS:
        invalid()
    for term in terms:
        if type(term) is not dict:
            invalid()
        if set(term) != {'numerator', 'denominator'}:
            invalid()
        numerator = term['numerator']
        denominator = term['denominator']
        if type(numerator) is not int or type(denominator) is not int:
            invalid()
        if not -MAX_VALUE <= numerator <= MAX_VALUE:
            invalid()
        if not 1 <= denominator <= MAX_VALUE:
            invalid()
    return terms


def add_terms(terms):
    numerator, denominator = 0, 1
    for term in terms:
        other_n = term['numerator']
        other_d = term['denominator']
        shared = gcd(denominator, other_d)
        numerator = numerator * (other_d // shared) + other_n * (denominator // shared)
        denominator *= other_d // shared
        divisor = gcd(numerator, denominator)
        numerator //= divisor
        denominator //= divisor
    return {
        'numerator': numerator,
        'denominator': denominator,
        'term_count': len(terms),
    }


def main():
    if len(sys.argv) != 1:
        sys.stderr.buffer.write(ERROR)
        return 2
    try:
        raw = sys.stdin.buffer.read(MAX_BYTES + 1)
        terms = validate(raw)
    except (ValueError, RecursionError):
        sys.stderr.buffer.write(ERROR)
        return 2
    # Input integers were already bounded independently of this output setting.
    sys.set_int_max_str_digits(0)
    result = add_terms(terms)
    encoded = (json.dumps(result, separators=(',', ':')) + '\n').encode('utf-8')
    sys.stdout.buffer.write(encoded)
    return 0


if __name__ == '__main__':
    sys.exit(main())
