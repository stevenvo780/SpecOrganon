"""Atomic sequential list transformations; Python 3.12, standard library only."""

import json
import sys


MAX_INPUT_BYTES = 65536
MAX_ELEMENTS = 1000
VALUE_MIN = -1000000000
VALUE_MAX = 1000000000
ERROR = '{"error":"invalid_input"}\n'


class InvalidInput(ValueError):
    pass


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidInput()
        result[key] = value
    return result


def reject_constant(value):
    raise InvalidInput()


def bounded_integer(value, minimum, maximum):
    return type(value) is int and minimum <= value <= maximum


def validate(document):
    if type(document) is not dict or set(document) != {"items", "operations"}:
        raise InvalidInput()
    items = document["items"]
    operations = document["operations"]
    if type(items) is not list or type(operations) is not list:
        raise InvalidInput()
    if len(items) > MAX_ELEMENTS or len(operations) > MAX_ELEMENTS:
        raise InvalidInput()
    for value in items:
        if not bounded_integer(value, VALUE_MIN, VALUE_MAX):
            raise InvalidInput()
    for operation in operations:
        if type(operation) is not dict:
            raise InvalidInput()
        op = operation.get("op")
        if type(op) is not str or op not in ("insert", "replace", "delete"):
            raise InvalidInput()
        expected = {"op", "index"} if op == "delete" else {"op", "index", "value"}
        if set(operation) != expected:
            raise InvalidInput()
        if not bounded_integer(operation["index"], 0, MAX_ELEMENTS):
            raise InvalidInput()
        if op != "delete" and not bounded_integer(operation["value"], VALUE_MIN, VALUE_MAX):
            raise InvalidInput()


def transform(document):
    validate(document)
    items = document["items"].copy()
    for operation in document["operations"]:
        op = operation["op"]
        index = operation["index"]
        if op == "insert":
            if index > len(items) or len(items) >= MAX_ELEMENTS:
                raise InvalidInput()
            items.insert(index, operation["value"])
        else:
            if index >= len(items):
                raise InvalidInput()
            if op == "replace":
                items[index] = operation["value"]
            else:
                del items[index]
    return {"items": items, "applied": len(document["operations"])}


def main():
    if len(sys.argv) != 1:
        sys.stderr.write(ERROR)
        return 2
    try:
        raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
        if len(raw) > MAX_INPUT_BYTES or raw.startswith(b"\xef\xbb\xbf") or b"\x00" in raw:
            raise InvalidInput()
        text = raw.decode("utf-8", errors="strict")
        document = json.loads(
            text,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
        result = transform(document)
        output = json.dumps(result, separators=(",", ":"), allow_nan=False) + "\n"
    except (ValueError, TypeError, RecursionError, OSError):
        sys.stderr.write(ERROR)
        return 2
    sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    sys.exit(main())
