Visible task for R-M.
