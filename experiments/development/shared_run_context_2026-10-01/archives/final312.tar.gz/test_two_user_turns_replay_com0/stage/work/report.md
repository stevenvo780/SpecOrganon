sealed output
