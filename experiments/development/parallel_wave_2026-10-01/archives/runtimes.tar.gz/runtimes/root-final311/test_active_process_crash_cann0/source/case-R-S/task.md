Visible task for R-S.
