#!/usr/bin/env python3
"""Compute a minimum-cost directed route using only the standard library."""

import heapq
import json
import re
import sys


MAX_BYTES = 65536
NODE_ID = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,15}")


class InvalidInput(ValueError):
    pass


def reject_number(_text):
    raise InvalidInput("Unsupported JSON number")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidInput("Duplicate key")
        result[key] = value
    return result


def require_object(value, keys):
    if type(value) is not dict or set(value) != keys:
        raise InvalidInput("Invalid object")


def require_endpoint(value, nodes):
    if type(value) is not str or value not in nodes:
        raise InvalidInput("Invalid endpoint")


def parse_input(raw):
    if len(raw) > MAX_BYTES:
        raise InvalidInput("Input too large")
    text = raw.decode("utf-8")
    data = json.loads(
        text,
        object_pairs_hook=unique_object,
        parse_float=reject_number,
        parse_constant=reject_number,
    )
    require_object(data, {"nodes", "edges", "query"})

    nodes = data["nodes"]
    if type(nodes) is not list or not 1 <= len(nodes) <= 32:
        raise InvalidInput("Invalid nodes")
    seen_nodes = set()
    for node in nodes:
        if type(node) is not str or NODE_ID.fullmatch(node) is None:
            raise InvalidInput("Invalid node ID")
        if node in seen_nodes:
            raise InvalidInput("Duplicate node")
        seen_nodes.add(node)

    edges = data["edges"]
    if type(edges) is not list or len(edges) > 128:
        raise InvalidInput("Invalid edges")
    seen_edges = set()
    for edge in edges:
        require_object(edge, {"source", "target", "cost"})
        require_endpoint(edge["source"], seen_nodes)
        require_endpoint(edge["target"], seen_nodes)
        cost = edge["cost"]
        if type(cost) is not int or not 1 <= cost <= 1000:
            raise InvalidInput("Invalid cost")
        pair = (edge["source"], edge["target"])
        if pair in seen_edges:
            raise InvalidInput("Duplicate edge")
        seen_edges.add(pair)

    query = data["query"]
    require_object(query, {"source", "target"})
    require_endpoint(query["source"], seen_nodes)
    require_endpoint(query["target"], seen_nodes)
    return nodes, edges, query


def find_route(nodes, edges, query):
    source, target = query["source"], query["target"]
    if source == target:
        return {"reachable": True, "cost": 0, "path": [source]}

    forward = {node: [] for node in nodes}
    reverse = {node: [] for node in nodes}
    for edge in edges:
        start, end, cost = edge["source"], edge["target"], edge["cost"]
        forward[start].append((end, cost))
        reverse[end].append((start, cost))

    # Distances to the destination, obtained by reversing every directed edge.
    distances = {target: 0}
    queue = [(0, target)]
    while queue:
        distance, node = heapq.heappop(queue)
        if distances[node] != distance:
            continue
        for predecessor, cost in reverse[node]:
            candidate = distance + cost
            previous = distances.get(predecessor)
            if previous is None or candidate < previous:
                distances[predecessor] = candidate
                heapq.heappush(queue, (candidate, predecessor))

    if source not in distances:
        return {"reachable": False, "cost": None, "path": []}

    # Every eligible edge extends a shortest route. Choosing the smallest next
    # ID gives the lexicographically smallest complete path. Positive costs
    # strictly decrease the remaining distance, so reconstruction terminates.
    path = [source]
    current = source
    while current != target:
        current = min(
            neighbor
            for neighbor, cost in forward[current]
            if neighbor in distances
            and cost + distances[neighbor] == distances[current]
        )
        path.append(current)
    return {"reachable": True, "cost": distances[source], "path": path}


def main():
    if len(sys.argv) != 1:
        sys.stderr.write('{"error":"invalid_input"}\n')
        return 2
    try:
        raw = sys.stdin.buffer.read(MAX_BYTES + 1)
        nodes, edges, query = parse_input(raw)
    except (ValueError, UnicodeError, RecursionError, OSError):
        sys.stderr.write('{"error":"invalid_input"}\n')
        return 2

    result = find_route(nodes, edges, query)
    sys.stdout.write(json.dumps(result, ensure_ascii=True, separators=(",", ":")) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
