# FractionMix

FractionMix sums rational numbers with exact integer arithmetic and returns a reduced fraction with a positive denominator. Zero is always `0/1`. Every term contributes to `term_count`, including duplicates, zero terms, and cancellations. All terms are validated before calculation.

## Installation and invocation

Requires Python 3.12 and only its standard library; no package installation is needed. Place `fractionmix.py` in `/input/delivery/`. The required interpreter must already be installed at `/opt/specorganon/venv/bin/python`.

Run without arguments, supplying input exclusively through stdin:

```sh
/opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Any argument, including `--help`, produces the contractual error before stdin is read. The program does not consult auxiliary files, network services, or environment variables and does not modify delivery files.

## Public examples

```sh
printf '%s\n' '{"terms":[{"numerator":1,"denominator":2},{"numerator":1,"denominator":3}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Output:

```json
{"numerator":5,"denominator":6,"term_count":2}
```

```sh
printf '%s\n' '{"terms":[{"numerator":2,"denominator":4},{"numerator":-1,"denominator":2}]}' | /opt/specorganon/venv/bin/python -E -s -B /input/delivery/fractionmix.py
```

Output:

```json
{"numerator":0,"denominator":1,"term_count":2}
```

## Formats, errors, and limits

Input must be one strict UTF-8 JSON object with exactly the key `terms`. JSON whitespace may surround it. An initial BOM, any NUL byte, empty input, additional JSON values, duplicate object keys (including escaped equivalents), and NaN or Infinity constants are invalid.

`terms` must be a list of 0 through 1000 objects, each with exactly `numerator` and `denominator`. Numerators must be JSON integers from -1000000000 through 1000000000. Denominators must be JSON integers from 1 through 1000000000. Booleans, floats, strings, extra properties, and coercions are rejected. One invalid term invalidates the whole input, even when its numerator is zero or its value would cancel another term.

Input is limited to 65536 bytes inclusive, counting trailing whitespace. The reader requests at most 65537 bytes to detect overflow. Output is one JSON object with exactly the integer fields `numerator`, `denominator`, and `term_count`, followed by one LF. Successful execution exits 0 with empty stderr. The empty terms list returns `{"numerator":0,"denominator":1,"term_count":0}`.

Every contractual error exits 2, leaves stdout empty, and writes exactly these bytes to stderr, including the final LF:

```text
{"error":"invalid_input"}
```

Result integers may exceed 4300 decimal digits; integer conversion is explicitly enabled for this domain. The contract-derived bounds are at most 9001 denominator digits and 9013 numerator digits, not additional acceptance limits. The external execution limits are 3 seconds, 2 CPUs, 1 GiB memory, 128 processes, and a 2 MiB stream maximum, with read-only delivery and no network or credentials. Resource failures remain execution failures rather than contractual input errors.

## Reproducible checks

The following command runs standard-library checks without creating test files. It checks both public examples, empty input terms, inclusive integer and term-count boundaries, exact byte-size acceptance, and representative invalid inputs. These checks have not been executed as part of this delivery; no measurements were supplied.

```sh
/opt/specorganon/venv/bin/python -E -s -B - <<'PY'
import json
import subprocess

command = ['/opt/specorganon/venv/bin/python', '-E', '-s', '-B', '/input/delivery/fractionmix.py']

def check(raw, expected=None, args=()):
    result = subprocess.run(command + list(args), input=raw, capture_output=True, timeout=3)
    if expected is None:
        assert (result.returncode, result.stdout, result.stderr) == (2, b'', b'{"error":"invalid_input"}\n')
    else:
        assert result.returncode == 0 and result.stderr == b''
        assert result.stdout.startswith(b'{') and result.stdout.endswith(b'}\n')
        assert json.loads(result.stdout) == expected

check(b'{"terms":[{"numerator":1,"denominator":2},{"numerator":1,"denominator":3}]}', {'numerator':5,'denominator':6,'term_count':2})
check(b'{"terms":[{"numerator":2,"denominator":4},{"numerator":-1,"denominator":2}]}', {'numerator':0,'denominator':1,'term_count':2})
base = b'{"terms":[]}'
check(base, {'numerator':0,'denominator':1,'term_count':0})
check(base + b' ' * (65536 - len(base)), {'numerator':0,'denominator':1,'term_count':0})
check(base + b' ' * (65537 - len(base)))
terms = [{'numerator':1000000000,'denominator':1000000000}, {'numerator':-1000000000,'denominator':1}]
check(json.dumps({'terms':terms}).encode(), {'numerator':-999999999,'denominator':1,'term_count':2})
zeros = [{'numerator':0,'denominator':1}] * 1000
check(json.dumps({'terms':zeros}).encode(), {'numerator':0,'denominator':1,'term_count':1000})
check(json.dumps({'terms':zeros + zeros[:1]}).encode())
for raw in [b'', b' ', b'{}', b'{"terms":[],"terms":[]}', b'{"terms":[],"ter\\u006ds":[]}', b'{"terms":[]}{}', b'\xef\xbb\xbf{"terms":[]}', b'{"terms":[]}\x00', b'\xff', b'{"terms":NaN}', b'{"terms":[{"numerator":true,"denominator":1}]}', b'{"terms":[{"numerator":1.0,"denominator":1}]}', b'{"terms":[{"numerator":0,"denominator":0}]}', b'{"terms":[{"numerator":0,"denominator":-1}]}']:
    check(raw)
check(b'', args=['--help'])
print('Checks completed')
PY
```

These checks cover selected synthetic cases, not universal coverage. Reserved recipes and their measurements are not available in this delivery. No claim of measured performance or general usefulness is made.
