#!/usr/bin/env python3
import json
import sys


def fail():
    sys.stderr.buffer.write(b'{"error":"invalid_input"}\n')
    sys.exit(2)


def validate_string(s):
    if type(s) is not str:
        fail()
    if len(s) == 0:
        fail()
    try:
        b = s.encode("utf-8")
    except UnicodeEncodeError:
        fail()
    if len(b) > 64:
        fail()
    if "\x00" in s or "\r" in s or "\n" in s:
        fail()


def object_pairs_hook(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise ValueError("Duplicate key")
        d[k] = v
    return d


def parse_constant_error(val):
    raise ValueError("Constant not allowed")


def parse_float_error(val):
    raise ValueError("Float not allowed")


def main():
    if len(sys.argv) > 1:
        fail()

    raw = sys.stdin.buffer.read(65537)
    if len(raw) > 65536:
        fail()

    if raw.startswith(b"\xef\xbb\xbf"):
        fail()
    if b"\x00" in raw:
        fail()

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        fail()

    try:
        data = json.loads(
            text,
            object_pairs_hook=object_pairs_hook,
            parse_constant=parse_constant_error,
            parse_float=parse_float_error,
        )
    except Exception:
        fail()

    if type(data) is not dict:
        fail()

    if set(data.keys()) != {"rules", "queries"}:
        fail()

    rules = data["rules"]
    queries = data["queries"]

    if type(rules) is not list or type(queries) is not list:
        fail()
    if len(rules) > 1000 or len(queries) > 1000:
        fail()

    seen_rule_names = set()
    validated_rules = []

    for r in rules:
        if type(r) is not dict:
            fail()
        if set(r.keys()) != {"name", "priority", "requires"}:
            fail()

        name = r["name"]
        validate_string(name)
        if name in seen_rule_names:
            fail()
        seen_rule_names.add(name)

        priority = r["priority"]
        if type(priority) is not int:
            fail()
        if not (-1000000000 <= priority <= 1000000000):
            fail()

        requires = r["requires"]
        if type(requires) is not list:
            fail()
        if len(requires) > 1000:
            fail()

        for req in requires:
            validate_string(req)

        validated_rules.append(
            {
                "name": name,
                "priority": priority,
                "requires_set": set(requires),
            }
        )

    seen_query_ids = set()
    validated_queries = []

    for q in queries:
        if type(q) is not dict:
            fail()
        if set(q.keys()) != {"id", "tags"}:
            fail()

        qid = q["id"]
        validate_string(qid)
        if qid in seen_query_ids:
            fail()
        seen_query_ids.add(qid)

        tags = q["tags"]
        if type(tags) is not list:
            fail()
        if len(tags) > 1000:
            fail()

        for tag in tags:
            validate_string(tag)

        validated_queries.append(
            {
                "id": qid,
                "tags_set": set(tags),
            }
        )

    decisions = []
    for q in validated_queries:
        tags_set = q["tags_set"]
        best_rule = None
        best_key = None

        for r in validated_rules:
            if r["requires_set"].issubset(tags_set):
                key = (-r["priority"], r["name"])
                if best_key is None or key < best_key:
                    best_key = key
                    best_rule = r["name"]

        decisions.append({"id": q["id"], "rule": best_rule})

    output_obj = {"decisions": decisions}
    output_str = json.dumps(output_obj, separators=(",", ":"), ensure_ascii=False) + "\n"
    sys.stdout.buffer.write(output_str.encode("utf-8"))
    sys.exit(0)


if __name__ == "__main__":
    main()
