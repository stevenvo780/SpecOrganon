# Synthetic runtime control

Original sources and host controls are exercised. Quantities, source interpretation, intervention quality and causal effects remain pending. Normative approval requires the competent human.
